
ORK Framework 3 Source Code
https://orkframework.com


-------------------------------------------------------------------------------------------------------------------------------------------------------
Content
-------------------------------------------------------------------------------------------------------------------------------------------------------

- General information
- API



-------------------------------------------------------------------------------------------------------------------------------------------------------
General Information
-------------------------------------------------------------------------------------------------------------------------------------------------------

The C# source code is provided as a Visual Studio solution (using VS Community 2017) and should be compatible with any similar IDE supporting the SLN format.
The solution contains individual projects for ORK Framework (gameplay), the editor as well as 2 projects for each UI module (1 gameplay and 1 editor project each).
Currently there's only the Unity UI module available.

The projects are already set up ready for use and contain the needed Makinom and Unity DLL files and references.
Building the projects will output them to the 'bin' folder, depending on the used configuration (for different Unity versions) it'll be put in the corresponding sub-folder.
E.g. building with 'Unity_2019' configuration (which supports Unity 2019 to 2023) will output to 'bin/Unity_2019', building with 'Unity_6' building with 'Unity_2019' configuration (which supports Unity 6 and newer) will output to 'bin/Unity_6'.
The created DLL files need to be copied into your Unity project, replacing the current DLL files in 'Assets/Gaming Is Love/Makinom 2/' and it's sub-folders.

ORK Framework is an extension for Makinom 2.

You can find general information about scripting with ORK Framework in the ORK documentation:
https://orkframework.com/guide/documentation/scripting/scripting-overview/

You can find general information about scripting with Makinom in the Makinom documentation:
https://makinom.com/guide/documentation/scripting/scripting-overview/



-------------------------------------------------------------------------------------------------------------------------------------------------------
API
-------------------------------------------------------------------------------------------------------------------------------------------------------

You can find the API here:
https://orkframework.com/api/

You'll also find numerous comments all over the source code.
