﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	public class BattleArenaSettings : BaseData
	{
		public BattleSystemSelection battleSystem = new BattleSystemSelection();

		[EditorHelp("Battle Component", "Select a 'Battle' component in the scene.")]
		[EditorLabel("Select a 'Battle' component in the scene, " +
			"it'll be used for the battle and optionally placed between the combatants.\n" +
			"When enabling 'Use Nearest Battle', the nearest 'Battle' component (within a defined range) will be used.\n" +
			"If no 'Battle' component is selected or found, a default 'Battle' component will be generated for the battle.")]
		[EditorInfo(allowSceneObjects=true)]
		public BattleComponent battleComponent;

		[EditorHelp("Set Position", "Set the position of the battle using the initiating combatant's position.")]
		public bool setPosition = false;

		[EditorHelp("Set Rotation", "Set the rotation of the battle using the initiating combatant's rotation.")]
		public bool setRotation = false;


		// nearest
		[EditorHelp("Use Nearest Battle", "Use the nearest 'Battle' component.")]
		[EditorSeparator]
		public bool useNearest = false;

		[EditorHelp("Nearest Range", "The range used to check for near 'Battle' components.\n" +
			"Only components within this range (to the initiating combatant) will be used.")]
		[EditorCondition("useNearest", true)]
		[EditorEndCondition]
		public float nearestRange = 20;

		public BattleArenaSettings()
		{

		}
	}
}
