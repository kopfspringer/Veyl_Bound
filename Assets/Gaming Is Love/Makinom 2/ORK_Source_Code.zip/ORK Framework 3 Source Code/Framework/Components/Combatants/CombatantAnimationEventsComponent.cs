﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Combatant/Combatant Animation Events")]
	public class CombatantAnimationEventsComponent : MonoBehaviour
	{
		protected Combatant combatant;

		protected virtual void OnEnable()
		{
			this.combatant = ORKComponentHelper.GetCombatant(this.gameObject);
		}

		protected virtual void Start()
		{
			this.combatant = ORKComponentHelper.GetCombatant(this.gameObject);
		}

		protected virtual void OnDisable()
		{
			this.combatant = null;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual bool HasCurrentAction
		{
			get
			{
				return this.combatant != null &&
					this.combatant.Actions.Current != null;
			}
		}


		/*
		============================================================================
		Calculate action functions
		============================================================================
		*/
		public virtual void CalculateCurrentAction()
		{
			if(this.HasCurrentAction)
			{
				this.combatant.Actions.Current.CalculateSimple(1);
			}
		}

		public virtual void CalculateCurrentAction(float damageFactor)
		{
			if(this.HasCurrentAction)
			{
				this.combatant.Actions.Current.CalculateSimple(damageFactor);
			}
		}


		/*
		============================================================================
		Damage dealer functions
		============================================================================
		*/
		public virtual void ActivateDamageDealers()
		{
			if(this.combatant != null)
			{
				DamageDealer[] damage = this.GetComponentsInChildren<DamageDealer>(true);
				for(int i = 0; i < damage.Length; i++)
				{
					if(!damage[i].settings.alwaysOn)
					{
						damage[i].SetDamageActive(true);
					}
				}
			}
		}

		public virtual void DeactivateDamageDealers()
		{
			if(this.combatant != null)
			{
				DamageDealer[] damage = this.GetComponentsInChildren<DamageDealer>(true);
				for(int i = 0; i < damage.Length; i++)
				{
					if(!damage[i].settings.alwaysOn)
					{
						damage[i].SetDamageActive(false);
					}
				}
			}
		}

		public virtual void CurrentActionActivateDamageDealers()
		{
			if(this.HasCurrentAction)
			{
				this.combatant.Actions.Current.ActivateUserDamageDealers(true);
			}
		}

		public virtual void CurrentActionDeactivateDamageDealers()
		{
			if(this.HasCurrentAction)
			{
				this.combatant.Actions.Current.ActivateUserDamageDealers(false);
			}
		}
	}
}
