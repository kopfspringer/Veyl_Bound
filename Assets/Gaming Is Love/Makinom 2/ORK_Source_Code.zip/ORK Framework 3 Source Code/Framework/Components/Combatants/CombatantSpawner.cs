
using UnityEngine;
using UnityEngine.AI;
using System.Collections;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using GamingIsLove.ORKFramework.AI;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Combatant/Combatant Spawner")]
	public class CombatantSpawner : BaseBattleComponent, IGlobalSceneGUID, ISerializationCallbackReceiver
	{
		// other collider
		[Tooltip("Use a different collider/trigger (3D) to spawn the combatants.")]
		public Collider otherCollider;

		[Tooltip("Use a different collider/trigger (2D) to spawn the combatants.")]
		public Collider2D otherCollider2D;

		// game objects
		public GameObject[] spawnPoint = new GameObject[0];

		public GameObject[] waypoints = new GameObject[0];


		// settings
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// ingame
		protected bool isInitialized = false;

		protected Collider usedCollider;

		protected Collider2D usedCollider2D;

		protected SpawnerData[] spawned;

		protected bool isSpawned = false;

		protected bool dontRemember = false;

		public virtual bool HasCollider()
		{
			Collider collider = this.otherCollider != null ?
				this.otherCollider :
				this.GetComponent<Collider>();
			if(collider != null &&
				collider.enabled)
			{
				return true;
			}
			Collider2D collider2D = this.otherCollider2D != null ?
				this.otherCollider2D :
				this.GetComponent<Collider2D>();
			if(collider2D != null &&
				collider2D.enabled)
			{
				return true;
			}
			return false;
		}

		public override bool UseSceneID
		{
			get { return this.settings.useSceneID; }
			set { this.settings.useSceneID = value; }
		}

		public override bool IsGlobalSceneID
		{
			get { return this.settings.isGlobalSceneID; }
			set { this.settings.isGlobalSceneID = value; }
		}

		public override int SceneID
		{
			get { return this.settings.sceneID; }
			set { this.settings.sceneID = value; }
		}

		public virtual bool UseSceneGUID
		{
			get { return this.settings.rememberCombatants; }
			set { this.settings.rememberCombatants = value; }
		}

		public virtual bool IsGlobalSceneGUID
		{
			get { return this.settings.rememberGlobal; }
			set { this.settings.rememberGlobal = value; }
		}

		public virtual string SceneGUID
		{
			get { return this.settings.spawnerID; }
			set { this.settings.spawnerID = value; }
		}

		protected virtual void Reset()
		{
			this.startSettings.autoStartSetting.isStart = true;
		}

		/// <summary>
		/// Gives access to the spawned combatants/groups.
		/// </summary>
		public virtual SpawnerData[] Spawned
		{
			get { return this.spawned; }
		}


		/*
		============================================================================
		Event handlers
		============================================================================
		*/
		protected Notify spawnedHandler;
		public virtual event Notify NotifySpawned
		{
			add { this.spawnedHandler += value; }
			remove { this.spawnedHandler -= value; }
		}

		protected Notify despawnedHandler;
		public virtual event Notify NotifyDespawned
		{
			add { this.despawnedHandler += value; }
			remove { this.despawnedHandler -= value; }
		}

		protected Notify anyKilledHandler;
		public virtual event Notify NotifyAnyKilled
		{
			add { this.anyKilledHandler += value; }
			remove { this.anyKilledHandler -= value; }
		}

		protected Notify allKilledHandler;
		public virtual event Notify NotifyAllKilled
		{
			add { this.allKilledHandler += value; }
			remove { this.allKilledHandler -= value; }
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		protected override void Start()
		{
			bool destroyed = false;

			if(ConditionAutoCheckType.Start == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				if(!this.isInitialized)
				{
					this.DoStartSetup(this.startSettings.autoStartSetting.isStart);
				}
				else if(this.startSettings.autoStartSetting.isStart)
				{
					this.AutoStartCheck();
				}
			}
		}

		protected override void OnEnable()
		{
			Maki.Instance.SceneLoaded += this.OnAutoSceneLoaded;

			bool destroyed = false;
			if(ConditionAutoCheckType.Enable == this.conditionSetting.autoCheckType)
			{
				destroyed = this.CheckAutoDestroy();
			}

			if(!destroyed)
			{
				this.Register();

				if(this.isSpawned)
				{
					if(this.settings.disableSpawned &&
						this.spawned != null)
					{
						for(int i = 0; i < this.spawned.Length; i++)
						{
							if(this.spawned[i] != null)
							{
								this.spawned[i].EnableInstances(true);
							}
						}
					}
				}
				else if(this.startSettings.autoStartSetting.isEnable)
				{
					if(!this.isInitialized)
					{
						this.DoStartSetup(true);
					}
					else
					{
						this.AutoStartCheck();
					}
				}
			}
		}

		public override void OnAutoSceneLoaded()
		{
			if(this.startSettings.autoStartSetting.isLevelWasLoaded)
			{
				if(!this.isInitialized)
				{
					this.DoStartSetup(true);
				}
				else
				{
					this.AutoStartCheck();
				}
			}
		}

		protected virtual void DoStartSetup(bool doStart)
		{
			if(!ORK.Access.Combatant.HasSpawnCreationAuthority)
			{
				this.dontRemember = true;
				UnityWrapper.Destroy(this.gameObject);
			}
			else if(!this.isInitialized)
			{
				this.isInitialized = true;

				if(!this.settings.useAppearingChance ||
					(this.settings.IsRememberSpawned &&
						ORK.Game.Scene.ContainsSpawnerData(this.settings.rememberGlobal ? null : this.sceneName, this.settings.spawnerID)) ||
					Maki.GameSettings.CheckRandom(this.settings.appearingChance))
				{
					if(!this.settings.spawnAtPosition)
					{
						this.usedCollider = this.otherCollider != null ? this.otherCollider : this.GetComponent<Collider>();
						this.usedCollider2D = this.otherCollider2D != null ? this.otherCollider2D : this.GetComponent<Collider2D>();
					}

					// init spawned
					if(!this.CheckAutoDestroy())
					{
						if(this.IsSceneIDSet())
						{
							this.dontRemember = true;
							UnityWrapper.Destroy(this.gameObject);
						}
						else if(this.InitSpawned() &&
							doStart)
						{
							this.CheckAutoStart();
						}
					}
				}
				else if(this.settings.useAppearingChance)
				{
					this.dontRemember = true;
					if(this.settings.appearingChanceFailSetID)
					{
						this.SetSceneID(true);
					}
					UnityWrapper.Destroy(this.gameObject);
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual BattleComponent GetBattleComponent(Vector3 position, Vector3 rotation, AutoStartBattleSettings autoStart)
		{
			BattleComponent battle = null;
			if(this.settings.battleArena.battleComponent != null)
			{
				battle = this.settings.battleArena.battleComponent;
				if(this.settings.battleArena.setPosition && this.settings.battleArena.setRotation)
				{
					battle.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
				}
				else
				{
					if(this.settings.battleArena.setPosition)
					{
						battle.transform.position = position;
					}
					if(this.settings.battleArena.setRotation)
					{
						battle.transform.eulerAngles = rotation;
					}
				}
			}
			if(battle == null && this.settings.battleArena.useNearest)
			{
				battle = ComponentHelper.GetNearest<BattleComponent>(position, this.settings.battleArena.nearestRange);
			}
			if(battle == null &&
				autoStart != null &&
				autoStart.useNearestArena)
			{
				battle = ComponentHelper.GetNearest<BattleComponent>(position, autoStart.arenaRange);
			}
			if(battle == null)
			{
				battle = new GameObject("_Battle").AddComponent<BattleComponent>();
				if(this.settings.battleArena.setRotation)
				{
					battle.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
				}
				else
				{
					battle.transform.position = position;
				}
			}
			battle.SetBattleSystem(this.settings.battleArena.battleSystem.GetBattleSystem());
			battle.UseSceneID = this.UseSceneID;
			battle.IsGlobalSceneID = this.IsGlobalSceneID;
			battle.SceneID = this.SceneID;
			return battle;
		}

		protected virtual Vector3 GetSpawnCenter()
		{
			if(!this.settings.spawnAtPosition)
			{
				if(this.usedCollider != null &&
					this.usedCollider.enabled)
				{
					Vector3 castOrigin = this.usedCollider.bounds.center;
					castOrigin.y += this.usedCollider.bounds.extents.y - 0.1f;
					return castOrigin;
				}
				else if(this.usedCollider2D != null &&
					this.usedCollider2D.enabled)
				{
					Vector3 castOrigin = this.usedCollider2D.bounds.center;
					//castOrigin.z += this.usedCollider2D.bounds.extents.z - 0.1f;
					return castOrigin;
				}
			}
			return this.transform.position;
		}

		protected virtual Vector3 GetRandomAdd()
		{
			Vector3 add = Vector3.zero;
			if(!this.settings.spawnAtPosition)
			{
				if(this.usedCollider != null &&
					this.usedCollider.enabled)
				{
					add.x += UnityWrapper.Range(-this.usedCollider.bounds.extents.x,
						this.usedCollider.bounds.extents.x);
					add.z += UnityWrapper.Range(-this.usedCollider.bounds.extents.z,
						this.usedCollider.bounds.extents.z);
				}
				else if(this.usedCollider2D != null &&
					this.usedCollider2D.enabled)
				{
					add.x += UnityWrapper.Range(-this.usedCollider2D.bounds.extents.x,
						this.usedCollider2D.bounds.extents.x);
					add.y += UnityWrapper.Range(-this.usedCollider2D.bounds.extents.y,
						this.usedCollider2D.bounds.extents.y);
				}
			}
			return add;
		}

		protected virtual Vector3 GetSingleSpawnPosition()
		{
			if(this.spawnPoint != null && this.spawnPoint.Length > 0)
			{
				List<GameObject> list = new List<GameObject>(this.spawnPoint);
				ArrayHelper.RemoveAllNull(list);
				if(list.Count > 0)
				{
					return list[UnityWrapper.Range(0, list.Count)].transform.position;
				}
			}
			return this.transform.position;
		}

		public virtual bool IsBlockMoveAI(int index)
		{
			if(index >= 0 && index < this.settings.combatant.Length)
			{
				return this.settings.combatant[index].blockMoveAI;
			}
			return false;
		}

		public virtual bool OwnMoveAI(int index)
		{
			if(index >= 0 && index < this.settings.combatant.Length)
			{
				return this.settings.combatant[index].ownMoveAI;
			}
			return false;
		}

		public virtual MoveAISetting GetMoveAI(int index)
		{
			if(index >= 0 && index < this.settings.combatant.Length)
			{
				if(this.settings.combatant[index].moveAI.StoredAsset != null)
				{
					return this.settings.combatant[index].moveAI.StoredAsset.Settings;
				}
			}
			return null;
		}

		public virtual MoveAIRangeComponent GetMoveAIRange(int index)
		{
			if(index >= 0 && index < this.settings.combatant.Length)
			{
				return this.settings.combatant[index].moveAIRange;
			}
			return null;
		}


		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public virtual void ExternalStart()
		{
			if(!this.isSpawned)
			{
				this.StartInteraction(null);
			}
		}

		public override void StartInteraction(GameObject startingObject)
		{
			if(ORK.Game.ActiveGroup.Size == 0)
			{
				Maki.StartCoroutine(this.DelayStart(startingObject));
			}
			else
			{
				this.DoTurns(startingObject);
				this.CancelInvoke("AutoDestroy");
				this.isInvoking = false;

				if(!this.isInitialized)
				{
					this.DoStartSetup(false);
				}

				this.isSpawned = true;

				if(this.settings.spawnRandom)
				{
					this.StartCoroutine(this.Spawn(this.GetRandomSpawnIndex()));
				}
				else
				{
					this.StartCoroutine(this.SpawnAll());
				}
			}
		}

		protected virtual IEnumerator DelayStart(GameObject startingObject)
		{
			yield return null;
			this.StartInteraction(startingObject);
		}


		/*
		============================================================================
		Spawn functions
		============================================================================
		*/
		protected virtual int GetRandomSpawnIndex()
		{
			if(this.settings.useChanceSelection)
			{
				float random = Maki.GameSettings.GetRandom();
				float tmpChance = 0;

				for(int i = 0; i < this.settings.combatant.Length; i++)
				{
					if(random >= tmpChance && random <= tmpChance + this.settings.combatant[i].combatant.chance)
					{
						return i;
					}
					else
					{
						tmpChance += this.settings.combatant[i].combatant.chance;
					}
				}
			}
			else
			{
				return UnityWrapper.Range(0, this.settings.combatant.Length);
			}
			return -1;
		}

		protected virtual bool CheckSpawnRequirements(int index)
		{
			return ((this.settings.spawnRandom && this.settings.useChanceSelection) ||
					Maki.GameSettings.CheckRandom(this.settings.combatant[index].combatant.chance)) &&
				this.settings.combatant[index].combatant.CheckRequirements();
		}

		protected virtual IEnumerator Spawn(int index)
		{
			if(this.settings.useNavMeshPositions)
			{
				yield return null;
			}
			if(this.CheckSpawnRequirements(index))
			{
				Vector3 castOrigin = this.GetSpawnCenter();
				int count = 0;

				while(this.spawned[index].CanSpawn(this.settings.combatant[index].quantity))
				{
					bool hasSpawned = false;
					if(!this.settings.spawnAtPosition &&
						this.usedCollider != null &&
						this.usedCollider.enabled)
					{
						if(!this.SpawnInArea(index, castOrigin + this.GetRandomAdd()))
						{
							hasSpawned = true;
						}
					}
					else if(!this.settings.spawnAtPosition &&
						this.usedCollider2D != null &&
						this.usedCollider2D.enabled)
					{
						if(!this.SpawnInArea(index, castOrigin + this.GetRandomAdd()))
						{
							hasSpawned = true;
						}
					}
					else if(!this.SpawnAt(index, this.GetSingleSpawnPosition()))
					{
						hasSpawned = true;
					}
					if(hasSpawned)
					{
						count++;
						if(count > this.settings.maxSpawnPerFrame)
						{
							count = 0;
							yield return null;
						}
					}
				}
				if(this.spawnedHandler != null)
				{
					this.spawnedHandler();
				}
			}
		}

		protected virtual IEnumerator SpawnSingle(int index)
		{
			if(this.CheckSpawnRequirements(index))
			{
				Vector3 castOrigin = this.GetSpawnCenter();
				int count = 0;

				while(true)
				{
					bool hasSpawned = false;
					if(!this.settings.spawnAtPosition &&
						this.usedCollider != null &&
						this.usedCollider.enabled)
					{
						if(!this.SpawnInArea(index, castOrigin + this.GetRandomAdd()))
						{
							hasSpawned = true;
						}
					}
					else if(!this.settings.spawnAtPosition &&
						this.usedCollider2D != null &&
						this.usedCollider2D.enabled)
					{
						if(!this.SpawnInArea(index, castOrigin + this.GetRandomAdd()))
						{
							hasSpawned = true;
						}
					}
					else if(!this.SpawnAt(index, this.GetSingleSpawnPosition()))
					{
						hasSpawned = true;
					}
					if(hasSpawned)
					{
						count++;
						if(count > this.settings.maxSpawnPerFrame)
						{
							count = 0;
							yield return null;
						}
					}
					else
					{
						break;
					}
				}
			}
		}

		protected virtual IEnumerator SpawnAll()
		{
			if(this.settings.useNavMeshPositions)
			{
				yield return null;
			}
			Vector3 castOrigin = this.GetSpawnCenter();
			int count = 0;

			for(int i = 0; i < this.settings.combatant.Length; i++)
			{
				if(this.CheckSpawnRequirements(i))
				{
					while(this.spawned[i].CanSpawn(this.settings.combatant[i].quantity))
					{
						bool hasSpawned = false;
						if(!this.settings.spawnAtPosition &&
							this.usedCollider != null &&
							this.usedCollider.enabled)
						{
							if(!this.SpawnInArea(i, castOrigin + this.GetRandomAdd()))
							{
								hasSpawned = true;
							}
						}
						else if(!this.settings.spawnAtPosition &&
							this.usedCollider2D != null &&
							this.usedCollider2D.enabled)
						{
							if(!this.SpawnInArea(i, castOrigin + this.GetRandomAdd()))
							{
								hasSpawned = true;
							}
						}
						else if(!this.SpawnAt(i, this.GetSingleSpawnPosition()))
						{
							hasSpawned = true;
						}
						if(hasSpawned)
						{
							count++;
							if(count > this.settings.maxSpawnPerFrame)
							{
								count = 0;
								yield return null;
							}
						}
					}
				}
			}
			if(this.spawnedHandler != null)
			{
				this.spawnedHandler();
			}
		}

		protected virtual bool SpawnInArea(int index, Vector3 castOrigin)
		{
			if(Rounding.None != this.settings.roundSpawnPosition &&
				(Rounding.Default != this.settings.roundSpawnPosition ||
					RoundingDefault.None != Maki.GameSettings.defaultRounding))
			{
				castOrigin.x = ValueHelper.GetRounded(castOrigin.x, this.settings.roundSpawnPosition);
				castOrigin.z = ValueHelper.GetRounded(castOrigin.z, this.settings.roundSpawnPosition);
			}

			if(this.usedCollider != null &&
				this.usedCollider.enabled)
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(castOrigin, -Vector3.up, out hit,
					this.usedCollider.bounds.size.y, this.settings.layerMask))
				{
					// check if not a spawn zone
					if(!RaycastColliderZone.CheckHit<BlockCombatantSpawn>(hit.transform.gameObject) &&
						!ORK.Game.Scene.WithinNoSpawn(hit.point))
					{
						return this.SpawnAt(index, hit.point);
					}
				}
			}
			else if(this.usedCollider2D != null &&
				this.usedCollider2D.enabled &&
				this.usedCollider2D.OverlapPoint(castOrigin))
			{
				RaycastOutput hit;
				if(RaycastHelper.Raycast(castOrigin, -Vector2.up, out hit, 0, this.settings.layerMask))
				{
					// check if not a spawn zone
					if(!RaycastColliderZone.CheckHit<BlockCombatantSpawn>(hit.transform.gameObject) &&
						!ORK.Game.Scene.WithinNoSpawn(hit.point))
					{
						return this.SpawnAt(index, hit.point);
					}
				}
			}
			return false;
		}

		protected virtual bool SpawnAt(int index, Vector3 position)
		{
			if(this.settings.useNavMeshPositions)
			{
				NavMeshHit navHit;
				if(NavMesh.SamplePosition(position, out navHit,
					this.settings.navMeshSampleDistance, this.settings.navMeshSampleAreaMask))
				{
					position = navHit.position;
				}
				else
				{
					return false;
				}
			}
			Group group = this.settings.combatant[index].combatant.GetGroup(this, index,
				this.settings.combatant[index].despawn ? this.settings.combatant[index].despawnTime : -1, position);
			if(group != null)
			{
				// update spawned info
				this.spawned[index].groups.Add(group);

				group.BattleSystem = this.settings.battleArena.battleSystem.GetBattleSystem();
				group.Leader.Object.SpawnAccess(position, true,
					this.settings.combatant[index].randomRotation ?
						new Vector3(0, UnityWrapper.Range(0.0f, 360.0f), 0) :
						this.transform.eulerAngles,
					this.settings.combatant[index].setScale, this.settings.combatant[index].scale);

				this.settings.combatant[index].UseGroupSettings(group);

				if(this.settings.rememberCombatants)
				{
					List<Combatant> list = group.GetBattle();
					for(int i = 0; i < list.Count; i++)
					{
						list[i].Object.RememberPosition = true;
					}
				}

				this.SetWaypoints(group);
				return true;
			}
			return false;
		}

		public virtual void SetWaypoints(Group group)
		{
			if(this.waypoints.Length > 0)
			{
				List<Combatant> list = group.GetBattle();
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].Object.MoveAI != null)
					{
						list[i].Object.MoveAI.SetWaypoints(this.waypoints, this.settings.randomWaypointOrder);
					}
				}
			}
		}


		/*
		============================================================================
		Respawn functions
		============================================================================
		*/
		public virtual void Despawn()
		{
			if(this.isSpawned)
			{
				this.isSpawned = false;
				for(int i = 0; i < this.spawned.Length; i++)
				{
					this.spawned[i].Despawn();
				}

				if(this.despawnedHandler != null)
				{
					this.despawnedHandler();
				}
			}
		}

		public virtual void Despawn(int index, Group group)
		{
			if(this.isSpawned)
			{
				this.spawned[index].groups.Remove(group);

				if(this.despawnedHandler != null)
				{
					for(int i = 0; i < this.spawned.Length; i++)
					{
						if(this.spawned[i].groups.Count > 0)
						{
							return;
						}
					}
					this.despawnedHandler();
				}
			}
		}

		public virtual void CheckRespawn(int index, Group group, bool destroyInstances, bool isDead)
		{
			if(this.isSpawned)
			{
				this.spawned[index].groups.Remove(group);
				if(this.anyKilledHandler != null)
				{
					this.anyKilledHandler();
				}
				if(this.allKilledHandler != null)
				{
					bool all = true;
					for(int i = 0; i < this.spawned.Length; i++)
					{
						if(this.spawned[i].groups.Count > 0)
						{
							all = false;
							break;
						}
					}
					if(all)
					{
						this.allKilledHandler();
					}
				}
			}
			if(!this.IsSceneIDSet() &&
				this.CheckConditions(ORK.Game.GetPlayer(), false))
			{
				if(this.settings.combatant[index].respawn)
				{
					if(destroyInstances)
					{
						group.DestroyInstances(true);
					}
					this.spawned[index].respawn.Add(this.settings.combatant[index].respawnTime);
				}
			}
		}

		protected override void Update()
		{
			base.Update();

			if(this.spawned != null)
			{
				float delta = ORK.Game.DeltaBattleTime;
				for(int i = 0; i < this.spawned.Length; i++)
				{
					if(this.spawned[i].respawn.Count > 0)
					{
						for(int j = 0; j < this.spawned[i].respawn.Count; j++)
						{
							this.spawned[i].respawn[j] -= delta;

							if(this.spawned[i].respawn[j] <= 0)
							{
								this.spawned[i].respawn.RemoveAt(j--);
								this.StartCoroutine(this.SpawnSingle(
									this.settings.spawnRandom && this.settings.respawnRandom ?
										this.GetRandomSpawnIndex() : i));
							}
						}
					}
				}
			}
		}

		protected virtual bool InitSpawned()
		{
			this.spawned = new SpawnerData[this.settings.combatant.Length];
			for(int i = 0; i < this.spawned.Length; i++)
			{
				this.spawned[i] = new SpawnerData();
			}

			if(this.settings.IsRememberSpawned)
			{
				DataObject data = ORK.Game.Scene.GetSpawnerData(
					this.settings.rememberGlobal ? null : this.sceneName, this.settings.spawnerID);

				if(data != null)
				{
					DataObject[] tmp = data.GetFileArray("spawned");
					if(this.spawned.Length == tmp.Length)
					{
						for(int i = 0; i < this.spawned.Length; i++)
						{
							this.spawned[i].UpdateSpawner(this, i,
								this.settings.combatant[i].despawn ? this.settings.combatant[i].despawnTime : -1);
							this.spawned[i].LoadGame(tmp[i]);
						}
						this.isSpawned = true;
						if(this.spawnedHandler != null)
						{
							this.spawnedHandler();
						}
						return false;
					}
					else
					{
						return true;
					}
				}
			}

			return true;
		}

		public virtual void StoreSpawned()
		{
			if(this.settings.IsRememberSpawned &&
				this.spawned != null && this.isSpawned && !this.dontRemember)
			{
				DataObject data = new DataObject();

				DataObject[] tmp = new DataObject[this.spawned.Length];
				for(int i = 0; i < this.spawned.Length; i++)
				{
					tmp[i] = this.spawned[i].SaveGame();
				}
				data.Set("spawned", tmp);

				ORK.Game.Scene.SetSpawnerData(this.settings.rememberGlobal ? null : this.sceneName, this.settings.spawnerID, data);
			}
		}

		protected override void OnDisable()
		{
			base.OnDisable();

			if(this.settings.disableSpawned &&
				this.isSpawned &&
				this.spawned != null)
			{
				for(int i = 0; i < this.spawned.Length; i++)
				{
					if(this.spawned[i] != null)
					{
						this.spawned[i].EnableInstances(false);
					}
				}
			}
		}

		protected override void OnDestroy()
		{
			base.OnDestroy();

			if(Maki.SaveGame != null &&
				!Maki.SaveGame.IsLoading)
			{
				this.StoreSpawned();
			}

			if(this.settings.destroySpawned &&
				this.spawned != null)
			{
				for(int i = 0; i < this.spawned.Length; i++)
				{
					if(this.spawned[i] != null)
					{
						this.spawned[i].Destroy();
					}
				}
			}
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/CombatantSpawner Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// scene ID
			[EditorHide]
			public bool useSceneID = true;

			[EditorHide]
			public bool isGlobalSceneID = false;

			[EditorHide]
			public int sceneID = -1;

			// remember combatants
			[EditorHide]
			public bool rememberCombatants = false;

			[EditorHide]
			public bool rememberGlobal = false;

			[EditorHide]
			public string spawnerID = "";


			// chance
			[EditorHelp("Use Appearing Chance", "Use a chance check if this combatant spawner is used.")]
			[EditorFoldout("Spawner Settings", "Define the used battle system and arena.")]
			public bool useAppearingChance = false;

			[EditorHelp("Chance (%)", "Define the chance this spawner can appear.")]
			[EditorIndent]
			[EditorCondition("useAppearingChance", true)]
			public float appearingChance = 100;

			[EditorHelp("Fail Set Scene ID", "Failing the chance check will set the scene ID of the spawner (if used).")]
			[EditorIndent]
			[EditorEndCondition]
			public bool appearingChanceFailSetID = false;


			// battle arena
			[EditorSeparator]
			[EditorTitleLabel("Battle Settings")]
			[EditorEndFoldout]
			public BattleArenaSettings battleArena = new BattleArenaSettings();


			// combatant settings
			[EditorFoldout("Combatant Settings", "Define the combatants/groups that will be spawned.")]
			[EditorHelp("Spawn Random", "Spawn a random combatant from the defined combatants/groups.\n" +
				"If disabled, all defined combatants/groups will be spawned.")]
			public bool spawnRandom = false;

			[EditorHelp("Use Chance Selection", "Use the combatant's chance setting to determine which combatant will be spawned.")]
			[EditorIndent]
			[EditorCondition("spawnRandom", true)]
			public bool useChanceSelection = false;

			[EditorHelp("Respawn Random", "Respawn a random combatant.\n" +
				"If disabled, the same combatant will be respawned.")]
			[EditorEndCondition]
			public bool respawnRandom = false;

			[EditorHelp("Disable Spawned", "Spawned combatants will be disabled when the combatant spawner is disabled.\n" +
				"They'll get enabled again when the combatant spawner is enabled.")]
			[EditorSeparator]
			public bool disableSpawned = false;

			[EditorHelp("Destroy Spawned", "Spawned combatants will be destroyed when the combatant spawner is destroyed.")]
			public bool destroySpawned = false;

			// combatants
			[EditorEndFoldout]
			[EditorArray("Add Combatant/Group", "Adds a combatant or group.", "",
				"Remove", "Removes this combatant/group.", "", noRemoveCount = 1,
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Combatant", "Define the combatant or group that will be used.", ""
				})]
			public SpawnerCombatant[] combatant = new SpawnerCombatant[] { new SpawnerCombatant() };


			// set after battle
			[EditorFoldout("Variables After Kill", "Optionally change variables after killing a spawned combatant.\n" +
				"Uses the killed combatant as user.",
				initialState = false)]
			[EditorEndFoldout]
			[EditorLabel("The spawned combatant's variables and selected data are available via the 'Local' origin.")]
			public VariableSetter<GameObjectSelection> variableChanges = new VariableSetter<GameObjectSelection>();


			// spawn settings
			[EditorHide]
			public LayerMask layerMask = -1;

			[EditorHide]
			public Rounding roundSpawnPosition = Rounding.None;

			[EditorHide]
			public bool spawnAtPosition = false;

			[EditorHide]
			public int maxSpawnPerFrame = 50;

			// navmesh settings
			[EditorHide]
			public bool useNavMeshPositions = false;

			[EditorHide]
			public float navMeshSampleDistance = 5;

			[EditorHide]
			public int navMeshSampleAreaMask = NavMesh.AllAreas;

			// waypoint settings
			[EditorHide]
			public bool randomWaypointOrder = false;

			public Settings()
			{

			}

			public virtual bool IsRememberSpawned
			{
				get { return this.rememberCombatants && this.spawnerID != ""; }
			}
		}
	}
}
