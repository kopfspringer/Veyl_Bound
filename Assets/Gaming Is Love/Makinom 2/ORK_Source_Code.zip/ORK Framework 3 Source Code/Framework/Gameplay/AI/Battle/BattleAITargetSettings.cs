﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public class BattleAITargetSettings : BaseData
	{
		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Use Body Parts", "Select if body parts of combatants will be included:\n" +
			"- Yes: Body parts will be included.\n" +
			"- No: Body parts will not be included.\n" +
			"- Only: Only body parts will be used.", "")]
		[EditorIndent]
		[EditorCondition("targetType", BattleAITargetType.Self)]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		public IncludeCheckType includeBodyParts = IncludeCheckType.Yes;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public BattleAITargetSettings()
		{

		}

		public override string ToString()
		{
			return this.targetType.ToString();
		}

		public virtual List<Combatant> GetTargetList(BattleAICall call)
		{
			return BattleAISettings.GetTargetList(this.targetType, this.includeBodyParts,
				this.targetExcludeSelf, this.targetExcludeFoundTargets,
				call);
		}
	}
}
