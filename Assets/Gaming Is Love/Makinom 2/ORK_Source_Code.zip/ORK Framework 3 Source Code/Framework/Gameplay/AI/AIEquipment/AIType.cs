﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.UI;

namespace GamingIsLove.ORKFramework.AI
{
	public class AITypeAsset : MakinomGenericAsset<AIType>
	{
		public AITypeAsset()
		{

		}

		public override string DataName
		{
			get { return "AI Type"; }
		}
	}

	[TextCode(typeof(AITypeAsset), "AI Type", "<aitype.",
		new string[] { "<aitype.name=", "<aitype.shortname=", "<aitype.description=", "<aitype.icon=", "<aitype.custom guid=\"" },
		new string[] { "Name", "Short Name", "Description", "Icon", "Custom Content" })]
	[EditorLanguageExport("AIType")]
	public class AIType : BaseSubTypeData<AITypeAsset, AIType>
	{
		// item type
		[EditorHelp("Item Type", "Select the primary item type of this AI type.\n" +
			"The item type is used when listing AI behaviours or AI rulesets in shops or inventory menus.\n" +
			"This is the item type the AI behavoiurs/rulesets will belong to.\n" +
			"Add secondary item types to list the AI behaviours/rulesets under multiple item types in menus/shops or other type checks.", "")]
		[EditorFoldout("AI Type Settings", "Additional settings for this AI type.", "")]
		public AssetSelection<ItemTypeAsset> itemType = new AssetSelection<ItemTypeAsset>();

		[EditorHelp("Item Type", "Select the item type that'll be used as a secondary item type.\n" +
			"Secondary item types are used to list AI behaviours/rulesets under multiple item types in menus/shops or other type checks.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Secondary Item Type", "Adds a secondary item type.\n" +
			"Secondary item types are used to list AI behaviours/rulesets under multiple item types in menus/shops or other type checks.", "",
			"Remove", "Removes the secondary item type.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Secondary Item Type", "Select the item type that will be used as a secondary item type.\n" +
				"Secondary item types are used to list AI behaviours/rulesets under multiple item types in menus/shops or other type checks.", ""
			})]
		public AssetSelection<ItemTypeAsset>[] secondaryItemType = new AssetSelection<ItemTypeAsset>[0];


		// behaviour UI settings
		// custom UI
		[EditorHelp("Own Shortcut UI", "Use a different shortcut UI setup for AI behaviours of this AI type.")]
		[EditorFoldout("AI Behaviour UI Settings", "Define UI related settings for behaviours of this AI type.", "",
			"Custom Shortcut UI", "Optionally override the default shortcut UI setup for behaviours of this AI type.", "")]
		public bool behaviourOwnShortcutUI = false;

		[EditorEndFoldout]
		[EditorCondition("behaviourOwnShortcutUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings behaviourShortcutUI;

		// information overrides
		// custom number format
		[EditorHelp("Own Number Format", "This AI type overrides the default number formats defined in the text display settings.", "")]
		[EditorFoldout("Information Overrides", "Optionally override notifications or console texts for an AI behaviour.", "",
			"Number Format", "This AI type can optionally override the default number format defined in  'UI > Text Display Settings'.", "",
			initialState = false)]
		public bool behaviourOwnNumberFormat = false;

		[EditorFoldout("Quantity Format", "The format used to display the quantity of an AI behaviour.", "")]
		[EditorEndFoldout(2)]
		[EditorCondition("behaviourOwnNumberFormat", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AdvancedNumberFormat behaviourQuantityFormat;

		// notifications
		[EditorHelp("Own Notifications", "This AI type overrides the default item notifications.", "")]
		[EditorFoldout("Notification Settings", "AI behaviours can override the default item notifications.", "")]
		public bool behaviourOwnNotifications = false;

		[EditorFoldout("AI Behaviour Added", "This notification will be displayed " +
			"when an AI behaviour is added to the player.", "")]
		[EditorEndFoldout]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<quantity> = quantity")]
		[EditorCondition("behaviourOwnNotifications", true)]
		[EditorAutoInit]
		public AINotification behaviourAddedNotification;

		[EditorFoldout("AI Behaviour Removed", "This notification will be displayed " +
			"when an AI behaviour is removed from the player.", "")]
		[EditorEndFoldout(2)]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<quantity> = quantity")]
		[EditorEndCondition]
		[EditorAutoInit]
		public AINotification behaviourRemovedNotification;

		// console texts
		[EditorHelp("Own Add Text", "This AI type overrides the default console add text.", "")]
		[EditorFoldout("Console Texts", "An AI behaviour can override the default console texts.", "")]
		public bool behaviourOwnConsoleAdd = false;

		[EditorFoldout("Add Text", "The text displayed for adding an AI behaviour to the player.", "")]
		[EditorEndFoldout]
		[EditorCondition("behaviourOwnConsoleAdd", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ConsoleTextAI behaviourConsoleAdd;

		[EditorHelp("Own Remove Text", "This AI type overrides the default console remove text.", "")]
		[EditorSeparator]
		public bool behaviourOwnConsoleRemove = false;

		[EditorFoldout("Remove Text", "The text displayed for removing an AI behaviour from the player.", "")]
		[EditorEndFoldout(4)]
		[EditorCondition("behaviourOwnConsoleRemove", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ConsoleTextAI behaviourConsoleRemove;


		// ruleset UI settings
		// custom UI
		[EditorHelp("Own Shortcut UI", "Use a different shortcut UI setup for AI rulesets of this AI type.")]
		[EditorFoldout("AI Ruleset UI Settings", "Define UI related settings for AI rulesets of this AI type.", "",
			"Custom Shortcut UI", "Optionally override the default shortcut UI setup for AI rulesets of this AI type.", "")]
		public bool rulesetOwnShortcutUI = false;

		[EditorEndFoldout]
		[EditorCondition("rulesetOwnShortcutUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings rulesetShortcutUI;

		// information overrides
		// custom number format
		[EditorHelp("Own Number Format", "This AI type overrides the default number formats defined in the text display settings.", "")]
		[EditorFoldout("Information Overrides", "Optionally override notifications or console texts for an AI ruleset.", "",
			"Number Format", "This AI type can optionally override the default number format defined in  'UI > Text Display Settings'.", "",
			initialState = false)]
		public bool rulesetOwnNumberFormat = false;

		[EditorFoldout("Quantity Format", "The format used to display the quantity of this AI ruleset.", "")]
		[EditorEndFoldout(2)]
		[EditorCondition("rulesetOwnNumberFormat", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AdvancedNumberFormat rulesetQuantityFormat;

		// notifications
		[EditorHelp("Own Notifications", "This AI type overrides the default item notifications.", "")]
		[EditorFoldout("Notification Settings", "AI rulesets can override the default item notifications.", "")]
		public bool rulesetOwnNotifications = false;

		[EditorFoldout("AI Ruleset Added", "This notification will be displayed " +
			"when an AI ruleset is added to the player.", "")]
		[EditorEndFoldout]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<quantity> = quantity")]
		[EditorCondition("rulesetOwnNotifications", true)]
		[EditorAutoInit]
		public AINotification rulesetAddedNotification;

		[EditorFoldout("AI Ruleset Removed", "This notification will be displayed " +
			"when an AI ruleset is removed from the player.", "")]
		[EditorEndFoldout(2)]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<quantity> = quantity")]
		[EditorEndCondition]
		[EditorAutoInit]
		public AINotification rulesetRemovedNotification;

		// console texts
		[EditorHelp("Own Add Text", "This AI type overrides the default console add text.", "")]
		[EditorFoldout("Console Texts", "An AI ruleset can override the default console texts.", "")]
		public bool rulesetOwnConsoleAdd = false;

		[EditorFoldout("Add Text", "The text displayed for adding an AI ruleset to the player.", "")]
		[EditorEndFoldout]
		[EditorCondition("rulesetOwnConsoleAdd", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ConsoleTextAI rulesetConsoleAdd;

		[EditorHelp("Own Remove Text", "This AI type overrides the default console remove text.", "")]
		[EditorSeparator]
		public bool rulesetOwnConsoleRemove = false;

		[EditorFoldout("Remove Text", "The text displayed for removing an AI ruleset from the player.", "")]
		[EditorEndFoldout(4)]
		[EditorCondition("rulesetOwnConsoleRemove", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ConsoleTextAI rulesetConsoleRemove;

		public AIType()
		{

		}

		public AIType(string name) : base(name)
		{

		}

		public ItemType ItemType
		{
			get { return this.itemType.StoredAsset != null ? this.itemType.StoredAsset.Settings : null; }
		}

		public virtual bool IsItemType(ItemType type, bool checkParent)
		{
			ItemType tmpType = this.ItemType;
			if(tmpType != null &&
				tmpType.IsType(type, checkParent))
			{
				return true;
			}
			else
			{
				for(int i = 0; i < this.secondaryItemType.Length; i++)
				{
					if(this.secondaryItemType[i].StoredAsset != null &&
						this.secondaryItemType[i].StoredAsset.Settings.IsType(type, checkParent))
					{
						return true;
					}
				}
			}
			return false;
		}

		public virtual void GetItemType(List<ItemType> addToList)
		{
			ItemType tmpType = this.ItemType;
			if(tmpType != null &&
				!addToList.Contains(tmpType))
			{
				addToList.Add(tmpType);
			}
			for(int i = 0; i < this.secondaryItemType.Length; i++)
			{
				if(this.secondaryItemType[i].StoredAsset != null &&
					!addToList.Contains(this.secondaryItemType[i].StoredAsset.Settings))
				{
					addToList.Add(this.secondaryItemType[i].StoredAsset.Settings);
				}
			}
		}


		/*
		============================================================================
		Parent type functions
		============================================================================
		*/
		public override bool HasSubTypes()
		{
			for(int i = 0; i < ORK.AITypes.Count; i++)
			{
				AIType type = ORK.AITypes.Get(i).ParentType;
				if(type == this)
				{
					return true;
				}
			}
			return false;
		}
	}
}
