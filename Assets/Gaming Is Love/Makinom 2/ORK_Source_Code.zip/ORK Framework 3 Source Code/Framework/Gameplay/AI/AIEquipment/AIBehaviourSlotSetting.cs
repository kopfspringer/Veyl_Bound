﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.AI;

namespace GamingIsLove.ORKFramework
{
	public class AIBehaviourSlotSetting : BaseData, IFoldoutInfo
	{
		// unequip
		[EditorHelp("Unequip", "This AI behaviour slot will be unequipped.", "")]
		public bool unequip = false;

		[EditorHelp("Collect", "Collect the currently equipped AI behaviour.\n" +
			"Only used for combatants of the player group.", "")]
		public bool collect = false;


		// equip
		[EditorHelp("AI Behaviour", "Select the AI behaviour that will be equipped.", "")]
		[EditorCondition("unequip", false)]
		public AssetSelection<AIBehaviourAsset> aiBehaviour = new AssetSelection<AIBehaviourAsset>();

		[EditorHelp("From Collection", "The AI behaviour will be taken from the collection, " +
			"i.e. it must be collected and available to be equipped.\n" +
			"This is only used for combatants of the player group.", "")]
		[EditorEndCondition]
		public bool fromCollection = false;

		public AIBehaviourSlotSetting()
		{

		}

		public virtual string GetFoldoutInfo()
		{
			return this.unequip ? "Unequip" : this.aiBehaviour.ToString();
		}

		public void Use(Combatant user, int slotIndex, bool notify)
		{
			if(this.unequip)
			{
				user.AI.UnequipAIBehaviourSlotAccess(slotIndex, this.collect, notify);
			}
			else if(this.aiBehaviour.StoredAsset != null)
			{
				user.AI.EquipAIBehaviourAccess(this.aiBehaviour.StoredAsset.Settings,
					slotIndex, this.collect, this.fromCollection, notify);
			}
		}

		public override string ToString()
		{
			return this.unequip ? "Unequip" : this.aiBehaviour.ToString();
		}
	}
}
