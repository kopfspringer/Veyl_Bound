﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Has Combatant Trigger", "Checks if a combatant has combatant triggers.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class HasCombatantTriggerNode : BaseAICheckNode
	{
		// combatant
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// tags
		[EditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Tags")]
		public Needed needed = Needed.All;

		[EditorWidth(hideName = true)]
		[EditorSeparator]
		[EditorArray("Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal = true)]
		public string[] tags = new string[0];

		public HasCombatantTriggerNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Object.Triggers.Count > 0 &&
					(this.tags.Length == 0 ||
						this.CheckTags(list[i].Object.Triggers)))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTags(List<CombatantTriggerComponent> list)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						list[i].CheckTags(this.tags, this.needed))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("In Combatant Trigger", "Checks if a combatant is within one of the " +
		"user's combatant triggers (or the user in another combatant's trigger).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class InCombatantTriggerNode : BaseAICheckNode
	{
		// combatant
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// settings
		[EditorHelp("In Target's Trigger", "Check if the user is in the target's trigger.\n" +
			"If disabled, checks if the target is in the user's trigger.", "")]
		[EditorSeparator]
		public bool inTargetTrigger = false;



		// tags
		[EditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Tags")]
		public Needed needed = Needed.All;

		[EditorWidth(hideName = true)]
		[EditorSeparator]
		[EditorArray("Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal = true)]
		public string[] tags = new string[0];

		public InCombatantTriggerNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					(this.inTargetTrigger ?
						this.CheckTrigger(list[i], call.user) :
						this.CheckTrigger(call.user, list[i])))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTrigger(Combatant user, Combatant combatant)
		{
			List<CombatantTriggerComponent> list = user.Object.Triggers;
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						(this.tags.Length == 0 ||
							list[i].CheckTags(this.tags, this.needed)) &&
						list[i].Contains(combatant))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() +
				(this.inTargetTrigger ?
					": In target's trigger" :
					": In user's trigger");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}

	[EditorHelp("Combatant Trigger Time", "Checks if a combatant is within one of the " +
		"user's combatant triggers for a defined amount of time (or the user in another combatant's trigger).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Combatant", "Check")]
	public class CombatantTriggerTimeNode : BaseAICheckNode
	{
		// combatant
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// settings
		[EditorHelp("In Target's Trigger", "Check if the user is in the target's trigger.\n" +
			"If disabled, checks if the target is in the user's trigger.", "")]
		[EditorSeparator]
		public bool inTargetTrigger = false;

		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();



		// tags
		[EditorHelp("Needed", "Either all or only one tag must be on added to the combatant trigger component.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Tags")]
		public Needed needed = Needed.All;

		[EditorWidth(hideName = true)]
		[EditorSeparator]
		[EditorArray("Add Tag", "Adds a tag that will be checked.", "",
			"Remove", "Removes this tag.", "", isHorizontal = true)]
		public string[] tags = new string[0];

		public CombatantTriggerTimeNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					(this.inTargetTrigger ?
						this.CheckTrigger(call, list[i], call.user) :
						this.CheckTrigger(call, call.user, list[i])))
				{
					any = true;
					if(!this.targetSettings.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}

		private bool CheckTrigger(BattleAICall call, Combatant user, Combatant combatant)
		{
			call.checkTarget = combatant;
			List<CombatantTriggerComponent> list = user.Object.Triggers;
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].IsActive &&
						(this.tags.Length == 0 ||
							list[i].CheckTags(this.tags, this.needed)))
					{
						float time = list[i].GetTime(combatant);
						if(time >= 0 &&
							this.check.Check(time, call))
						{
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString() + ": " + this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameObjectNodeColor; }
		}
	}
}
