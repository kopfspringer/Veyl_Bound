
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveCondition : BaseData, IFoldoutInfo
	{
		[EditorHelp("Type", "Select the type of the condition's check:", "")]
		[EditorInfo(settingBaseType = typeof(BaseMoveConditionType), settingAutoSetup = "settings")]
		public string type = typeof(LevelMoveConditionType).ToString();

		[EditorSeparator]
		public BaseMoveConditionType settings = new LevelMoveConditionType();

		public MoveCondition()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("type"))
			{
				int tmp = 0;
				data.Get("type", ref tmp);
				if(tmp == 0)
				{
					this.settings = new LevelMoveConditionType();
				}
				else if(tmp == 1)
				{
					this.settings = new ClassLevelMoveConditionType();
				}
				else if(tmp == 2)
				{
					this.settings = new GroupSizeMoveConditionType();
				}
				else if(tmp == 3)
				{
					this.settings = new StatusMoveConditionType();
				}
				this.settings.SetData(data);
				this.type = this.settings.GetType().ToString();
			}
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("settings" == fieldName)
			{
				if(!this.settings.IsType(this.type))
				{
					DataObject data = this.settings.GetData();
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						this.type, typeof(BaseMoveConditionType));
					if(tmpSettings is BaseMoveConditionType)
					{
						this.settings = (BaseMoveConditionType)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new LevelMoveConditionType();
						this.settings.SetData(data);
						this.type = this.settings.GetType().ToString();
					}
				}
			}
		}

		public virtual string GetFoldoutInfo()
		{
			return this.settings.ToString();
		}

		public static bool Check(Combatant combatant, Combatant target, MoveCondition[] condition, Needed needed)
		{
			if(condition != null &&
				condition.Length > 0)
			{
				for(int i = 0; i < condition.Length; i++)
				{
					if(condition[i].settings.IsValid(combatant, target))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				return Needed.All == needed;
			}
			return true;
		}
	}
}
