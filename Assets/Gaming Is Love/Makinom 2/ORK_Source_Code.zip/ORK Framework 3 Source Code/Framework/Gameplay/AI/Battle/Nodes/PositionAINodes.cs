
using UnityEngine;
using System.Collections.Generic;
using System.Text;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Check Distance", "The distance between user and target is checked with a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckDistanceNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// distance
		[EditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Distance")]
		public bool ignoreHeightDistance = false;

		[EditorHelp("Ignore Radius", "The radius of the combatants will be ignored when calculating the distance (radius is defined by 'Radius' components).", "")]
		public bool ignComRad = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();


		// check
		[EditorSeparator]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckDistanceNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status conditions
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					call.checkTarget = list[i];
					if(this.check.Check(call.user.Object.DistanceTo(list[i],
							this.ignoreHeightDistance, this.ignComRad, this.horizontalPlane),
						call))
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Angle", "The angle between user and target is checked with a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckAngleNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// angle
		[EditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Angle")]
		public bool direction = false;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[EditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[EditorCondition("direction", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool fromTarget = false;


		// check
		[EditorSeparator]
		[EditorLabel("Angle has to be between -180 and 180")]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckAngleNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status conditions
			if(call.user.GameObject != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null && list[i].GameObject != null)
					{
						float tmpVal = 0;
						if(this.direction)
						{
							tmpVal = VectorHelper.HorizontalDirectionAngle(call.user.GameObject.transform,
								list[i].GameObject.transform, this.horizontalPlane);
						}
						else if(this.fromTarget)
						{
							tmpVal = VectorHelper.HorizontalAngle(list[i].GameObject.transform,
								call.user.GameObject.transform.position, this.horizontalPlane);
						}
						else
						{
							tmpVal = VectorHelper.HorizontalAngle(call.user.GameObject.transform,
								list[i].GameObject.transform.position, this.horizontalPlane);
						}

						call.checkTarget = list[i];
						if(this.check.Check(tmpVal, call))
						{
							any = true;
							if(!this.targetSettings.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + (this.direction ? " Direction" : "") +
				(this.fromTarget ? " from Target" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Orientation", "Checks the orientation from user to target (e.g. if the target is in front of the user).\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckOrientationNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// orientation
		[EditorHelp("Orientation", "Select the orientation that'll be checked for:\n" +
			"- None: The orientation is ignored.\n" +
			"- Front: The target has to be in front of the user.\n" +
			"- Back: The target has to be in the back of the user.\n" +
			"- Left: The target has to be left of the user.\n" +
			"- Right: The target has to be right of the user.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Orientation")]
		public Orientation orientation = Orientation.Front;

		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		[EditorHelp("From Target", "The orientation is checked from target to user.\n" +
			"If disabled, the orientation is checked from user to target.", "")]
		public bool fromTarget = false;

		public CheckOrientationNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status conditions
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					Orientation check = Orientation.None;
					if(call.user.GameObject != null && list[i].GameObject != null)
					{
						if(this.fromTarget)
						{
							check = VectorHelper.GetOrientation(list[i].GameObject.transform,
								call.user.GameObject.transform, this.horizontalPlane);
						}
						else
						{
							check = VectorHelper.GetOrientation(call.user.GameObject.transform,
								list[i].GameObject.transform, this.horizontalPlane);
						}
					}
					if(Orientation.None == this.orientation ||
						this.orientation == check)
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.orientation + (this.fromTarget ? ", from Target" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Grid Distance", "The distance on a battle grid between user and target is checked with a defined value.\n" +
		"Neighbouring cells have a distance of 1, a cell between is distance of 2, etc.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckGridDistanceNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// check
		[EditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[EditorSeparator]
		public bool blockDiagonalDistance1 = false;

		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		// grid formation
		[EditorHelp("Check Formation", "If the user is part of a grid formation, " +
			"all formation position cells will be checked, using the lowest distance to the checked combatant.", "")]
		[EditorSeparator]
		public bool checkFormation = false;

		[EditorHelp("Only Filled Positions", "Only positions that have a combatant assigned will be checked.\n" +
			"If disabled, all position cells will be checked.", "")]
		[EditorCondition("checkFormation", true)]
		public bool formationOnlyFilled = true;

		[EditorHelp("Only On Position", "Only positions where the assigned combatant is on the position's cell will be checked.\n" +
			"If disabled, a filled position's cell will be checked in any case.", "")]
		[EditorCondition("formationOnlyFilled", true)]
		[EditorEndCondition(2)]
		public bool formationOnlyOnPosition = false;

		[EditorSeparator]
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckGridDistanceNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null &&
				this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(this.checkFormation &&
				call.user.Group.InGridFormation)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].Grid.Cell != null)
					{
						call.checkTarget = list[i];
						if(call.user.Group.GridFormation.CheckGridDistance(list[i],
								(int)this.check.value.GetValue(call),
								(int)(this.check.value2 != null ? this.check.value2.GetValue(call) : 0),
								this.check.type, this.blockDiagonalDistance1, this.ignoreSizeCells,
								this.formationOnlyFilled, this.formationOnlyOnPosition))
						{
							any = true;
							if(!this.targetSettings.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null && list[i].Grid.Cell != null)
					{
						call.checkTarget = list[i];
						if(this.ignoreSizeCells ?
							this.check.Check(
								call.user.Grid.Cell.CubeCoord.Distance(
									list[i].Grid.Cell.CubeCoord, this.blockDiagonalDistance1),
								call) :
							call.user.Grid.CheckDistance(
								list[i], this.blockDiagonalDistance1,
								(int)this.check.value.GetValue(call),
								(int)(this.check.value2 != null ? this.check.value2.GetValue(call) : 0),
								this.check.type, null))
						{
							any = true;
							if(!this.targetSettings.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Is Grid Cell Diagonal", "Checks if user and target are diagonal to each other ('Square' grids only).\n" +
		"Any combatant that is diagonal will be added to the target list. " +
		"The target list will be used by actions to determine the target.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Position", "Check")]
	public class IsGridCellDiagonalNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// check
		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[EditorSeparator]
		public bool ignoreSizeCells = false;

		public IsGridCellDiagonalNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				ORK.BattleGridSettings.IsSquare &&
				call.user.Grid.Cell != null &&
				this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Grid.Cell != null)
				{
					if(this.ignoreSizeCells ?
						CubeCoord.IsSquareDiagonal(call.user.Grid.Cell.CubeCoord, list[i].Grid.Cell.CubeCoord) :
						call.user.Grid.CheckDiagonal(list[i]))
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Rotate To Target", "Changes the user's rotation to look at the found target.", "")]
	[NodeInfo("Position")]
	public class RotateToTargetNode : BaseAINode
	{
		[EditorHelp("Use Center", "Use the center position when multiple targets are available.\n" +
			"If disabled, the first available target will be used.", "")]
		public bool useCenter = false;

		public RotateToTargetNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(call.user.GameObject != null)
			{
				List<Combatant> preferredTargets = BattleAISettings.GetPreferredTargets(call.user, call.foundTargets);

				if(preferredTargets.Count > 0)
				{
					if(this.useCenter)
					{
						call.user.Object.LookAt(ORKTransformHelper.GetCenterPosition(preferredTargets));
					}
					else
					{
						for(int i = 0; i < preferredTargets.Count; i++)
						{
							if(preferredTargets[i] != null &&
								preferredTargets[i].GameObject != null)
							{
								call.user.Object.LookAt(preferredTargets[i]);
								break;
							}
						}
					}
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useCenter ? "Center" : "";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Grid Rotate To Target", "Changes the user's orientation on the grid to look at the found target.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Position")]
	public class GridRotateToTargetNode : BaseAINode
	{
		[EditorHelp("Use Center", "Use the center position when multiple targets are available.\n" +
			"If disabled, the first available target will be used.", "")]
		public bool useCenter = false;

		[EditorHelp("Block Diagonal Rotation", "Diagonal cells in square grids will be ignored " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).\n" +
			"The combatant won't rotate to a diagonal direction (square grids).", "")]
		public bool blockDiagonalRotation = false;

		public GridRotateToTargetNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null)
			{
				List<Combatant> preferredTargets = BattleAISettings.GetPreferredTargets(call.user, call.foundTargets);

				if(preferredTargets.Count > 0)
				{
					if(this.useCenter)
					{
						BattleGridHelper.RotateToPosition(call.user,
							ORKTransformHelper.GetCenterPosition(preferredTargets),
							!this.blockDiagonalRotation);
					}
					else
					{
						for(int i = 0; i < preferredTargets.Count; i++)
						{
							if(preferredTargets[i] != null &&
								preferredTargets[i].GameObject != null)
							{
								BattleGridHelper.RotateToPosition(call.user,
									preferredTargets[i].GameObject.transform.position,
									!this.blockDiagonalRotation);
								break;
							}
						}
					}
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useCenter ? "Center" : "";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Get Nearest", "Adds the nearest combatant to the target list.\n" +
	   "The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Position")]
	public class GetNearestNode : BaseAINode
	{
		public BattleAISingleTargetSettings targetSettings = new BattleAISingleTargetSettings();


		// distance
		[EditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Check Distance")]
		public bool ignoreHeightDistance = false;

		[EditorHelp("Ignore Radius", "The radius of the combatants will be ignored when calculating the distance (radius is defined by 'Radius' components).", "")]
		public bool ignComRad = false;

		[EditorHelp("Nearest Offset Index", "Defines which nearest combatant will be used.\n" +
			"If the index exceeds the available combatants, no combatant will be used.\n" +
			"E.g. 0 is the nearest, 1 is the 2nd nearest, etc.", "")]
		[EditorLimit(0, false)]
		public int nearestOffsetIndex = 0;

		[EditorHelp("Use Grid Distance", "Use the grid distance when used in battles with a battle grid.", "")]
		public bool useGridDistance = false;

		[EditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[EditorCondition("useGridDistance", true)]
		public bool blockDiagonalDistance1 = false;

		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[EditorEndCondition]
		public bool ignoreSizeCells = false;

		[EditorHelp("Inverse Order", "Inverse distance order.", "")]
		public bool inverseOrder = false;

		public GetNearestNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.targetSettings.Use(call, this.Check);

			currentNode = this.next;
			return null;
		}

		private void Check(BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(this.useGridDistance &&
				ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null)
			{
				list.Sort(new CombatantGridDistanceSorter(
					call.user, this.blockDiagonalDistance1,
					this.ignoreSizeCells, this.inverseOrder));
			}
			else
			{
				list.Sort(new CombatantDistanceSorter(call.user,
					this.ignoreHeightDistance, this.ignComRad, this.inverseOrder));
			}

			Combatant nearest = this.nearestOffsetIndex < list.Count ?
				list[this.nearestOffsetIndex] : null;

			if(nearest != null &&
				!foundTargets.Contains(nearest))
			{
				foundTargets.Add(nearest);
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetSettings.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("In Use Range", "Checks if a combatant is within use range of a selected action of the user, " +
		"a battle range template or a custom battle range.\n" +
		"If the check is valid, 'In Range' will be executed, otherwise 'Out Of Range'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Position", "Check")]
	public class InUseRangeNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// use range
		[EditorHelp("Reverse", "Check if the user is within use range of the target.\n" +
			"If disabled, checks if the target is within use range of the user.", "")]
		[EditorSeparator]
		public bool reverse = false;

		[EditorHelp("Check Out Of Range", "Check for out of range instead of in range.")]
		public bool checkOutOfRange = false;

		[EditorHelp("Fail Uses Failed Targets", "The failed targets will be used as found targets if no valid target was found.")]
		[EditorCondition("dontAddTargets", false)]
		[EditorEndCondition]
		public bool failUsesFailedTargets = false;

		public UseRangeCheck<BattleAIObjectSelection> useRangeCheck = new UseRangeCheck<BattleAIObjectSelection>();

		public InUseRangeNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			List<Combatant> outOfRange = !this.targetSettings.dontAddTargets && this.failUsesFailedTargets ?
				new List<Combatant>() : null;
			if(this.targetSettings.Use(call, this.Check, outOfRange))
			{
				currentNode = this.next;
			}
			else
			{
				if(outOfRange != null)
				{
					for(int i = 0; i < outOfRange.Count; i++)
					{
						if(!call.foundTargets.Contains(outOfRange[i]))
						{
							call.foundTargets.Add(outOfRange[i]);
						}
					}
				}

				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets, List<Combatant> outOfRange)
		{
			// check for status conditions
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.checkOutOfRange !=
						(this.reverse ?
							this.useRangeCheck.Check(list[i], call.user, call) :
							this.useRangeCheck.Check(call.user, list[i], call)))
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
					else if(outOfRange != null &&
						!outOfRange.Contains(list[i]))
					{
						outOfRange.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return this.checkOutOfRange ? "Out Of Range" : "In Range";
			}
			else if(index == 1)
			{
				return this.checkOutOfRange ? "In Range" : "Out Of Range";
			}
			return "";
		}

		public override string GetNodeDetails()
		{
			return this.useRangeCheck.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("In Grid Action Range", "Checks if a combatant is within move range and use range of a selected action of the user, " +
		"a battle range template or a custom battle range.\n" +
		"Please note that this can be performance heavy, as it'll potentially check every cell in move range for the use range of the action.\n" +
		"If the check is valid, 'In Range' will be executed, otherwise 'Out Of Range'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Position", "Check")]
	public class InGridActionRangeNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// range
		[EditorHelp("Move Range", "Select which move range will be used:\n" +
			"- Current: The user's current move range.\n" +
			"- Max: The user's maximum move range.\n" +
			"- All: All cells.")]
		[EditorSeparator]
		public MoveRangeType moveRangeType = MoveRangeType.Current;

		[EditorSeparator]
		public UseRangeCheck<BattleAIObjectSelection> useRangeCheck = new UseRangeCheck<BattleAIObjectSelection>();

		public InGridActionRangeNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			BattleRangeSetting range = this.useRangeCheck.GetRange(call.user, call);

			if(FoundTargets.Clear == this.targetSettings.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.targetSettings.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call, range, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.targetSettings.foundType)
			{
				this.Check(ref any, call, range, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call, range,
				this.targetSettings.targetSettings.GetTargetList(call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, BattleRangeSetting range, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(this.targetSettings.dontAddTargets)
			{
				List<Combatant> tmpList = new List<Combatant>();
				if(GridActionRangeHelper.GetInRange(this.moveRangeType, false, call.user, range, list, ref tmpList))
				{
					any = true;
				}
			}
			else
			{
				if(GridActionRangeHelper.GetInRange(this.moveRangeType, false, call.user, range, list, ref foundTargets))
				{
					any = true;
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "In Range";
			}
			else if(index == 1)
			{
				return "Out Of Range";
			}
			return "";
		}

		public override string GetNodeDetails()
		{
			return this.useRangeCheck.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Distance Sort Targets", "Sort the found targets based on their distance to the user.", "")]
	[NodeInfo("Position")]
	public class DistanceSortTargetsNode : BaseAINode
	{
		[EditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		public bool ignoreHeightDistance = false;

		[EditorHelp("Ignore Radius", "The radius of the combatants will be ignored when calculating the distance (radius is defined by 'Radius' components).", "")]
		public bool ignComRad = false;

		[EditorHelp("Use Grid Distance", "Use the grid distance when used in battles with a battle grid.", "")]
		public bool useGridDistance = false;

		[EditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[EditorCondition("useGridDistance", true)]
		public bool blockDiagonalDistance1 = false;

		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[EditorEndCondition]
		public bool ignoreSizeCells = false;

		[EditorHelp("Inverse Order", "Inverse the sorting.", "")]
		public bool inverseOrder = false;

		public DistanceSortTargetsNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(call.user.GameObject != null)
			{
				if(this.useGridDistance &&
					ORK.Battle.Grid != null &&
					call.user.Grid.Cell != null)
				{
					call.foundTargets.Sort(new CombatantGridDistanceSorter(
						call.user, this.blockDiagonalDistance1,
						this.ignoreSizeCells, this.inverseOrder));
				}
				else
				{
					call.foundTargets.Sort(new CombatantDistanceSorter(call.user,
						this.ignoreHeightDistance, this.ignComRad, this.inverseOrder));
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.inverseOrder ? "Inverse" : "";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Grid Cell Type", "Checks if a combatant is currently on a cell of a defined grid cell type.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckGridCellTypeNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// settings
		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		[EditorSeparator]
		public bool ignoreSizeCells = false;


		// grid cell type
		[EditorHelp("Grid Cell Type", "Select the grid cell type that will be used.", "")]
		[EditorArray("Add Grid Cell Type", "Adds a grid cell type that will be used.", "",
			"Remove", "Removes the grid cell type.", "",
			isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Grid Cell Type", "Select the grid cell type that will be used.", ""
			})]
		public AssetSelection<BattleGridCellTypeAsset>[] gridCellType = new AssetSelection<BattleGridCellTypeAsset>[] {
			new AssetSelection<BattleGridCellTypeAsset>()
		};

		public CheckGridCellTypeNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null &&
				this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Grid.Cell != null)
				{
					if(this.ignoreSizeCells ?
						BattleGridHelper.IsCellType(list[i].Grid.Cell, this.gridCellType) :
						list[i].Grid.IsOnCellType(this.gridCellType))
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			StringBuilder builder = new StringBuilder();
			for(int i = 0; i < this.gridCellType.Length; i++)
			{
				if(i > 0)
				{
					builder.Append(", ");
				}
				builder.Append(this.gridCellType[i].ToString());
			}
			return builder.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Get Weighted Group", "Uses the largest or smallest weighted group of combatants as targets.\n" +
		"A weighted group is based on the physical proximity between combatants, defined by a maximum distance between them.\n" +
		"The combatants of the weighted group will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Position")]
	public class GetWeightedGroupNode : BaseAINode
	{
		public BattleAISingleTargetSettings targetSettings = new BattleAISingleTargetSettings();


		// weighted group
		[EditorHelp("Weighted Group", "Select which weighted group will be used:\n" +
			"- Smallest: The weighted group with the least combatants.\n" +
			"- Largest: The weighted group with the most combatants.", "")]
		[EditorSeparator]
		public WeightedGroupType groupType = WeightedGroupType.Largest;

		[EditorHelp("Same Size", "Select which group will be used if multiple groups of the same size are found:\n" +
			"- Nearest: Uses the group with the nearest combatant.\n" +
			"- Nearest Average: Uses the nearest group (average distance)\n" +
			"- Farthest: Uses the group with the farthest combatant.\n" +
			"- Farthest Average: Uses the farthest group (average distance)\n" +
			"- All: Uses all groups.", "")]
		public DistanceType distanceType = DistanceType.Nearest;


		// distance
		[EditorSeparator]
		[EditorHelp("Maximum Distance", "The maximum distance between combatants to be part of a weighted group.")]
		public FloatValue<BattleAIObjectSelection> distance = new FloatValue<BattleAIObjectSelection>();

		// grid distance
		[EditorHelp("Use Grid Distance", "Use the grid distance when used in battles with a battle grid.", "")]
		public bool useGridDistance = false;

		[EditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		[EditorCondition("useGridDistance", true)]
		public bool blockDiagonalDistance1 = false;

		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		// regular distance
		[EditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[EditorElseCondition]
		public bool ignoreHeightDistance = false;

		[EditorHelp("Ignore Radius", "The radius of the combatants will be ignored when calculating the distance (radius is defined by 'Radius' components).", "")]
		public bool ignComRad = false;

		[EditorEndCondition]
		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		public GetWeightedGroupNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			this.targetSettings.Use(call, this.Check);

			currentNode = this.next;
			return null;
		}

		private void Check(BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			List<List<Combatant>> groups = new List<List<Combatant>>();

			// grid distance
			if(this.useGridDistance &&
				ORK.Battle.Grid != null &&
				call.user.Grid.Cell != null)
			{
				List<Combatant> combatants = new List<Combatant>();
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].Grid.Cell != null)
					{
						combatants.Add(list[i]);
					}
				}

				while(combatants.Count > 0)
				{
					groups.Add(this.GetWeightedGroupGrid(call, combatants));
				}
			}
			// distance
			else
			{
				List<Combatant> combatants = new List<Combatant>();
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null &&
						list[i].GameObject != null)
					{
						combatants.Add(list[i]);
					}
				}

				while(combatants.Count > 0)
				{
					groups.Add(this.GetWeightedGroup(call, combatants));
				}
			}

			// get count
			int count = 0;
			if(WeightedGroupType.Smallest == this.groupType)
			{
				count = int.MaxValue;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count < count)
					{
						count = groups[i].Count;
					}
				}
			}
			else if(WeightedGroupType.Largest == this.groupType)
			{
				for(int i = 0; i < groups.Count; i++)
				{
					if(count < groups[i].Count)
					{
						count = groups[i].Count;
					}
				}
			}

			List<Combatant> usedGroup = null;
			if(DistanceType.Nearest == this.distanceType)
			{
				float tmpDistance = Mathf.Infinity;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						float groupDistance = this.useGridDistance &&
							ORK.Battle.Grid != null &&
							call.user.Grid.Cell != null ?
								DistanceHelper.GetNearestGrid(call.user, groups[i],
									this.blockDiagonalDistance1, this.ignoreSizeCells) :
								DistanceHelper.GetNearest(call.user, groups[i], this.ignoreHeightDistance,
									this.ignComRad, this.horizontalPlane);

						if(groupDistance < tmpDistance)
						{
							tmpDistance = groupDistance;
							usedGroup = groups[i];
						}
					}
				}
			}
			else if(DistanceType.NearestAverage == this.distanceType)
			{
				float tmpDistance = Mathf.Infinity;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						float groupDistance = this.useGridDistance &&
							ORK.Battle.Grid != null &&
							call.user.Grid.Cell != null ?
								DistanceHelper.GetAverageGrid(call.user, groups[i],
									this.blockDiagonalDistance1, this.ignoreSizeCells) :
								DistanceHelper.GetAverage(call.user, groups[i], this.ignoreHeightDistance,
									this.ignComRad, this.horizontalPlane);

						if(groupDistance < tmpDistance)
						{
							tmpDistance = groupDistance;
							usedGroup = groups[i];
						}
					}
				}
			}
			else if(DistanceType.Farthest == this.distanceType)
			{
				float tmpDistance = 0;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						float groupDistance = this.useGridDistance &&
							ORK.Battle.Grid != null &&
							call.user.Grid.Cell != null ?
								DistanceHelper.GetFarthestGrid(call.user, groups[i],
									this.blockDiagonalDistance1, this.ignoreSizeCells) :
								DistanceHelper.GetFarthest(call.user, groups[i], this.ignoreHeightDistance,
									this.ignComRad, this.horizontalPlane);

						if(tmpDistance < groupDistance)
						{
							tmpDistance = groupDistance;
							usedGroup = groups[i];
						}
					}
				}
			}
			else if(DistanceType.FarthestAverage == this.distanceType)
			{
				float tmpDistance = 0;
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						float groupDistance = this.useGridDistance &&
							ORK.Battle.Grid != null &&
							call.user.Grid.Cell != null ?
								DistanceHelper.GetAverageGrid(call.user, groups[i],
									this.blockDiagonalDistance1, this.ignoreSizeCells) :
								DistanceHelper.GetAverage(call.user, groups[i], this.ignoreHeightDistance,
									this.ignComRad, this.horizontalPlane);

						if(tmpDistance < groupDistance)
						{
							tmpDistance = groupDistance;
							usedGroup = groups[i];
						}
					}
				}
			}
			else if(DistanceType.All == this.distanceType)
			{
				for(int i = 0; i < groups.Count; i++)
				{
					if(groups[i].Count == count)
					{
						for(int j = 0; j < groups[i].Count; j++)
						{
							if(!foundTargets.Contains(groups[i][j]))
							{
								foundTargets.Add(groups[i][j]);
							}
						}
					}
				}
			}

			if(usedGroup != null)
			{
				for(int i = 0; i < usedGroup.Count; i++)
				{
					if(!foundTargets.Contains(usedGroup[i]))
					{
						foundTargets.Add(usedGroup[i]);
					}
				}
			}
		}

		public List<Combatant> GetWeightedGroup(BattleAICall call, List<Combatant> combatants)
		{
			List<Combatant> group = new List<Combatant>();

			if(combatants.Count > 0)
			{
				group.Add(combatants[0]);
				combatants.RemoveAt(0);

				for(int i = 0; i < combatants.Count; i++)
				{
					for(int j = 0; j < group.Count; j++)
					{
						if(group[j].Object.DistanceTo(combatants[i], this.ignoreHeightDistance,
								this.ignComRad, this.horizontalPlane) <=
							this.distance.GetValue(new BattleAICall(call, group[j], combatants[i])))
						{
							group.Add(combatants[i]);
							combatants.RemoveAt(i--);
							i = -1;
							break;
						}
					}
				}
			}

			return group;
		}

		public List<Combatant> GetWeightedGroupGrid(BattleAICall call, List<Combatant> combatants)
		{
			List<Combatant> group = new List<Combatant>();

			if(combatants.Count > 0)
			{
				group.Add(combatants[0]);
				combatants.RemoveAt(0);

				for(int i = 0; i < combatants.Count; i++)
				{
					for(int j = 0; j < group.Count; j++)
					{
						if(this.ignoreSizeCells ?
							(group[j].Grid.Cell.CubeCoord.Distance(
									combatants[i].Grid.Cell.CubeCoord, this.blockDiagonalDistance1) <=
								this.distance.GetValue(new BattleAICall(call, group[j], combatants[i]))) :
							group[j].Grid.CheckDistance(combatants[i], this.blockDiagonalDistance1,
								0, (int)this.distance.GetValue(new BattleAICall(call, group[j], combatants[i])),
								ValueCheckType.RangeInclusive, null))
						{
							group.Add(combatants[i]);
							combatants.RemoveAt(i);
							i = -1;
							break;
						}
					}
				}
			}

			return group;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.distance.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Height Differences", "Checks if a combatant is above or below the user.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Position", "Check")]
	public class CheckHeightDifferencesNode : BaseAICheckNode
	{
		public BattleAIMultiTargetSettings targetSettings = new BattleAIMultiTargetSettings();


		// height check
		[EditorSeparator]
		public HeightDifferenceCheck heightCheck = new HeightDifferenceCheck();

		public CheckHeightDifferencesNode()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("foundType"))
			{
				this.targetSettings.SetData(data);
			}
		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.targetSettings.Use(call, this.Check))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.heightCheck.Check(call.user.GameObject, list[i].GameObject))
					{
						any = true;
						if(!this.targetSettings.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.heightCheck.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}
}
