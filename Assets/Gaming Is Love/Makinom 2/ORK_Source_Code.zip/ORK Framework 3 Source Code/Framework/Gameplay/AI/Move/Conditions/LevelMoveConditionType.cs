﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	[EditorSettingInfo("Level", "Checks the target's level.")]
	public class LevelMoveConditionType : BaseMoveConditionType
	{
		[EditorHelp("Use Offset", "The defined level value is added to the combatant's level for the check.\n" +
			"If disabled, only the defined level value is used.", "")]
		public bool levelOffset = true;

		[EditorHelp("Average Level", "Use the target's average group level for the check.\n" +
			"If disabled, the target's level is used.", "")]
		public bool levelAverage = false;

		[EditorHelp("Only Battle Group", "Only the target's battle group is used for the average level.\n" +
			"If disabled, the whole group is used.", "")]
		[EditorCondition("levelAverage", true)]
		[EditorEndCondition]
		public bool levelOnlyBattle = true;

		[EditorSeparator]
		public ValueCheck<GameObjectSelection> valueCheck = new ValueCheck<GameObjectSelection>(1);

		public LevelMoveConditionType()
		{

		}

		public override string ToString()
		{
			return "Level " + this.valueCheck.ToString();
		}

		public override bool IsValid(Combatant combatant, Combatant target)
		{
			DataCall call = this.valueCheck.NeedsCall ? new DataCall(combatant, target) : null;
			if(this.levelAverage)
			{
				if(this.levelOnlyBattle)
				{
					return this.levelOffset ?
						this.valueCheck.Check(target.Group.AverageBattleLevel, combatant.Status.Level, call) :
						this.valueCheck.Check(target.Group.AverageBattleLevel, call);
				}
				else
				{
					return this.levelOffset ?
						this.valueCheck.Check(target.Group.AverageLevel, combatant.Status.Level, call) :
						this.valueCheck.Check(target.Group.AverageLevel, call);
				}
			}
			else
			{
				return this.levelOffset ?
					this.valueCheck.Check(target.Status.Level, combatant.Status.Level, call) :
					this.valueCheck.Check(target.Status.Level, call);
			}
		}
	}
}
