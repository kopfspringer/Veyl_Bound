﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface IContentCombatantInfo
	{
		string GetInfo(Combatant c);
	}

	public static class CombatantContentHelper
	{
		public static string Get(object content, Combatant combatant)
		{
			if(content is IContentCombatantInfo)
			{
				return ((IContentCombatantInfo)content).GetInfo(combatant);
			}
			return "";
		}
	}
}
