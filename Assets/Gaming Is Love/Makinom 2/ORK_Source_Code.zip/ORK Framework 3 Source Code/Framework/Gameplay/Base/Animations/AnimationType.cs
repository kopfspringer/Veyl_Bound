
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Animations
{
	public class AnimationTypeAsset : MakinomGenericAsset<AnimationType>
	{
		public AnimationTypeAsset()
		{

		}

		public override string DataName
		{
			get { return "Animation Type"; }
		}
	}

	public class AnimationType : BaseIndexData
	{
		[EditorHelp("Name", "The name of this animation type.", "")]
		[EditorFoldout("Base Settings", "Set the name of this animation type.", "")]
		[EditorWidth(true)]
		[EditorEndFoldout]
		public string name = "";

		public AnimationType()
		{

		}

		public AnimationType(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}
	}
}
