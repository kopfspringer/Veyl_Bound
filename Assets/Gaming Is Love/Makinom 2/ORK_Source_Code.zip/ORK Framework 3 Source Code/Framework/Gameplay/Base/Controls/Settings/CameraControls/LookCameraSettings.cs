﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class LookCameraSettings : BaseData
	{
		[EditorHelp("Child Object", "Use a child object of the player to position the camera.", "")]
		public ChildObjectSettings childObject = new ChildObjectSettings();

		[EditorHelp("Use Unscaled Time", "Use unscaled delta time.\n" +
			"I.e. the camera control is not affected when changing the timescale.", "")]
		public bool useUnscaledTime = false;

		[EditorHelp("Smooth", "Camera changes will use damping.", "")]
		[EditorSeparator]
		public bool smooth = true;

		[EditorHelp("Damping", "Used for smoother camera changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorCondition("smooth", true)]
		[EditorEndCondition]
		[EditorLimit(0.0f, false)]
		public float damping = 6.0f;

		public LookCameraSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.childObject.Upgrade(data, "onChild");
		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				SmoothLookAt comp = camera.GetComponent<SmoothLookAt>();
				if(comp == null)
				{
					comp = camera.AddComponent<SmoothLookAt>();
					comp.settings.SetData(this.GetData());
				}
				if(comp != null)
				{
					Maki.Control.AddCameraControl(comp);
				}
			}
		}
	}
}
