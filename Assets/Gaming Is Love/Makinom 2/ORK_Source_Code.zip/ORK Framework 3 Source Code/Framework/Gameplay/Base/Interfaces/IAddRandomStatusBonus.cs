﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface IAddRandomStatusBonus
	{
		void AddRandomStatusBonus(RandomStatusBonusSettings settings);

		void RemoveAllStatusBonuses();
	}
}
