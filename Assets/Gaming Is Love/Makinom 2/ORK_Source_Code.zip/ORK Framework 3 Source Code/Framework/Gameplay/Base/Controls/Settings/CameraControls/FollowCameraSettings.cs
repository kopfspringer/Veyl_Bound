﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class FollowCameraSettings : BaseData
	{
		[EditorHelp("Child Object", "Use a child object of the player to position the camera.", "")]
		public ChildObjectSettings childObject = new ChildObjectSettings();

		[EditorHelp("Use Unscaled Time", "Use unscaled delta time.\n" + 
			"I.e. the camera control is not affected when changing the timescale.", "")]
		public bool useUnscaledTime = false;

		[EditorHelp("Distance", "The distance of the camera to the player.", "")]
		[EditorSeparator]
		public float distance = 10.0f;

		[EditorHelp("Height", "The height above the player.", "")]
		public float height = 5.0f;

		[EditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorLimit(0.0f, false)]
		public float heightDamping = 2.0f;

		[EditorHelp("Rotation Damping", "Used for smoother rotation changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[EditorLimit(0.0f, false)]
		public float rotationDamping = 3.0f;

		public FollowCameraSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.childObject.Upgrade(data, "onChild");
		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				SmoothFollow comp = camera.GetComponent<SmoothFollow>();
				if(comp == null)
				{
					comp = camera.AddComponent<SmoothFollow>();
					comp.settings.SetData(this.GetData());
				}
				if(comp != null)
				{
					Maki.Control.AddCameraControl(comp);
				}
			}
		}
	}
}
