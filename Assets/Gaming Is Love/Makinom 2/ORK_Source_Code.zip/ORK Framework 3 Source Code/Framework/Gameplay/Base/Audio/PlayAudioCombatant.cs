
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class PlayAudioCombatant : BaseData
	{
		public enum PlayType { Combatant, SoundChannel, SoundChannelFallback }

		[EditorHelp("Use Sound Type", "The combatant's defined sound of a selected sound type will be used.", "")]
		public bool useSoundType = false;

		[EditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[EditorCondition("useSoundType", true)]
		[EditorAutoInit]
		public AssetSelection<SoundTypeAsset> soundType;

		[EditorHelp("Audio Clip", "The selected audio clip will be played.", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<AudioClip> audioClip;

		[EditorHelp("Volume", "The volume used to play the audio clip.", "")]
		[EditorLimit(0.0f, 1.0f)]
		public float volume = 1;

		[EditorHelp("Play On", "Select where to play the sound:\n" +
			"- Combatant: On the combatant's game object.\n" +
			"- Sound Channel: On a defined sound channel.\n" +
			"- Sound Channel Fallback: On the combatant if spawned, otherwise on a defined sound channel.")]
		public PlayType playType = PlayType.Combatant;

		[EditorHelp("Sound Channel", "Define the sound channel that will used.\n" +
			"The default channel is 0.")]
		[EditorLimit(0, false)]
		[EditorCondition("playType", PlayType.Combatant)]
		[EditorElseCondition]
		[EditorEndCondition]
		public int channel = 0;

		public PlayAudioCombatant()
		{

		}

		public void Play(Combatant combatant)
		{
			if(combatant != null)
			{
				AudioClip clip = this.useSoundType ?
					combatant.Animations.GetAudioClip(this.soundType) :
					this.audioClip;
				if(clip != null)
				{
					if(PlayType.Combatant == this.playType)
					{
						AudioSource source = combatant.Object.GetAudioSource();
						if(source != null)
						{
							ComponentHelper.PlayOneShot(source.gameObject, clip, this.volume);
						}
					}
					else if(PlayType.SoundChannel == this.playType)
					{
						Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(clip, this.volume);
					}
					else if(PlayType.SoundChannelFallback == this.playType)
					{
						AudioSource source = combatant.Object.GetAudioSource();
						if(source != null)
						{
							ComponentHelper.PlayOneShot(source.gameObject, clip, this.volume);
						}
						else
						{
							Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(clip, this.volume);
						}
					}
				}
			}
		}
	}
}
