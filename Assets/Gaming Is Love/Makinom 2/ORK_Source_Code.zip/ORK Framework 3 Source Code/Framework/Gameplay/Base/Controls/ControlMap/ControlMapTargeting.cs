﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ControlMapTargeting : BaseData
	{
		// cursor target
		[EditorHelp("Only Cursor Over Target", "The control map key can only be used when the cursor is over a valid target.", "")]
		public bool onlyCursorOverTarget = false;

		[EditorHelp("Only In Range", "Cursor over targets will only be used when the target is in range.", "")]
		[EditorIndent]
		[EditorCondition("onlyCursorOverTarget", true)]
		[EditorEndCondition]
		public bool cursorOverInRange = false;

		[EditorHelp("Use Cursor Over Target", "Use the combatant the cursor is over as the action's target.\n" +
			"If the cursor isn't over a valid target, the auto target or target selection will be used.", "")]
		public bool useCursorOverTarget = false;


		// auto target
		[EditorHelp("Use Auto Target", "Automatically selects the action's targets using " +
			"the 'Auto Targets' settings of abilities/items or the user's AI settings.\n" +
			"The group/individual target is ignored.", "")]
		[EditorSeparator]
		public bool useAutoTarget = false;

		[EditorHelp("Auto Target Only", "Only use auto target for abilities/items that have " +
			"'Use Auto Target' enabled in their settings.", "")]
		[EditorCondition("useAutoTarget", true)]
		[EditorEndCondition]
		public bool autoTargetOnly = false;


		// target selections
		[EditorHelp("Use Group Target", "Automatically use a group target for abilities and items (if available).", "")]
		[EditorSeparator]
		public bool useGroupTarget = true;

		[EditorHelp("Use Individual Target", "Automatically use an individual target for abilities and items (if available).", "")]
		public bool useIndividualTarget = true;

		[EditorHelp("Prioritize Raycast", "Raycast targeting of 'None' target range abilities/items will be used even if group/individual targets are available.\n" +
			"If disabled, the group/individual target will be used instead of raycast targeting.", "")]
		[EditorIndent]
		[EditorCondition("useGroupTarget", true)]
		[EditorCondition("useIndividualTarget", true)]
		[EditorEndCondition]
		public bool prioritizeRaycast = false;

		[EditorHelp("No Target Selection", "The control map key will not bring up any target selection if auto or cursor targeting fails.\n" +
			"Using the key will fail in that case.", "")]
		public bool noTargetSelection = false;

		[EditorHelp("Need Targets", "Actions that need target selection require possible targets to display the battle menu.\n" +
			"If no targets are available, the action won't be used and no target menu displayed.\n" +
			"If disabled, the action will display an empty target menu.", "")]
		[EditorCondition("noTargetSelection", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool needTargets = false;


		// static
		public static readonly ControlMapTargeting Default = new ControlMapTargeting(
			false, false, false, true, false, true, true, false, false, false);

		public ControlMapTargeting()
		{

		}

		public ControlMapTargeting(bool onlyCursorOverTarget, bool cursorOverInRange, bool useCursorOverTarget,
			bool useAutoTarget, bool autoTargetOnly,
			bool useGroupTarget, bool useIndividualTarget, bool prioritizeRaycast,
			bool noTargetSelection, bool needTargets)
		{
			this.onlyCursorOverTarget = onlyCursorOverTarget;
			this.cursorOverInRange = cursorOverInRange;
			this.useCursorOverTarget = useCursorOverTarget;
			this.useAutoTarget = useAutoTarget;
			this.autoTargetOnly = autoTargetOnly;
			this.useGroupTarget = useGroupTarget;
			this.useIndividualTarget = useIndividualTarget;
			this.prioritizeRaycast = prioritizeRaycast;
			this.noTargetSelection = noTargetSelection;
			this.needTargets = needTargets;
		}
	}
}
