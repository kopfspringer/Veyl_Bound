﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface ICombatantHighlightCursorPrefab
	{
		void StartSelection(Combatant combatant);

		void StopSelection();
	}
}
