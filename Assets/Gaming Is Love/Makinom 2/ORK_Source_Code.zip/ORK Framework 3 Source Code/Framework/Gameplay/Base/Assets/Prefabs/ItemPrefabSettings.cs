﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ItemPrefabSettings : BaseData
	{
		// prefab
		public ItemPrefab prefab = new ItemPrefab();


		// conditional prefabs
		[EditorSeparator]
		[EditorArray("Add Conditional Prefab", "Adds a conditional prefab.\n" +
			"A conditional prefab can replace the item's prefab based on variable conditions.\n" +
			"The first conditional prefab with valid conditions will be used. " +
			"If none is valid, the base prefab will be used.", "",
			"Remove", "Removes this conditional prefab.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Conditional Prefab", "A conditional prefab can replace the item's " +
				"prefab based on variable conditions.\n" +
				"The first conditional prefab with valid conditions will be used. " +
				"If none is valid, the base prefab will be used.", ""
		})]
		public ItemConditionalPrefab[] conditionalPrefab = new ItemConditionalPrefab[0];

		public ItemPrefabSettings()
		{

		}

		public virtual bool HasConditions
		{
			get
			{
				for(int i = 0; i < this.conditionalPrefab.Length; i++)
				{
					if(this.conditionalPrefab[i].condition.Has)
					{
						return true;
					}
				}
				return false;
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public virtual GameObject GetPrefab(IVariableSource variableSource)
		{
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					return this.conditionalPrefab[i].prefab.prefab.StoredAsset;
				}
			}

			// base prefab
			return this.prefab.prefab.StoredAsset;
		}

		public virtual GameObject GetPrefab(IVariableSource variableSource, ref int prefabIndex, ref Vector3 offset)
		{
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					prefabIndex = i;
					offset = this.conditionalPrefab[i].prefab.spawnOffset;
					return this.conditionalPrefab[i].prefab.prefab.StoredAsset;
				}
			}

			// base prefab
			prefabIndex = -1;
			offset = this.prefab.spawnOffset;
			return this.prefab.prefab.StoredAsset;
		}


		/*
		============================================================================
		Portrait functions
		============================================================================
		*/
		public virtual void SetPortraitPrefab(TypePrefabViewPortrait portrait, IVariableSource variableSource)
		{
			if(portrait != null &&
				portrait.CanSetPrefab)
			{
				portrait.SetPrefab(this.GetPrefab(variableSource));
				if(this.HasConditions &&
					portrait.PrefabView.clearCall == null)
				{
					// check
					Notify check = delegate()
					{
						portrait.SetPrefab(this.GetPrefab(variableSource));
					};

					// register
					Maki.Game.Variables.Changed += check;
					if(variableSource != null &&
						variableSource.HasVariables)
					{
						variableSource.Variables.Changed += check;
					}

					// remove
					portrait.PrefabView.clearCall = delegate ()
					{
						Maki.Game.Variables.Changed -= check;
						if(variableSource != null &&
							variableSource.HasVariables)
						{
							variableSource.Variables.Changed -= check;
						}
					};

				}
			}
		}
	}
}
