
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class DifficultyAsset : MakinomGenericAsset<Difficulty>
	{
		public DifficultyAsset()
		{

		}

		public override string DataName
		{
			get { return "Difficulty"; }
		}
	}

	[TextCode(typeof(DifficultyAsset), "Difficulty", "<difficulty.",
		new string[] { "<difficulty.name=", "<difficulty.shortname=", "<difficulty.description=", "<difficulty.icon=", "<difficulty.custom guid=\"" },
		new string[] { "Name", "Short Name", "Description", "Icon", "Custom Content" })]
	[EditorLanguageExport("Difficulty")]
	public class Difficulty : BaseLanguageData
	{
		[EditorHelp("Movement Factor", "Used for changing the speed of movements (e.g. player controls, enemy movements, etc.).", "")]
		[EditorFoldout("Time Factor Settings", "The different time factors are used " +
			"to change the time behaviour of different parts of the game. E.g.:\n" +
			"- A factor of 1 represents normal time flow.\n" +
			"- A factor of 2 will double the time speed resulting in things happening twice as fast.\n" +
			"- A factor of 0.5 will halve the time speed resulting in things happening halve as fast.", "")]
		public float movementFactor = 1;

		[EditorHelp("Battle Factor", "Used for changing the speed of battles and battle related things (e.g. status effects).", "")]
		public float battleFactor = 1;

		[EditorHelp("Animation Factor", "Used for changing animation speed.", "")]
		[EditorEndFoldout]
		public float animationFactor = 1;


		// factions
		[EditorFoldout("Faction Settings", "The different multiplier settings are used " +
			"to multiply the initial status values, attack and defence modifiers of all members of a selected faction.\n" +
			"E.g.:\n" +
			"- A multiplier of 1 represents the default values.\n" +
			"- A multiplier of 2 represents doubled values, e.g. if settings the MaxHP multiplier " +
			"to 2 will result in combatants having twice the HP as normally.\n" +
			"- A multiplier of 0.5 represents half values, e.g. if setting the EXP multiplier " +
			"to 0.5 will result in combatants giving half the EXP as normally.\n", "")]
		[EditorEndFoldout]
		[EditorArray("Add Faction Multipliers", "Add a faction bonus setting.\n" +
			"All members of the selected faction will have their initial values multiplied by the defined values.", "",
			"Remove", "Removes this faction bonus.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Faction Multipliers",
				"All members of the selected faction will have their initial values multiplied by the defined values.", ""
		})]
		public DifficultyFaction[] faction = new DifficultyFaction[0];


		// variables
		[EditorFoldout("Variable Changes", "Define variable changes that will be used when changing to this difficulty.")]
		[EditorEndFoldout]
		public VariableSetter<GameObjectSelection> variableChanges = new VariableSetter<GameObjectSelection>();


		public Difficulty()
		{

		}

		public Difficulty(string name) : base(name)
		{

		}

		public virtual void UseChanges()
		{
			this.variableChanges.SetVariables(new DataCall());
		}


		/*
		============================================================================
		Faction functions
		============================================================================
		*/
		public DifficultyFaction GetMultipliers(FactionSetting faction)
		{
			for(int i = 0; i < this.faction.Length; i++)
			{
				if(this.faction[i].faction.Is(faction))
				{
					return this.faction[i];
				}
			}
			return null;
		}
	}
}
