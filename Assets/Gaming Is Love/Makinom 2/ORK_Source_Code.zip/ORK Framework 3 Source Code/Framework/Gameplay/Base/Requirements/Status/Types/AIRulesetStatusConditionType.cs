﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.AI;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("AI Ruleset", "A defined AI ruleset must or mustn't be equipped on an AI ruleset slot.")]
	public class AIRulesetStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("AI Ruleset", "Select the AI ruleset that will be used.", "")]
		public AssetSelection<AIRulesetAsset> ruleset = new AssetSelection<AIRulesetAsset>();

		[EditorHelp("Is Equipped", "The AI ruleset must be equipped in one of the combatant's AI slots.\n" +
			"If disabled, the AI ruleset mustn't be equipped.", "")]
		public bool isEquipped = true;

		public AIRulesetStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.ruleset.ToString() + (this.isEquipped ? " is equipped" : " not equipped");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.ruleset.StoredAsset != null &&
				combatant.AI.IsAIRulesetEquipped(this.ruleset.StoredAsset.Settings) == this.isEquipped;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AIChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AIChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.AIChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.AIChangedSimple -= notify;
		}
	}
}
