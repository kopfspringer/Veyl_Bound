
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Animations
{
	public class ORKLegacyAnimation : BaseData, IFoldoutInfo
	{
		[EditorHelp("Animation Type", "Select the animation type of this animation.", "")]
		public AssetSelection<AnimationTypeAsset> type = new AssetSelection<AnimationTypeAsset>();

		[EditorHelp("Stop Fade (s)", "The time in seconds used to fade out before stopping the animation.\n" +
			"Set to 0 if the animation should stop immediately.", "")]
		[EditorLimit(0.0f, false)]
		public float stopFade = 0.1f;

		[EditorArray("Add Animation", "Adds an animation - one of the added animations will be played randomly.\n", "",
			"Remove", "Remove this animation.", "",
			isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Animation", "Define the legacy animation setup that will be used.\n" +
				"One of the added animations will be played randomly for the defined animation type.", ""
			})]
		public LegacyAnimationBase[] animation = new LegacyAnimationBase[] { new LegacyAnimationBase() };

		public ORKLegacyAnimation()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("name"))
			{
				this.animation[0].SetData(data);
			}
		}

		public virtual string GetFoldoutInfo()
		{
			return this.type.ToString();
		}

		public virtual void Init(Combatant combatant, Animation animation)
		{
			for(int i = 0; i < this.animation.Length; i++)
			{
				this.animation[i].Init(combatant, animation);
			}
		}

		public virtual AnimInfo Play(Animation animation, bool randomTime)
		{
			if(this.animation.Length == 1)
			{
				return this.animation[0].Play(animation, randomTime);
			}
			else
			{
				int index = Random.Range(0, this.animation.Length);
				if(this.animation[index].HasPlay(animation))
				{
					return this.animation[index].Play(animation, randomTime);
				}
				else
				{
					for(int i = 0; i < this.animation.Length; i++)
					{
						if(i != index &&
							this.animation[i].HasPlay(animation))
						{
							return this.animation[i].Play(animation, randomTime);
						}
					}
				}
				return AnimInfo.None;
			}
		}

		public virtual void RemoveStop(Combatant combatant)
		{
			for(int i = 0; i < this.animation.Length; i++)
			{
				combatant.Animations.LegacyRemoveStop(this.animation[i].name);
			}
		}

		public virtual void Stop(Animation animation, Combatant user)
		{
			for(int i = 0; i < this.animation.Length; i++)
			{
				this.animation[i].Stop(animation, user, this.stopFade);
			}
		}
	}
}
