﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CameraControlTargetTransition : BaseData
	{
		[EditorHelp("Use Transition", "Use a transition when changing to a new camera control target.", "")]
		public bool enabled = false;

		[EditorHelp("Transition Time (s)", "The time in seconds used to transition to the new camera control target.", "")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("enabled", true)]
		public float time = 1.0f;

		[EditorHelp("Per World Unit", "The transition time is per world unit distance between current and new camera control target.\n" +
			"E.g. a distance of 2 world units would multiply the transition time by 2.", "")]
		public bool perWorldUnit = false;


		// position
		[EditorHelp("Use Position", "Transition the camera position.", "")]
		public bool usePosition = true;

		[EditorHelp("Position Interpolation", "The interpolation used for the position transition.", "")]
		[EditorCondition("usePosition", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public Interpolation positionInterpolation;


		// rotation
		[EditorHelp("Use Rotation", "Transition the camera rotation.", "")]
		public bool useRotation = true;

		[EditorHelp("Rotation Interpolation", "The interpolation used for the rotation transition.", "")]
		[EditorCondition("useRotation", true)]
		[EditorEndCondition(2)]
		[EditorAutoInit]
		public Interpolation rotationInterpolation;


		// in-game
		private Interpolation.Vector3Instance positionInterpolationInstance;

		private Interpolation.QuaternionInstance rotationInterpolationInstance;

		private float duration = 0;

		public CameraControlTargetTransition()
		{

		}

		public float Duration
		{
			get { return this.duration; }
		}


		/*
		============================================================================
		Transition functions
		============================================================================
		*/
		public void StartTransition(Transform transform, float distance)
		{
			this.duration = this.perWorldUnit ? this.time * distance : this.time;

			if(this.usePosition)
			{
				if(this.positionInterpolationInstance == null)
				{
					this.positionInterpolationInstance = this.positionInterpolation.CreateVector3();
				}
				this.positionInterpolationInstance.ElapsedTime = 0;
				this.positionInterpolationInstance.Duration = this.duration;
				this.positionInterpolationInstance.Start = transform.position;
			}
			if(this.useRotation)
			{
				if(this.rotationInterpolationInstance == null)
				{
					this.rotationInterpolationInstance = this.rotationInterpolation.CreateQuaternion();
				}
				this.rotationInterpolationInstance.ElapsedTime = 0;
				this.rotationInterpolationInstance.Duration = this.duration;
				this.rotationInterpolationInstance.Start = transform.rotation;
			}
		}

		public bool Transition(Transform transform, Vector3 position, Quaternion rotation, float deltaTime, float elapsedTime)
		{
			if(this.usePosition && this.useRotation)
			{
				if(this.positionInterpolationInstance != null &&
					this.rotationInterpolationInstance != null)
				{
					this.positionInterpolationInstance.Target = position;
					this.rotationInterpolationInstance.Target = rotation;
					transform.SetPositionAndRotation(this.positionInterpolationInstance.Tick(deltaTime),
						this.rotationInterpolationInstance.Tick(deltaTime));
				}
			}
			else
			{
				if(this.usePosition &&
					this.positionInterpolationInstance != null)
				{
					this.positionInterpolationInstance.Target = position;
					transform.position = this.positionInterpolationInstance.Tick(deltaTime);
				}
				if(this.useRotation &&
					this.rotationInterpolationInstance != null)
				{
					this.rotationInterpolationInstance.Target = rotation;
					transform.rotation = this.rotationInterpolationInstance.Tick(deltaTime);
				}
			}

			return elapsedTime >= this.duration;
		}
	}
}
