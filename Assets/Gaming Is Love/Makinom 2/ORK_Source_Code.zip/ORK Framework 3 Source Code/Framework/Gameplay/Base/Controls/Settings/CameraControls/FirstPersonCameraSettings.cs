﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class FirstPersonCameraSettings : BaseData
	{
		[EditorHelp("Child Object", "Use a child object to position the camera.", "")]
		public ChildObjectSettings childObject = new ChildObjectSettings();

		[EditorHelp("Use Unscaled Time", "Use unscaled delta time.\n" +
			"I.e. the camera control is not affected when changing the timescale.", "")]
		public bool useUnscaledTime = false;

		[EditorHelp("Offset", "The offset added to the player/child position when placing the camera.", "")]
		[EditorSeparator]
		public Vector3 offset = Vector3.zero;

		[EditorHelp("Lock Cursor", "The mouse cursor will be locked when the camera control is enabled " +
			"(i.e. the mouse cursor is centered in the screen, hidden and can't be moved).", "")]
		[EditorSeparator]
		public bool lockCursor = false;


		// vertical
		[EditorFoldout("Vertical Input Axis", "Define the settings for the camera's vertical input axis.\n" +
			"Vertical camera changes will turn the camera along the X-axis.")]
		public AxisControl verticalInputAxis = new AxisControl();

		[EditorHelp("Vertical Sensitivity", "The sensitivity of vertical camera moves.", "")]
		public FloatValue<GameObjectSelection> verticalSensitivity = new FloatValue<GameObjectSelection>(15);

		[EditorSeparator]
		[EditorTitleLabel("Invert Vertical")]
		[EditorEndFoldout]
		public BoolValue<GameObjectSelection> verticalInvert = new BoolValue<GameObjectSelection>();


		// horizontal
		[EditorFoldout("Horizontal Input Axis", "Define the settings for the camera's vertical input axis.\n" +
			"Horizontal camera changes will turn the camera along the Y-axis.")]
		public AxisControl horizontalInputAxis = new AxisControl();

		[EditorHelp("Horizontal Sensitivity", "The sensitivity of horizontal camera moves.", "")]
		public FloatValue<GameObjectSelection> horizontalSensitivity = new FloatValue<GameObjectSelection>(15);

		[EditorSeparator]
		[EditorTitleLabel("Invert Horizontal")]
		[EditorEndFoldout]
		public BoolValue<GameObjectSelection> horizontalInvert = new BoolValue<GameObjectSelection>();

		public FirstPersonCameraSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.childObject.Upgrade(data, "onChild");
			this.verticalInputAxis.UpgradeOldAxis(data, "verticalAxis");
			this.horizontalInputAxis.UpgradeOldAxis(data, "horizontalAxis");
		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				FirstPersonCamera comp = camera.GetComponent<FirstPersonCamera>();
				if(comp == null)
				{
					comp = camera.AddComponent<FirstPersonCamera>();
					comp.settings.SetData(this.GetData());
				}
				if(comp != null)
				{
					Maki.Control.AddCameraControl(comp);
				}
			}
		}
	}
}
