﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.UI
{
	public enum ORKContentLayoutType { Text, Icon, TextAndIcon, Custom, Info, LevelUpCost, None }

	public enum ORKIconContentType { Icon, TypeIcon, IconFallback, TypeIconFallback }

	public class ORKContentLayout : BaseData, IContentLayout
	{
		[EditorHelp("Content Type", "Select the content type:\n" +
			"- Text: Only texts will be displayed.\n" +
			"- Icon: Only icons will be displayed.\n" +
			"- Text And Icon: Text and icons will be displayed.\n" +
			"- Custom: Define the layout in a text area using text codes.\n" +
			"- Info: The default info of the displayed content (same as '<info>' text code).\n" +
			"- Level Up Cost: The level up costs of the displayed content (same as '<levelupcost> text code).\n" +
			"- None: Nothing (e.g. only show HUD content).")]
		public ORKContentLayoutType type = ORKContentLayoutType.TextAndIcon;

		[EditorHelp("Icon Type", "Select which icon will be used:\n" +
			"- Icon: The content's icon.\n" +
			"- Type Icon: The content's type icon (no icon if no type is available).\n" +
			"- Icon Fallback: The content's icon, if no icon is available, the content's type icon.\n" +
			"- Type Icon Fallback: The content's type icon, if no icon is available the content's icon.")]
		[EditorCondition("type", ORKContentLayoutType.Icon)]
		[EditorCondition("type", ORKContentLayoutType.TextAndIcon)]
		[EditorCondition(new string[] { "type", "customAddIcon" },
			new object[] { ORKContentLayoutType.Custom, true })]
		[EditorEndCondition]
		public ORKIconContentType iconType = ORKIconContentType.Icon;

		[EditorHelp("Use Content Variables", "Variable text codes use the variables of the displayed content.\n" +
			"If the content doesn't have variables, the variable text codes will be replaced by default values (e.g. int/float '0', bool 'false', etc.).")]
		public bool useContentVariables = false;


		// HUD
		[EditorSeparator]
		public AddUIKeyHUD addHUD = new AddUIKeyHUD();


		// custom
		[EditorHelp("Add Icon", "Add the content's icon, i.e. like 'Text And Icon' with custom text.")]
		[EditorSeparator]
		[EditorCondition("type", ORKContentLayoutType.Custom)]
		public bool customAddIcon = false;

		[EditorHelp("Remove Empty Lines", "Remove empty lines from the text.")]
		public bool removeEmptyLines = false;

		[EditorHelp("Content Text", "The text used to display the content.")]
		[EditorLabel("<name> = name, <shortname> = short name, <description> = description, <icon> = icon, <customcontent=KEY> = custom content 'KEY'\n" +
			"<typename> = type name, <typeshortname> = type short name, <typedescription> = type description, <typeicon> = type icon, <typecustomcontent=KEY> = type custom content 'KEY'\n" +
			"<level> = ability level, equipment level, combatant level (combatant, bestiary)\n" +
			"<quantity> = quantity, <quantityinventory> = quantity in inventory, <quantitymax> = max allowed quantity, <levelupcost> = level up costs\n" +
			"<buyprice> = buy price (x1), <totalbuyprice> = total buy price (x quantity)\n" +
			"<sellprice> = sell price (x1), <totalsellprice> = total sell price (x quantity)\n" +
			"<usecost> = use cost text\n" +
			"<usecount> = use count, <usecountmax> = maximum use count\n" +
			"<reuse> = reuse time/turns, <reuse1> = with 1 decimal (0.0), <reuse2> = with 2 decimal (0.00)\n" +
			"<info> = default info, e.g. quantity, use costs, level (bestiary, combatant)\n" +
			"Ability, Item:\n" +
			"<userchanges> = status changes for the user (including use costs)\n" +
			"<targetchanges> = status changes for the target (using dummy target combatant)" +
			"Combatant:\n" +
			"<classname> = name, <classshortname> = short name, <classdescription> = description, <classicon> = icon, <classcustomcontent=KEY> = custom content 'KEY'\n" +
			"<level> = level, <classlevel> = class level\n" +
			"<factiontext0> = faction text 0, <factiontext1> = faction text 1, ...")]
		[EditorEndCondition]
		[EditorAutoInit]
		[EditorLanguageExport("CustomContentLayout")]
		public LanguageData<TextContent> customContent;

		public ORKContentLayout()
		{

		}

		public ORKContentLayout(ORKContentLayoutType type)
		{
			this.type = type;
			if(ORKContentLayoutType.Custom == this.type)
			{
				this.customContent = new LanguageData<TextContent>();
			}
		}

		public ORKContentLayout(string customContent)
		{
			this.type = ORKContentLayoutType.Custom;
			this.customContent = new LanguageData<TextContent>(customContent);
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual bool Contains(string text)
		{
			return ORKContentLayoutType.Custom == this.type &&
				this.customContent.Current.text.Contains(text);
		}

		protected virtual void FinalSetup(UIText text, IVariableSource variables)
		{
			if(this.useContentVariables)
			{
				text.ReplaceVariables(variables != null && variables.HasVariables ? variables.Variables : null);
			}
		}


		/*
		============================================================================
		Text functions
		============================================================================
		*/
		protected virtual UIText GetCustomText(string name, Sprite iconSprite, Texture iconTexture)
		{
			UIText text = this.customContent.Current;
			if(this.customAddIcon)
			{
				text.sprite = iconSprite;
				text.texture = iconTexture;
			}
			if(text.Contains("<"))
			{
				text.Replace("<reuse2>", "");
				text.Replace("<reuse1>", "");
				text.Replace("<reuse>", "");

				text.Replace("<name>", name);
				text.Replace("<shortname>", name);
				text.ReplaceContent(null);
				text.Replace("<level>", "");
				text.Replace("<classlevel>", "");
				text.Replace("<quantity>", "");
				text.Replace("<quantityinventory>", "");
				text.Replace("<quantitymax>", "");
				text.Replace("<totalbuyprice>", "");
				text.Replace("<buyprice>", "");
				text.Replace("<totalsellprice>", "");
				text.Replace("<sellprice>", "");
				text.Replace("<usecost>", "");
				text.Replace("<usecount>", "");
				text.Replace("<usecountmax>", "");
				text.Replace("<userchanges>", "");
				text.Replace("<targetchanges>", "");
				text.Replace("<levelupcost>", "");
				text.Replace("<info>", "");

				text.ReplaceContent(null,
					"<classname>", "<classshortname>", "<classdescription>", "<classicon>", "<classcustomcontent=",
					"", "", "", "", "");
				FactionSetting.ReplaceFactionTextsEmpty(text);

				ResearchItem.ReplaceProgressCountsEmpty(text);
			}
			if(this.removeEmptyLines)
			{
				text.RemoveEmptyLines();
			}
			return text;
		}

		protected virtual UIText GetCustomText(Combatant combatant, object content,
			IContent contentInfo, IContent typeContentInfo,
			string quantity, string inventoryQuantity, string quantityMax, string buyPrice, string sellPrice,
			string totalBuyPrice, string totalSellPrice,
			string level, string classLevel, string levelUpCost,
			string useCost, string useCount, string useCountMax, string userChanges, string targetChanges, string info)
		{
			UIText text = this.customContent.Current;
			this.GetText(text,
				combatant, content, contentInfo, typeContentInfo,
				quantity, inventoryQuantity, quantityMax, buyPrice, sellPrice,
				totalBuyPrice, totalSellPrice,
				level, classLevel, levelUpCost, useCost, useCount, useCountMax, userChanges, targetChanges, info);
			return text;
		}

		protected virtual void GetText(UIText text, Combatant combatant, object content,
			IContent contentInfo, IContent typeContentInfo,
			string quantity, string inventoryQuantity, string quantityMax, string buyPrice, string sellPrice,
			string totalBuyPrice, string totalSellPrice,
			string level, string classLevel, string levelUpCost,
			string useCost, string useCount, string useCountMax, string userChanges, string targetChanges, string info)
		{
			if(this.customAddIcon)
			{
				this.SetIcons(text, contentInfo, typeContentInfo);
			}
			if(text.Contains("<"))
			{
				IReuseTime reuseTime = content as IReuseTime;
				if(reuseTime != null &&
					combatant != null)
				{
					text.Replace("<reuse2>", reuseTime.GetReuseTimeText(combatant, 2));
					text.Replace("<reuse1>", reuseTime.GetReuseTimeText(combatant, 1));
					text.Replace("<reuse>", reuseTime.GetReuseTimeText(combatant, 0));
				}
				else
				{
					text.Replace("<reuse2>", "");
					text.Replace("<reuse1>", "");
					text.Replace("<reuse>", "");
				}

				text.ReplaceContent(contentInfo, typeContentInfo);
				text.Replace("<level>", level);
				text.Replace("<classlevel>", classLevel);
				text.Replace("<quantity>", quantity);
				text.Replace("<quantityinventory>", inventoryQuantity);
				text.Replace("<quantitymax>", quantityMax);
				text.Replace("<totalbuyprice>", totalBuyPrice);
				text.Replace("<buyprice>", buyPrice);
				text.Replace("<totalsellprice>", totalSellPrice);
				text.Replace("<sellprice>", sellPrice);
				text.Replace("<usecost>", useCost);
				text.Replace("<usecount>", useCount);
				text.Replace("<usecountmax>", useCountMax);
				text.Replace("<userchanges>", userChanges);
				text.Replace("<targetchanges>", targetChanges);
				text.Replace("<levelupcost>", levelUpCost);
				text.Replace("<info>", info);

				if(content is ResearchItem)
				{
					((ResearchItem)content).ReplaceProgressCounts(text);
				}
				else
				{
					ResearchItem.ReplaceProgressCountsEmpty(text);
				}

				if(content is Combatant)
				{
					Combatant tmp = (Combatant)content;
					text.ReplaceContent(tmp.Class.Current,
						"<classname>", "<classshortname>", "<classdescription>", "<classicon>", "<classcustomcontent=",
						"", "", "", "", "");
					tmp.Faction.ReplaceFactionTexts(text);
				}
				else
				{
					text.ReplaceContent(null,
						"<classname>", "<classshortname>", "<classdescription>", "<classicon>", "<classcustomcontent=",
						"", "", "", "", "");
					FactionSetting.ReplaceFactionTextsEmpty(text);
				}
			}
			if(this.removeEmptyLines)
			{
				text.RemoveEmptyLines();
			}
		}

		protected virtual void GetText(UIText text, Combatant combatant, object content,
			IContent contentInfo, IContent typeContentInfo, Sprite iconSprite, Texture iconTexture,
			string quantity, string inventoryQuantity, string quantityMax, string buyPrice, string sellPrice,
			string totalBuyPrice, string totalSellPrice,
			string level, string classLevel, string levelUpCost,
			string useCost, string useCount, string useCountMax, string userChanges, string targetChanges, string info)
		{
			if(this.customAddIcon)
			{
				text.sprite = iconSprite;
				text.texture = iconTexture;
			}
			if(text.Contains("<"))
			{
				IReuseTime reuseTime = content as IReuseTime;
				if(reuseTime != null &&
					combatant != null)
				{
					text.Replace("<reuse2>", reuseTime.GetReuseTimeText(combatant, 2));
					text.Replace("<reuse1>", reuseTime.GetReuseTimeText(combatant, 1));
					text.Replace("<reuse>", reuseTime.GetReuseTimeText(combatant, 0));
				}
				else
				{
					text.Replace("<reuse2>", "");
					text.Replace("<reuse1>", "");
					text.Replace("<reuse>", "");
				}

				text.ReplaceContent(contentInfo, typeContentInfo);
				text.Replace("<level>", level);
				text.Replace("<classlevel>", classLevel);
				text.Replace("<quantity>", quantity);
				text.Replace("<quantityinventory>", inventoryQuantity);
				text.Replace("<quantitymax>", quantityMax);
				text.Replace("<totalbuyprice>", totalBuyPrice);
				text.Replace("<buyprice>", buyPrice);
				text.Replace("<totalsellprice>", totalSellPrice);
				text.Replace("<sellprice>", sellPrice);
				text.Replace("<usecost>", useCost);
				text.Replace("<usecount>", useCount);
				text.Replace("<usecountmax>", useCountMax);
				text.Replace("<userchanges>", userChanges);
				text.Replace("<targetchanges>", targetChanges);
				text.Replace("<levelupcost>", levelUpCost);
				text.Replace("<info>", info);

				if(content is ResearchItem)
				{
					((ResearchItem)content).ReplaceProgressCounts(text);
				}
				else
				{
					ResearchItem.ReplaceProgressCountsEmpty(text);
				}

				if(content is Combatant)
				{
					Combatant tmp = (Combatant)content;
					text.ReplaceContent(tmp.Class.Current,
						"<classname>", "<classshortname>", "<classdescription>", "<classicon>", "<classcustomcontent=",
						"", "", "", "", "");
					tmp.Faction.ReplaceFactionTexts(text);
				}
				else
				{
					text.ReplaceContent(null,
						"<classname>", "<classshortname>", "<classdescription>", "<classicon>", "<classcustomcontent=",
						"", "", "", "", "");
					FactionSetting.ReplaceFactionTextsEmpty(text);
				}
			}
			if(this.removeEmptyLines)
			{
				text.RemoveEmptyLines();
			}
		}


		/*
		============================================================================
		Icon functions
		============================================================================
		*/
		public virtual void SetIcons(UIText text, IContent content, IContent typeContent)
		{
			if(ORKIconContentType.Icon == this.iconType)
			{
				if(content != null)
				{
					text.sprite = content.GetIconSprite();
					text.texture = content.GetIconTexture();
				}
			}
			else if(ORKIconContentType.TypeIcon == this.iconType)
			{
				if(typeContent != null)
				{
					text.sprite = typeContent.GetIconSprite();
					text.texture = typeContent.GetIconTexture();
				}
			}
			else if(ORKIconContentType.IconFallback == this.iconType)
			{
				if(content != null)
				{
					text.sprite = content.GetIconSprite();
					text.texture = content.GetIconTexture();
				}
				if(typeContent != null)
				{
					if(text.sprite == null)
					{
						text.sprite = typeContent.GetIconSprite();
					}
					if(text.texture == null)
					{
						text.texture = typeContent.GetIconTexture();
					}
				}
			}
			else if(ORKIconContentType.TypeIconFallback == this.iconType)
			{
				if(typeContent != null)
				{
					text.sprite = typeContent.GetIconSprite();
					text.texture = typeContent.GetIconTexture();
				}
				if(content != null)
				{
					if(text.sprite == null)
					{
						text.sprite = content.GetIconSprite();
					}
					if(text.texture == null)
					{
						text.texture = content.GetIconTexture();
					}
				}
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public virtual void UpdateContent(UIText content)
		{
			if(ORKContentLayoutType.Text == this.type)
			{
				content.sprite = null;
				content.texture = null;
			}
			else if(ORKContentLayoutType.Icon == this.type ||
				ORKContentLayoutType.Info == this.type ||
				ORKContentLayoutType.LevelUpCost == this.type)
			{
				content.text = "";
			}
			else if(ORKContentLayoutType.Custom == this.type)
			{
				content.Set(this.GetCustomText(content.text, content.sprite, content.texture));
			}
			else if(ORKContentLayoutType.None == this.type)
			{
				content.sprite = null;
				content.texture = null;
				content.text = "";
			}
		}

		public virtual void UpdateContent(UIText text, IShortcut content, IContent typeContent, Combatant combatant, string info)
		{
			Currency currency = ORK.Currencies.Get(0);
			string level = "";
			string classLevel = "";
			string useCount = "";
			string useCountMax = "";
			string userChanges = "";
			string targetChanges = "";
			if(content is AbilityShortcut)
			{
				AbilityShortcut ability = (AbilityShortcut)content;
				level = ability.LevelFormatted;
				if(ability.HasUseCount)
				{
					useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.MaxUseCount);
					useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.UseCount);
				}
				if(this.Contains("<userchanges>"))
				{
					userChanges = ORK.TextDisplaySettings.GetUserChanges(ability, combatant, false);
				}
				if(this.Contains("<targetchanges>"))
				{
					targetChanges = ORK.TextDisplaySettings.GetTargetChanges(ability, combatant, false);
				}
			}
			else if(content is AbilityLinkShortcut)
			{
				AbilityShortcut ability = ((AbilityLinkShortcut)content).Shortcut;
				level = ability.LevelFormatted;
				if(ability.HasUseCount)
				{
					useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.MaxUseCount);
					useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.UseCount);
				}
				if(this.Contains("<userchanges>"))
				{
					userChanges = ORK.TextDisplaySettings.GetUserChanges(ability, combatant, false);
				}
				if(this.Contains("<targetchanges>"))
				{
					targetChanges = ORK.TextDisplaySettings.GetTargetChanges(ability, combatant, false);
				}
			}
			else if(content is ItemShortcut)
			{
				ItemShortcut item = (ItemShortcut)content;
				if(item.HasUseCount)
				{
					useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(item.MaxUseCount);
					useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(item.UseCount);
				}
				if(this.Contains("<userchanges>"))
				{
					userChanges = ORK.TextDisplaySettings.GetUserChanges(item, combatant, false);
				}
				if(this.Contains("<targetchanges>"))
				{
					targetChanges = ORK.TextDisplaySettings.GetTargetChanges(item, combatant, false);
				}
			}
			else if(content is EquipShortcut)
			{
				level = ((EquipShortcut)content).LevelFormatted;
			}
			else if(content is CombatantShortcut)
			{
				CombatantShortcut combatantShortcut = (CombatantShortcut)content;
				level = combatantShortcut.Combatant.Status.LevelFormatted;
				classLevel = combatantShortcut.Combatant.Class.LevelFormatted;
			}
			else if(content is ClassShortcut)
			{
				level = ((ClassShortcut)content).LevelFormatted;
				classLevel = level;
			}
			else if(content is ShopWrapperShortcut)
			{
				currency = ((ShopWrapperShortcut)content).Currency;
				IShortcut tmpContent = ((ShopWrapperShortcut)content).Shortcut;
				if(tmpContent is AbilityShortcut)
				{
					AbilityShortcut ability = (AbilityShortcut)tmpContent;
					level = ability.LevelFormatted;
					if(ability.HasUseCount)
					{
						useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.MaxUseCount);
						useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.UseCount);
					}
					if(this.Contains("<userchanges>"))
					{
						userChanges = ORK.TextDisplaySettings.GetUserChanges(ability, combatant, false);
					}
					if(this.Contains("<targetchanges>"))
					{
						targetChanges = ORK.TextDisplaySettings.GetTargetChanges(ability, combatant, false);
					}
				}
				else if(tmpContent is ItemShortcut)
				{
					ItemShortcut item = (ItemShortcut)tmpContent;
					if(item.HasUseCount)
					{
						useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(item.MaxUseCount);
						useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(item.UseCount);
					}
					if(this.Contains("<userchanges>"))
					{
						userChanges = ORK.TextDisplaySettings.GetUserChanges(item, combatant, false);
					}
					if(this.Contains("<targetchanges>"))
					{
						targetChanges = ORK.TextDisplaySettings.GetTargetChanges(item, combatant, false);
					}
				}
				else if(tmpContent is EquipShortcut)
				{
					level = ((EquipShortcut)tmpContent).LevelFormatted;
				}
				else if(tmpContent is CombatantShortcut)
				{
					CombatantShortcut combatantShortcut = (CombatantShortcut)tmpContent;
					level = combatantShortcut.Combatant.Status.LevelFormatted;
					classLevel = combatantShortcut.Combatant.Class.LevelFormatted;
				}
				else if(tmpContent is ShopClassShortcut)
				{
					level = ((ShopClassShortcut)tmpContent).LevelFormatted;
					classLevel = level;
				}
			}

			string levelUpCost = content is ILevelUpCostText ?
				((ILevelUpCostText)content).GetLevelUpCostString(combatant) : "";

			IPriceShortcut price = content as IPriceShortcut;
			int priceQuantity = content.Quantity > 0 ? content.Quantity : 1;

			string useCost = content is IUseCostDisplay ?
				((IUseCostDisplay)content).GetUseCostText(combatant) : "";

			this.GetText(text, combatant, content,
				// content
				content, typeContent,
				// quantity, price
				ORK.TextDisplaySettings.quantityText.GetText(content),
				ORKTextHelper.GetInventoryQuantity(content),
				ORKTextHelper.GetMaxQuantity(combatant, content),
				price != null ? price.GetBuyPriceText(currency, combatant, 1, null) : "",
				price != null ? price.GetSellPriceText(currency, combatant, 1, null) : "",
				price != null ? price.GetBuyPriceText(currency, combatant, priceQuantity, null) : "",
				price != null ? price.GetSellPriceText(currency, combatant, priceQuantity, null) : "",
				// level, cost, info
				level, classLevel, levelUpCost, useCost, useCount, useCountMax, userChanges, targetChanges, info);

			this.FinalSetup(text, content as IVariableSource);
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual UIText GetContent(string content, object hudUser)
		{
			UIText contentText = null;
			if(ORKContentLayoutType.Text == this.type ||
				ORKContentLayoutType.TextAndIcon == this.type)
			{
				contentText = content;
			}
			else if(ORKContentLayoutType.None == this.type ||
				ORKContentLayoutType.Icon == this.type ||
				ORKContentLayoutType.Info == this.type ||
				ORKContentLayoutType.LevelUpCost == this.type)
			{
				contentText = "";
			}
			else if(ORKContentLayoutType.Custom == this.type)
			{
				contentText = this.GetCustomText(content, null, null);
			}
			this.addHUD.Add(contentText, hudUser, hudUser);
			this.FinalSetup(contentText, hudUser as IVariableSource);
			return contentText;
		}

		public virtual UIText GetContent(IContent content, IContent typeContent)
		{
			UIText contentText = null;
			if(ORKContentLayoutType.Text == this.type)
			{
				contentText = content.GetName();
			}
			else if(ORKContentLayoutType.Icon == this.type)
			{
				contentText = new UIText("");
				this.SetIcons(contentText, content, typeContent);
			}
			else if(ORKContentLayoutType.TextAndIcon == this.type)
			{
				contentText = new UIText(content.GetName());
				this.SetIcons(contentText, content, typeContent);
			}
			else if(ORKContentLayoutType.None == this.type ||
				ORKContentLayoutType.Info == this.type ||
				ORKContentLayoutType.LevelUpCost == this.type)
			{
				contentText = "";
			}
			else if(ORKContentLayoutType.Custom == this.type)
			{
				contentText = this.GetCustomText(null, content,
					// content
					content, typeContent,
					// quantity, price
					"", "", "", "", "", "", "",
					// level, cost, info
					"", "", "", "", "", "", "", "", "");
			}
			this.addHUD.Add(contentText, content, content);
			this.FinalSetup(contentText, content as IVariableSource);
			return contentText;
		}

		public virtual UIText GetContent(IShortcut content, IContent typeContent, Combatant combatant, DragShortcutWrapper wrapper, string info)
		{
			UIText contentText = null;
			if(ORKContentLayoutType.Text == this.type)
			{
				contentText = content.GetName();
			}
			else if(ORKContentLayoutType.Icon == this.type)
			{
				contentText = new UIText("");
				this.SetIcons(contentText, content, typeContent);
			}
			else if(ORKContentLayoutType.TextAndIcon == this.type)
			{
				contentText = new UIText(content.GetName());
				this.SetIcons(contentText, content, typeContent);
			}
			else if(ORKContentLayoutType.Info == this.type)
			{
				contentText = info;
			}
			else if(ORKContentLayoutType.LevelUpCost == this.type)
			{
				if(content is ILevelUpCostText)
				{
					contentText = ((ILevelUpCostText)content).GetLevelUpCostString(combatant);
				}
				else
				{
					contentText = "";
				}
			}
			else if(ORKContentLayoutType.Custom == this.type)
			{
				Currency currency = ORK.Currencies.Get(0);
				string level = "";
				string classLevel = "";
				string useCount = "";
				string useCountMax = "";
				string userChanges = "";
				string targetChanges = "";
				if(content is AbilityShortcut)
				{
					AbilityShortcut ability = (AbilityShortcut)content;
					level = ability.LevelFormatted;
					if(ability.HasUseCount)
					{
						useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.MaxUseCount);
						useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.UseCount);
					}
					if(this.Contains("<userchanges>"))
					{
						userChanges = ORK.TextDisplaySettings.GetUserChanges(ability, combatant, false);
					}
					if(this.Contains("<targetchanges>"))
					{
						targetChanges = ORK.TextDisplaySettings.GetTargetChanges(ability, combatant, false);
					}
				}
				else if(content is AbilityLinkShortcut)
				{
					AbilityShortcut ability = ((AbilityLinkShortcut)content).Shortcut;
					level = ability.LevelFormatted;
					if(ability.HasUseCount)
					{
						useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.MaxUseCount);
						useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.UseCount);
					}
					if(this.Contains("<userchanges>"))
					{
						userChanges = ORK.TextDisplaySettings.GetUserChanges(ability, combatant, false);
					}
					if(this.Contains("<targetchanges>"))
					{
						targetChanges = ORK.TextDisplaySettings.GetTargetChanges(ability, combatant, false);
					}
				}
				else if(content is ItemShortcut)
				{
					ItemShortcut item = (ItemShortcut)content;
					if(item.HasUseCount)
					{
						useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(item.MaxUseCount);
						useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(item.UseCount);
					}
					if(this.Contains("<userchanges>"))
					{
						userChanges = ORK.TextDisplaySettings.GetUserChanges(item, combatant, false);
					}
					if(this.Contains("<targetchanges>"))
					{
						targetChanges = ORK.TextDisplaySettings.GetTargetChanges(item, combatant, false);
					}
				}
				else if(content is EquipShortcut)
				{
					level = ((EquipShortcut)content).LevelFormatted;
				}
				else if(content is CombatantShortcut)
				{
					CombatantShortcut combatantShortcut = (CombatantShortcut)content;
					level = combatantShortcut.Combatant.Status.LevelFormatted;
					classLevel = combatantShortcut.Combatant.Class.LevelFormatted;
				}
				else if(content is ClassShortcut)
				{
					level = ((ClassShortcut)content).LevelFormatted;
					classLevel = level;
				}
				else if(content is ShopWrapperShortcut)
				{
					currency = ((ShopWrapperShortcut)content).Currency;
					IShortcut tmpContent = ((ShopWrapperShortcut)content).Shortcut;
					if(tmpContent is AbilityShortcut)
					{
						AbilityShortcut ability = (AbilityShortcut)tmpContent;
						level = ability.LevelFormatted;
						if(ability.HasUseCount)
						{
							useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.MaxUseCount);
							useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(ability.UseCount);
						}
						if(this.Contains("<userchanges>"))
						{
							userChanges = ORK.TextDisplaySettings.GetUserChanges(ability, combatant, false);
						}
						if(this.Contains("<targetchanges>"))
						{
							targetChanges = ORK.TextDisplaySettings.GetTargetChanges(ability, combatant, false);
						}
					}
					else if(tmpContent is ItemShortcut)
					{
						ItemShortcut item = (ItemShortcut)tmpContent;
						if(item.HasUseCount)
						{
							useCount = ORK.TextDisplaySettings.numberFormatting.FormatInt(item.MaxUseCount);
							useCountMax = ORK.TextDisplaySettings.numberFormatting.FormatInt(item.UseCount);
						}
						if(this.Contains("<userchanges>"))
						{
							userChanges = ORK.TextDisplaySettings.GetUserChanges(item, combatant, false);
						}
						if(this.Contains("<targetchanges>"))
						{
							targetChanges = ORK.TextDisplaySettings.GetTargetChanges(item, combatant, false);
						}
					}
					else if(tmpContent is EquipShortcut)
					{
						level = ((EquipShortcut)tmpContent).LevelFormatted;
					}
					else if(tmpContent is CombatantShortcut)
					{
						CombatantShortcut combatantShortcut = (CombatantShortcut)tmpContent;
						level = combatantShortcut.Combatant.Status.LevelFormatted;
						classLevel = combatantShortcut.Combatant.Class.LevelFormatted;
					}
					else if(tmpContent is ShopClassShortcut)
					{
						level = ((ShopClassShortcut)tmpContent).LevelFormatted;
						classLevel = level;
					}
				}

				string levelUpCost = content is ILevelUpCostText ?
					((ILevelUpCostText)content).GetLevelUpCostString(combatant) : "";

				IPriceShortcut price = content as IPriceShortcut;
				int priceQuantity = content.Quantity > 0 ? content.Quantity : 1;

				string useCost = content is IUseCostDisplay ?
					((IUseCostDisplay)content).GetUseCostText(combatant) : "";

				contentText = this.GetCustomText(combatant, content,
					// content
					content, typeContent,
					// quantity, price
					ORK.TextDisplaySettings.quantityText.GetText(content),
					ORKTextHelper.GetInventoryQuantity(content),
					ORKTextHelper.GetMaxQuantity(combatant, content),
					price != null ? price.GetBuyPriceText(currency, combatant, 1, null) : "",
					price != null ? price.GetSellPriceText(currency, combatant, 1, null) : "",
					price != null ? price.GetBuyPriceText(currency, combatant, priceQuantity, null) : "",
					price != null ? price.GetSellPriceText(currency, combatant, priceQuantity, null) : "",
					// level, cost, info
					level, classLevel, levelUpCost, useCost, useCount, useCountMax, userChanges, targetChanges, info);
			}
			else if(ORKContentLayoutType.None == this.type)
			{
				contentText = "";
			}
			this.addHUD.Add(contentText, wrapper, content);
			this.FinalSetup(contentText, content as IVariableSource);
			return contentText;
		}

		public virtual UIText GetContent(Combatant combatant, IContent typeContent)
		{
			UIText contentText = null;
			if(ORKContentLayoutType.Text == this.type)
			{
				contentText = combatant.GetName();
			}
			else if(ORKContentLayoutType.Icon == this.type)
			{
				contentText = new UIText("");
				this.SetIcons(contentText, combatant, typeContent);
			}
			else if(ORKContentLayoutType.TextAndIcon == this.type)
			{
				contentText = new UIText(combatant.GetName());
				this.SetIcons(contentText, combatant, typeContent);
			}
			else if(ORKContentLayoutType.Info == this.type)
			{
				contentText = combatant.Status.LevelFormatted;
			}
			else if(ORKContentLayoutType.LevelUpCost == this.type ||
				ORKContentLayoutType.None == this.type)
			{
				contentText = "";
			}
			else if(ORKContentLayoutType.Custom == this.type)
			{
				contentText = this.GetCustomText(null, combatant,
					// content
					combatant, typeContent,
					// quantity, price
					"", "", "", "", "", "", "",
					// level, cost, info
					combatant.Status.LevelFormatted, combatant.Class.LevelFormatted,
					"", "", "", "", "", "", combatant.Status.LevelFormatted);
			}
			if(this.addHUD.Has)
			{
				this.addHUD.Add(contentText, combatant, combatant);
			}
			this.FinalSetup(contentText, combatant);
			return contentText;
		}

		public virtual UIText GetContent(BestiaryEntry content, IContent typeContent)
		{
			UIText contentText = null;
			if(ORKContentLayoutType.Text == this.type)
			{
				contentText = content.GetName();
			}
			else if(ORKContentLayoutType.Icon == this.type)
			{
				contentText = new UIText("");
				this.SetIcons(contentText, content, typeContent);
			}
			else if(ORKContentLayoutType.TextAndIcon == this.type)
			{
				contentText = new UIText(content.GetName());
				this.SetIcons(contentText, content, typeContent);
			}
			else if(ORKContentLayoutType.Info == this.type)
			{
				contentText = content.Setting.FormatLevel(content.Level);
			}
			else if(ORKContentLayoutType.LevelUpCost == this.type ||
				ORKContentLayoutType.None == this.type)
			{
				contentText = "";
			}
			else if(ORKContentLayoutType.Custom == this.type)
			{
				string level = content.Setting.FormatLevel(content.Level);
				contentText = this.GetCustomText(null, content,
					// content
					content, typeContent,
					// quantity, price
					"", "", "", "", "", "", "",
					// level, cost, info
					level, content.Setting.FormatClassLevel(content.ClassLevel),
					"", "", "", "", "", "", level);
			}
			if(this.addHUD.Has)
			{
				this.addHUD.Add(contentText, content.GetCombatant(), content);
			}
			this.FinalSetup(contentText, content.GetCombatant());
			return contentText;
		}

		public virtual UIText GetContent(ResearchItem content, IContent typeContent, Combatant combatant)
		{
			UIText contentText = null;
			if(ORKContentLayoutType.Text == this.type)
			{
				contentText = content.GetName();
			}
			else if(ORKContentLayoutType.Icon == this.type)
			{
				contentText = new UIText("");
				this.SetIcons(contentText, content, typeContent);
			}
			else if(ORKContentLayoutType.TextAndIcon == this.type)
			{
				contentText = new UIText(content.GetName());
				this.SetIcons(contentText, content, typeContent);
			}
			else if(ORKContentLayoutType.Info == this.type)
			{
				contentText = CombatantContentHelper.Get(content, combatant);
			}
			else if(ORKContentLayoutType.LevelUpCost == this.type ||
				ORKContentLayoutType.None == this.type)
			{
				contentText = "";
			}
			else if(ORKContentLayoutType.Custom == this.type)
			{
				contentText = this.GetCustomText(combatant, content,
					// content
					content, typeContent,
					// quantity, price
					content.Setting.GetItemQuantityText(combatant), "",
					"", "", "", "", "",
					// level, cost, info
					"", "", "", content.GetUseCostText(combatant), "", "", "", "", CombatantContentHelper.Get(content, combatant));
			}
			this.addHUD.Add(contentText, content, content);
			this.FinalSetup(contentText, null);
			return contentText;
		}
	}
}
