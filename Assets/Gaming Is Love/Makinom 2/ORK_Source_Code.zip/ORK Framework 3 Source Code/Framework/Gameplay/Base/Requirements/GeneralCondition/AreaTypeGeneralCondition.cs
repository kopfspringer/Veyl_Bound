﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Area Type", "Check the current area type.")]
	public class AreaTypeGeneralCondition<T> : BaseGeneralCondition<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Area Type", "Select the area type that will be checked for.", "")]
		public AssetSelection<AreaTypeAsset> areaType = new AssetSelection<AreaTypeAsset>();

		[EditorHelp("Use Sub-Types", "The sub-types of the defined area type will also be checked.", "")]
		public bool useSubTypes = true;

		public AreaTypeGeneralCondition()
		{

		}

		public override string ToString()
		{
			return "Area Type" +
				(this.areaType.HasAsset ?
					" (" + this.areaType.ToString() + ")" :
					"");
		}

		public override bool Check(IDataCall call)
		{
			return this.areaType.StoredAsset != null &&
				ORK.Game.Area.IsType(this.areaType.StoredAsset.Settings, this.useSubTypes);
		}

		public override void Register(IDataCall call, Notify notify, ref List<VariableHandler> unregisterHandlers)
		{
			ORK.Game.AreaChanged += notify;
		}

		public override void Unregister(IDataCall call, Notify notify)
		{
			ORK.Game.AreaChanged -= notify;
		}
	}
}
