﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public interface ITimestamp
	{
		float Timestamp
		{
			get;
			set;
		}
	}
}
