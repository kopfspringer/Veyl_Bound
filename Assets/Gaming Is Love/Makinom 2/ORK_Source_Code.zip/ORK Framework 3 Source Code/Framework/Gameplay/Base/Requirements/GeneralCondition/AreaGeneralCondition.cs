﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Area", "Check the current area.")]
	public class AreaGeneralCondition<T> : BaseGeneralCondition<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Area", "Select the area that will be checked for.", "")]
		public AssetSelection<AreaAsset> area = new AssetSelection<AreaAsset>();

		public AreaGeneralCondition()
		{

		}

		public override string ToString()
		{
			return "Area" +
				(this.area.HasAsset ?
					" (" + this.area.ToString() + ")" :
					"");
		}

		public override bool Check(IDataCall call)
		{
			return this.area.Is(ORK.Game.Area);
		}

		public override void Register(IDataCall call, Notify notify, ref List<VariableHandler> unregisterHandlers)
		{
			ORK.Game.AreaChanged += notify;
		}

		public override void Unregister(IDataCall call, Notify notify)
		{
			ORK.Game.AreaChanged -= notify;
		}
	}
}
