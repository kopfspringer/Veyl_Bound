
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Animations
{
	public class ORKMecanimAnimation : BaseData, IFoldoutInfo
	{
		[EditorHelp("Animation Type", "Select the animation type of this animation.", "")]
		public AssetSelection<AnimationTypeAsset> type = new AssetSelection<AnimationTypeAsset>();

		[EditorArray("Add Animation", "Adds an animation - one of the added animations will be played randomly.\n", "",
			"Remove", "Remove this animation.", "",
			isCopy = true, isMove = true, noRemoveCount = 1,
			foldout = true, foldoutText = new string[] {
				"Animation", "Define the Mecanim animation setup that will be used.\n" +
				"One of the added animations will be played randomly for the defined animation type.", ""
			})]
		public MecanimAnimationBase[] animation = new MecanimAnimationBase[] { new MecanimAnimationBase() };

		public ORKMecanimAnimation()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<string>("name"))
			{
				this.animation[0].SetData(data);
			}
		}

		public virtual string GetFoldoutInfo()
		{
			return this.type.ToString();
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public virtual AnimInfo Play(Animator animator, bool randomTime)
		{
			return this.animation[Random.Range(0, this.animation.Length)].Play(animator, randomTime);
		}

		public virtual void Stop(Animator animator)
		{
			for(int i = 0; i < this.animation.Length; i++)
			{
				this.animation[i].Stop(animator);
			}
		}
	}
}
