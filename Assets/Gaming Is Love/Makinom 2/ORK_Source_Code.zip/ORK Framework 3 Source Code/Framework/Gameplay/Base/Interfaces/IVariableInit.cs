﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public interface IVariableInit
	{
		void InitVariables(Combatant combatant);
	}
}
