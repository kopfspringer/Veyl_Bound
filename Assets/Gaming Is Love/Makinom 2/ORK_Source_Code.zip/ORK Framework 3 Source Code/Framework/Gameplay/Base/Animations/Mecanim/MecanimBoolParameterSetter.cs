﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Animations
{
	public class MecanimBoolParameterSetter
	{
		public int hash = -1;

		public MecanimBoolParameterSetter(string name)
		{
			this.hash = Animator.StringToHash(name);
		}

		public void Set(Animator animator, bool value)
		{
			animator.SetBool(this.hash, value);
		}
	}
}
