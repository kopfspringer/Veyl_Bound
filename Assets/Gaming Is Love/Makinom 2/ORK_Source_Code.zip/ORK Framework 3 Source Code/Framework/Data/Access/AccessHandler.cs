﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Default", "Uses default access functionality for single player games.")]
	public class AccessHandler : BaseTypeData
	{
		protected ActionAccessHandler actionAccess;

		protected BattleAccessHandler battleAccess;

		protected CombatantAccessHandler combatantAccess;

		protected GroupAccessHandler groupAccess;

		protected InventoryAccessHandler inventoryAccess;

		public AccessHandler()
		{
			this.actionAccess = new ActionAccessHandler();
			this.battleAccess = new BattleAccessHandler();
			this.combatantAccess = new CombatantAccessHandler();
			this.groupAccess = new GroupAccessHandler();
			this.inventoryAccess = new InventoryAccessHandler();
		}
		
		
		/*
		============================================================================
		Access properties
		============================================================================
		*/
		public virtual ActionAccessHandler Action
		{
			get { return this.actionAccess; }
		}

		public virtual BattleAccessHandler Battle
		{
			get { return this.battleAccess; }
		}

		public virtual CombatantAccessHandler Combatant
		{
			get { return this.combatantAccess; }
		}

		public virtual GroupAccessHandler Group
		{
			get { return this.groupAccess; }
		}

		public virtual InventoryAccessHandler Inventory
		{
			get { return this.inventoryAccess; }
		}


		/*
		============================================================================
		Handler instantiation functions
		============================================================================
		*/
		public virtual ORKControlHandler CreateControlHandler()
		{
			return new ORKControlHandler();
		}

		public virtual CombatantHandler CreateCombatantHandler()
		{
			return new CombatantHandler();
		}

		public virtual ISaveGameHandler CreateSaveGameHandler()
		{
			return new ORKSaveGameHandler();
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		/// <summary>
		/// Called before ORK registers update handlers.
		/// </summary>
		public virtual void InitBeforeRegister()
		{

		}

		/// <summary>
		/// Called after ORK registers update handlers.
		/// </summary>
		public virtual void InitAfterRegister()
		{

		}
	}
}
