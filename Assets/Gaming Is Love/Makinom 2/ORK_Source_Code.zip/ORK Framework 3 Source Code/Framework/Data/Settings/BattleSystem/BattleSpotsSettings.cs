
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class BattleSpotsSettings : BaseSettings
	{
		// base settings
		[EditorHelp("Use Rotation", "Use the battle spot's rotation when spawning combatants.\n" +
			"If disabled, the rotation of a spawned combatant won't be changed.", "")]
		[EditorFoldout("Base Settings", "Base settings for battle spots.\n" +
			"Battle spots are used in arena battles when no a combatant needs a spot that hasn't been defined in the scene.\n" +
			"The combatants are placed at the positions of battle spots at the start of the battle.", "")]
		public bool useRotation = true;

		[EditorHelp("Use Scale", "Use the battle spot's scale (localScale) when spawning combatants.\n" +
			"If disabled, the scale of a spawned combatant won't be changed.", "")]
		public bool useScale = false;

		// place on ground
		[EditorHelp("Place On Ground", "The battle spots will be placed directly on the ground, using a raycast to find the ground.\n" +
			"If disabled, the battle spots will remain at their original position.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Raycast Settings")]
		public bool onGround = false;

		[EditorHelp("Distance", "The distance used for the raycast.", "")]
		[EditorCondition("onGround", true)]
		public float distance = 100.0f;

		[EditorHelp("Layer Mask", "The layer mask used for the raycast.\n" +
			"Select the layers that will be recognized as the ground.", "")]
		public LayerMask layerMask = -1;

		[EditorEndFoldout]
		[EditorSeparator]
		[EditorTitleLabel("Raycast Random Offset")]
		[EditorEndCondition]
		[EditorAutoInit]
		public RandomVector3 rayOffset;


		// player spots
		[EditorFoldout("Player Spots", "Default battle spots of the player group.", "")]
		[EditorLabel("The player spots should at least have the same number as the maximum battle group size.")]
		[EditorArray("Add Player Spot", "Adds a player battle spot.", "",
			"Remove", "Removes this player spot.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Member", "Define the default battle spot for this member of player groups.", ""
		})]
		public BattleSpotSettings[] playerSpot = new BattleSpotSettings[] {
			new BattleSpotSettings(new Vector3(0, 0, 3)),
			new BattleSpotSettings(new Vector3(-3, 0, 3)),
			new BattleSpotSettings(new Vector3(3, 0, 3))
		};

		[EditorFoldout("Additional Spot", "Define how additional spots exceeding the defined number of spots will be placed.")]
		[EditorEndFoldout]
		[EditorLabel("Additional battle spots are used when a spot exceeding the number of defined spots is needed.\n" +
			"Use the random offset to vary different positions.")]
		public BattleSpotSettings playerExtra = new BattleSpotSettings();

		[EditorEndFoldout]
		[EditorArray("Add Conditional Battle Spots", "Adds conditional battle spots.\n" +
			"They're used when a combatant matches defined conditions.", "",
			"Remove", "Removes these conditional battle spots.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Conditional Battle Spots", "Define the battle spots and conditions that must be valid.\n" +
				"Each combatant placed on battle spots is checked individually, " +
				"i.e. it's possible to combine battle spots from the default spots and different conditional battle spots.\n" +
				"Conditional battle spots are not used when a 'Battle' component uses placed battle spots or a combatant group member defines their own battle spot.", ""
		})]
		public ConditionalBattleSpots[] playerConditionalSpots = new ConditionalBattleSpots[0];


		// ally spots
		[EditorFoldout("Ally Spots", "Default battle spots of combatants who are allies of the player.", "")]
		[EditorArray("Add Ally Spot", "Adds a ally battle spot.", "",
			"Remove", "Removes this ally spot.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Member", "Define the default battle spot for this member of ally groups.", ""
		})]
		public BattleSpotSettings[] allySpot = new BattleSpotSettings[0];

		[EditorFoldout("Additional Spot", "Define how additional spots exceeding the defined number of spots will be placed.")]
		[EditorEndFoldout]
		[EditorLabel("Additional battle spots are used when a spot exceeding the number of defined spots is needed.\n" +
			"Use the random offset to vary different positions.")]
		public BattleSpotSettings allyExtra = new BattleSpotSettings();

		[EditorEndFoldout]
		[EditorArray("Add Conditional Battle Spots", "Adds conditional battle spots.\n" +
			"They're used when a combatant matches defined conditions.", "",
			"Remove", "Removes these conditional battle spots.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Conditional Battle Spots", "Define the battle spots and conditions that must be valid.\n" +
				"Each combatant placed on battle spots is checked individually, " +
				"i.e. it's possible to combine battle spots from the default spots and different conditional battle spots.\n" +
				"Conditional battle spots are not used when a 'Battle' component uses placed battle spots or a combatant group member defines their own battle spot.", ""
		})]
		public ConditionalBattleSpots[] allyConditionalSpots = new ConditionalBattleSpots[0];


		// enemy spots
		[EditorFoldout("Enemy Spots", "Default battle spots of combatants who are enemies of the player.", "")]
		[EditorArray("Add Enemy Spot", "Adds an enemy battle spot.", "",
			"Remove", "Removes this enemy spot.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Member", "Define the default battle spot for this member of enemy groups.", ""
		})]
		public BattleSpotSettings[] enemySpot = new BattleSpotSettings[] {
			new BattleSpotSettings(new Vector3(0, 0, -3)),
			new BattleSpotSettings(new Vector3(-3, 0, -3)),
			new BattleSpotSettings(new Vector3(3, 0, -3))
		};

		[EditorFoldout("Additional Spot", "Define how additional spots exceeding the defined number of spots will be placed.")]
		[EditorEndFoldout]
		[EditorLabel("Additional battle spots are used when a spot exceeding the number of defined spots is needed.\n" +
			"Use the random offset to vary different positions.")]
		public BattleSpotSettings enemyExtra = new BattleSpotSettings();

		[EditorEndFoldout]
		[EditorArray("Add Conditional Battle Spots", "Adds conditional battle spots.\n" +
			"They're used when a combatant matches defined conditions.", "",
			"Remove", "Removes these conditional battle spots.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Conditional Battle Spots", "Define the battle spots and conditions that must be valid.\n" +
				"Each combatant placed on battle spots is checked individually, " +
				"i.e. it's possible to combine battle spots from the default spots and different conditional battle spots.\n" +
				"Conditional battle spots are not used when a 'Battle' component uses placed battle spots or a combatant group member defines their own battle spot.", ""
		})]
		public ConditionalBattleSpots[] enemyConditionalSpots = new ConditionalBattleSpots[0];

		public BattleSpotsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Battle Spots"; }
		}


		/*
		============================================================================
		Battle spot functions
		============================================================================
		*/
		public virtual void SetPlayerSpot(Combatant combatant, int index, GroupAdvantageType advantage, Transform arenaTransform, Transform spotTransform)
		{
			// conditional
			for(int i = 0; i < this.playerConditionalSpots.Length; i++)
			{
				if(this.playerConditionalSpots[i].Use(combatant, index, advantage, arenaTransform, spotTransform))
				{
					return;
				}
			}
			// default
			if(index >= 0 && index < this.playerSpot.Length)
			{
				this.playerSpot[index].SetSpot(advantage, arenaTransform, spotTransform);
			}
			else
			{
				this.playerExtra.SetSpot(advantage, arenaTransform, spotTransform);
			}
		}

		public virtual void SetAllySpot(Combatant combatant, int index, GroupAdvantageType advantage, Transform arenaTransform, Transform spotTransform)
		{
			// conditional
			for(int i = 0; i < this.allyConditionalSpots.Length; i++)
			{
				if(this.allyConditionalSpots[i].Use(combatant, index, advantage, arenaTransform, spotTransform))
				{
					return;
				}
			}
			// default
			if(index >= 0 && index < this.allySpot.Length)
			{
				this.allySpot[index].SetSpot(advantage, arenaTransform, spotTransform);
			}
			else
			{
				this.allyExtra.SetSpot(advantage, arenaTransform, spotTransform);
			}
		}

		public virtual void SetEnemySpot(Combatant combatant, int index, GroupAdvantageType advantage, Transform arenaTransform, Transform spotTransform)
		{
			// conditional
			for(int i = 0; i < this.enemyConditionalSpots.Length; i++)
			{
				if(this.enemyConditionalSpots[i].Use(combatant, index, advantage, arenaTransform, spotTransform))
				{
					return;
				}
			}
			// default
			if(index >= 0 && index < this.enemySpot.Length)
			{
				this.enemySpot[index].SetSpot(advantage, arenaTransform, spotTransform);
			}
			else
			{
				this.enemyExtra.SetSpot(advantage, arenaTransform, spotTransform);
			}
		}
	}
}
