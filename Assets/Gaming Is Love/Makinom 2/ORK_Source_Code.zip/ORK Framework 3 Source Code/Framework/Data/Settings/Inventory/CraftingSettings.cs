﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CraftingSettings : BaseSettings
	{
		// prefab settings
		[EditorHelp("Own Prefab", "Override the default item prefab defined in the inventory settings.")]
		[EditorFoldout("Item Prefab Settings", "Define the prefab used to display crafting recipes in a scene.\n" +
			"Optionally use conditional prefabs to display different prefabs based on variable conditions.\n" +
			"Crafting recipes can override the default item prefab and this prefab.", "")]
		public bool ownPrefab = false;

		[EditorEndFoldout(2)]
		[EditorCondition("ownPrefab", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public ItemPrefabSettings prefabSettings;


		// audio settings
		[EditorFoldout("Default Audio Settings", "Define the default audio settings for all crafting recipes.\n" +
			"Optionally use audio clips for various crafting outcomes.\n" +
			"Each crafting recipe can override the default settings.")]
		[EditorEndFoldout]
		public CraftingAudioSettings audioSettings = new CraftingAudioSettings();


		// schematics
		[EditorFoldout("Crafting Schematics", "Crafting can optionally use schematics.")]
		[EditorEndFoldout]
		public CraftingSchematics craftingSchematics = new CraftingSchematics();


		// crafting layout
		[EditorFoldout("Default Recipe Layout", "The crafting recipe layout is used in " +
			"crafting menus to display information about a crafting recipe.\n" +
			"The default layout can be overridden by crafting recipes and crafting menus.", "")]
		[EditorEndFoldout]
		public CraftingRecipeLayout craftingLayout = new CraftingRecipeLayout();


		// notifications
		[EditorFoldout("Crafting Notifications", "Learning recipes and using them can display notifications.", "")]
		[EditorEndFoldout]
		public CraftingNotificationSettings notifications = new CraftingNotificationSettings();

		public CraftingSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Crafting Settings"; }
		}
	}
}
