
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class FactionsSettings : GenericAssetListSettings<FactionAsset, FactionSetting>
	{
		// sympathy settings
		[EditorHelp("Minimum Sympathy", "The minimum sympathy value a faction can reach.", "")]
		[EditorFoldout("Sympathy Settings", "A factions sympathy defines how combatants of the faction will react to other factions.\n" +
			"Negative sympathy values will make the faction an enemy, positive values will make it an ally.", "")]
		public float min = -1000;

		[EditorHelp("Maximum Sympathy", "The maximum sympathy value a faction can reach.", "")]
		[EditorEndFoldout]
		public float max = 1000;


		// sympathies
		[EditorFoldout("Faction Sympathies", "Define the starting sympathies between different factions.\n" +
			"If no faction sympathy is defined, the starting sympathy between them is 0.")]
		[EditorEndFoldout]
		[EditorArray("Add Faction Sympathy", "Add a start faction sympathy.", "",
			"Remove", "Remove this faction sympathy.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Faction Sympathy", "Define the factions and the sympathy between them.\n" + 
				"This will be used at the start of the game to set the initial sympathy between the factions.", ""
			})]
		public FactionSympathy[] sympathy = new FactionSympathy[0];

		public FactionsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Factions"; }
		}
	}
}

