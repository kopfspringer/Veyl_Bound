
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;
using GamingIsLove.ORKFramework.UI;

namespace GamingIsLove.ORKFramework
{
	public class BattleTextsSettings : BaseSettings
	{
		// text settings
		// all choice settings
		[EditorFoldout("Text Settings", "Base text and display settings.", "",
			"All Choice Settings", "Define the content of the all allies/enemies choices in target menus.", "",
			"All Allies Choice", "Name, description and icon for the choice to target all allies.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("AllAllies")]
		public ContentInputCustom allAlliesButton = new ContentInputCustom("All Allies");

		[EditorFoldout("All Enemies Choice", "Name, description and icon for the choice to target all enemies.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("AllEnemies")]
		public ContentInputCustom allEnemiesButton = new ContentInputCustom("All Enemies");

		[EditorFoldout("All Combatants Choice", "Name, description and icon for the choice to target all combatants.", "")]
		[EditorEndFoldout(2)]
		[EditorLanguageExport("AllCombatants")]
		public ContentInputCustom allCombatantsButton = new ContentInputCustom("All Combatants");

		// special commands
		[EditorFoldout("Special Command Content", "Define the content information of special commands, e.g. escape or defend.", "",
			"Escape Command", "Name, description and icon for the escape command.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("EscapeCommand")]
		public LanguageContentInformation escapeCommandContent = new LanguageContentInformation("Escape");

		[EditorFoldout("Defend Command", "Name, description and icon for the defend command.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("DefendCommand")]
		public LanguageContentInformation defendCommandContent = new LanguageContentInformation("Defend");

		[EditorFoldout("None Command", "Name, description and icon for the none command (end turn).", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("NoneCommand")]
		public LanguageContentInformation noneCommandContent = new LanguageContentInformation("End Turn");

		[EditorFoldout("Change Member Command", "Name, description and icon for the change member command.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("ChangeMemberCommand")]
		public LanguageContentInformation changeMemberCommandContent = new LanguageContentInformation("Change Member");

		[EditorFoldout("Join Battle", "Name, description and icon for the join battle action.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("JoinBattle")]
		public LanguageContentInformation joinBattleContent = new LanguageContentInformation("Joining");

		[EditorFoldout("Death", "Name, description and icon for death.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("Death")]
		public LanguageContentInformation deathContent = new LanguageContentInformation("Death");

		[EditorFoldout("Grid Move Command", "Name, description and icon for the grid move command.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("GridMoveCommand")]
		public LanguageContentInformation gridMoveCommandContent = new LanguageContentInformation("Move");

		[EditorFoldout("Grid Orientation Command", "Name, description and icon for the grid orientation command.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("GridOrientationCommand")]
		public LanguageContentInformation gridOrientationCommandContent = new LanguageContentInformation("Rotate");

		[EditorFoldout("Grid Examine Command", "Name, description and icon for the grid examine command.", "")]
		[EditorEndFoldout(2)]
		[EditorLanguageExport("GridExamineCommand")]
		public LanguageContentInformation gridExamineCommandContent = new LanguageContentInformation("Examine");

		// other content
		[EditorFoldout("Other Content", "Define the other content information.", "",
			"Action Cost", "Name, description and icon for action cost display.\n" +
			"This can be used by cost displays.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("ActionCost")]
		public LanguageContentInformation actionCostContent = new LanguageContentInformation("AP");

		[EditorFoldout("Use Count", "Name, description and icon for use count display.\n" +
			"This can be used by cost displays.", "")]
		[EditorEndFoldout(3)]
		[EditorLanguageExport("UseCount")]
		public LanguageContentInformation useCountContent = new LanguageContentInformation("Uses");

		// action info notifications
		[EditorFoldout("Action Info Notifications", "Action info notifications display information about the battle action currently used by a combatant.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Action Infos", "Add action info settings.", "",
			"Remove", "Remove this action info settings.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Action Info Notification", "Define the action info notifications that will be displayed and for which group they're used.", ""
		})]
		public AlliedStateSettings<ActionInfoNotifications>[] actionInfos = new AlliedStateSettings<ActionInfoNotifications>[0];


		// flying texts
		// status effects
		[EditorHelp("Show End With Battle", "Show the remove flying text for effects that end with the battle.", "")]
		[EditorFoldout("Flying Text Settings", "Optionally display flying texts for different status changes, " +
			"e.g. adding/removing status effects or level ups.", "",
			"Status Effects", "Adding, missing or removing a status effect can display flying texts.", "")]
		public bool effectRemoveTextEndBattle = true;

		[EditorHelp("Show End On Death", "Show the remove flying text for effects that end with the death of the combatant.", "")]
		public bool effectRemoveTextEndDeath = true;

		[EditorEndFoldout]
		[EditorArray("Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public AlliedStateSettings<StatusEffectFlyingTextSettings>[] statusEffectFlyingText = new AlliedStateSettings<StatusEffectFlyingTextSettings>[0];


		// miss
		[EditorFoldout("Miss", "The miss text is displayed when an attack or ability misses it's target.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public AlliedStateSettings<FlyingTextContent>[] missFlyingText = new AlliedStateSettings<FlyingTextContent>[0];


		// block
		[EditorFoldout("Block", "The block text is displayed when status changes " +
			"(e.g. from an ability or item) are blocked by the target.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public AlliedStateSettings<FlyingTextContent>[] blockFlyingText = new AlliedStateSettings<FlyingTextContent>[0];


		// cast cancel
		[EditorFoldout("Cast Cancel", "The cast cancel text is displayed when an action cast is canceled (e.g. due to an attack).", "")]
		[EditorEndFoldout]
		[EditorArray("Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public AlliedStateSettings<FlyingTextContent>[] castCancelFlyingText = new AlliedStateSettings<FlyingTextContent>[0];


		// level up
		[EditorFoldout("Level Up", "The level up text is displayed when the level of a combatant increases.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public AlliedStateSettings<FlyingTextContent>[] levelUpFlyingText = new AlliedStateSettings<FlyingTextContent>[0];


		// class level up
		[EditorFoldout("Class Level Up", "The class level up text is displayed when the class level of a combatant increases.", "")]
		[EditorEndFoldout(2)]
		[EditorArray("Add Flying Text", "Add flying text settings.", "",
			"Remove", "Remove this flying text settings.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Flying Text", "Define the flying texts that will be displayed and for which group they're used.", ""
		})]
		public AlliedStateSettings<FlyingTextContent>[] classLevelUpFlyingText = new AlliedStateSettings<FlyingTextContent>[0];


		// in-game
		protected DefendShortcut dummyDefendAction;

		protected EscapeShortcut dummyEscapeAction;

		protected NoneShortcut dummyNoneAction;

		protected GridMoveShortcut dummyGridMoveAction;

		protected GridExamineShortcut dummyGridExamineAction;

		protected GridOrientationShortcut dummyGridOrientationAction;

		public BattleTextsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("showInfo"))
			{
				bool tmp = false;
				data.Get("showInfo", ref tmp);
				if(tmp)
				{
					AlliedStateSettings<ActionInfoNotifications> settings = new AlliedStateSettings<ActionInfoNotifications>();
					settings.settings.SetData(data);
					this.actionInfos = new AlliedStateSettings<ActionInfoNotifications>[] { settings };
				}
			}

			this.dummyDefendAction = null;
			this.dummyEscapeAction = null;
			this.dummyNoneAction = null;
			this.dummyGridMoveAction = null;
			this.dummyGridExamineAction = null;
			this.dummyGridOrientationAction = null;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Battle Texts"; }
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual UIButtonInputContent GetAllCombatantsContent(TargetType type, ORKButtonContentLayout layout)
		{
			if(TargetType.Ally == type)
			{
				return layout.GetContent(this.allAlliesButton.GetContent());
			}
			else if(TargetType.Enemy == type)
			{
				return layout.GetContent(this.allEnemiesButton.GetContent());
			}
			else if(TargetType.All == type)
			{
				return layout.GetContent(this.allCombatantsButton.GetContent());
			}
			return null;
		}

		public virtual UIButtonInputContent GetAllCombatantsContent(TargetType type)
		{
			if(TargetType.Ally == type)
			{
				return this.allAlliesButton.GetContent();
			}
			else if(TargetType.Enemy == type)
			{
				return this.allEnemiesButton.GetContent();
			}
			else if(TargetType.All == type)
			{
				return this.allCombatantsButton.GetContent();
			}
			return null;
		}

		public virtual DefendShortcut DummyDefendAction
		{
			get
			{
				if(this.dummyDefendAction == null)
				{
					this.dummyDefendAction = new DefendShortcut();
				}
				return this.dummyDefendAction;
			}
		}

		public virtual EscapeShortcut DummyEscapeAction
		{
			get
			{
				if(this.dummyEscapeAction == null)
				{
					this.dummyEscapeAction = new EscapeShortcut();
				}
				return this.dummyEscapeAction;
			}
		}

		public virtual NoneShortcut DummyNoneAction
		{
			get
			{
				if(this.dummyNoneAction == null)
				{
					this.dummyNoneAction = new NoneShortcut();
				}
				return this.dummyNoneAction;
			}
		}

		public virtual GridMoveShortcut DummyGridMoveAction
		{
			get
			{
				if(this.dummyGridMoveAction == null)
				{
					this.dummyGridMoveAction = new GridMoveShortcut(new GridMoveSettings());
				}
				return this.dummyGridMoveAction;
			}
		}

		public virtual GridExamineShortcut DummyGridExamineAction
		{
			get
			{
				if(this.dummyGridExamineAction == null)
				{
					this.dummyGridExamineAction = new GridExamineShortcut();
				}
				return this.dummyGridExamineAction;
			}
		}

		public virtual GridOrientationShortcut DummyGridOrientationAction
		{
			get
			{
				if(this.dummyGridOrientationAction == null)
				{
					this.dummyGridOrientationAction = new GridOrientationShortcut(false);
				}
				return this.dummyGridOrientationAction;
			}
		}


		/*
		============================================================================
		Flying text functions
		============================================================================
		*/
		public virtual void ShowMissFlyingText(string info, Combatant combatant, GameObject targetObject, IContent content)
		{
			if(combatant != null &&
				this.missFlyingText.Length > 0)
			{
				int group = FlyingTextExtensions.GetGroup(combatant);
				for(int i = 0; i < this.missFlyingText.Length; i++)
				{
					if(this.missFlyingText[i].CheckCombatant(group))
					{
						this.missFlyingText[i].settings.ShowText(info, combatant, targetObject, content);
						break;
					}
				}
			}
		}

		public virtual void ShowBlockFlyingText(string info, Combatant combatant, GameObject targetObject, IContent content)
		{
			if(combatant != null &&
				this.blockFlyingText.Length > 0)
			{
				int group = FlyingTextExtensions.GetGroup(combatant);
				for(int i = 0; i < this.blockFlyingText.Length; i++)
				{
					if(this.blockFlyingText[i].CheckCombatant(group))
					{
						this.blockFlyingText[i].settings.ShowText(info, combatant, targetObject, content);
						break;
					}
				}
			}
		}

		public virtual void ShowCastCancelFlyingText(string info, Combatant combatant, GameObject targetObject, IContent content)
		{
			if(combatant != null &&
				this.castCancelFlyingText.Length > 0)
			{
				int group = FlyingTextExtensions.GetGroup(combatant);
				for(int i = 0; i < this.castCancelFlyingText.Length; i++)
				{
					if(this.castCancelFlyingText[i].CheckCombatant(group))
					{
						this.castCancelFlyingText[i].settings.ShowText(info, combatant, targetObject, content);
						break;
					}
				}
			}
		}

		public virtual void ShowLevelUpFlyingText(string info, Combatant combatant, GameObject targetObject)
		{
			if(combatant != null &&
				this.levelUpFlyingText.Length > 0)
			{
				int group = FlyingTextExtensions.GetGroup(combatant);
				for(int i = 0; i < this.levelUpFlyingText.Length; i++)
				{
					if(this.levelUpFlyingText[i].CheckCombatant(group))
					{
						this.levelUpFlyingText[i].settings.ShowText(info, combatant, targetObject, combatant);
						break;
					}
				}
			}
		}

		public virtual void ShowClassLevelUpFlyingText(string info, Combatant combatant, GameObject targetObject)
		{
			if(combatant != null &&
				this.classLevelUpFlyingText.Length > 0)
			{
				int group = FlyingTextExtensions.GetGroup(combatant);
				for(int i = 0; i < this.classLevelUpFlyingText.Length; i++)
				{
					if(this.classLevelUpFlyingText[i].CheckCombatant(group))
					{
						this.classLevelUpFlyingText[i].settings.ShowText(info, combatant, targetObject, combatant.Class.Current);
						break;
					}
				}
			}
		}
	}
}
