
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class StartMenuSettings : BaseSettings
	{
		// start menu scene/call
		[EditorHelp("Start Menu Scene", "The name of the scene where the start menu will be displayed.\n" +
			"This scene is loaded when the game exits to the start menu.", "")]
		[EditorFoldout("Start Menu Settings", "Set the start menu scene and other base settings.", "")]
		[EditorWidth(true)]
		public string startMenuScene = "";

		[EditorHelp("Load Type", "Select how the scene is loaded:\n" +
			"- Load Level: Closes all current loaded scenes and loads a scene.\n" +
			"- Load Level Additive: Adds the scene to the current loaded scenes.\n" +
			"- Load Async: Closes all current loaded scenes and loads a " +
			"scene asynchronously in the background.\n" +
			"- Load Async Additive: Adds the scene to the current loaded scenes " +
			"and loads it asynchronously in the background.", "")]
		public SceneLoadType loadType = SceneLoadType.LoadLevel;

		[EditorHelp("Auto Call", "The start menu will automatically be called when the " +
			"menu scene is loaded (at game start and exit to menu).", "")]
		public bool autoCall = false;

		[EditorHelp("Wait Time (s)", "The time in seconds before the start menu is displayed.", "")]
		[EditorCondition("autoCall", true)]
		[EditorEndCondition]
		[EditorLimit(0.0f, false)]
		public float waitTime = 0;

		// screen fades
		[EditorHelp("Own Screen Fade", "Use different screen fade settings when loading the start menu scene.\n" +
			"If disabled, it'll use the default screen fade settings defined in the game settings.")]
		[EditorFoldout("Screen Fade Settings", "Optionally use a different screen fading when loading the start menu scene.", "")]
		public bool ownScreenFade = false;

		[EditorEndFoldout(2)]
		[EditorCondition("ownScreenFade", true)]
		[EditorAutoInit]
		[EditorEndCondition]
		public ScreenFadeSettings screenFade;



		// new game
		[EditorHelp("New Game Scene", "The name of the scene that will be loaded when a new game is started.", "")]
		[EditorFoldout("New Game Settings", "Set the new game scene and screen fade settings.", "")]
		[EditorWidth(true)]
		public string newGameScene = "";

		[EditorHelp("Load Type", "Select how the scene is loaded:\n" +
			"- Load Level: Closes all current loaded scenes and loads a scene.\n" +
			"- Load Level Additive: Adds the scene to the current loaded scenes.\n" +
			"- Load Async: Closes all current loaded scenes and loads a " +
			"scene asynchronously in the background.\n" +
			"- Load Async Additive: Adds the scene to the current loaded scenes " +
			"and loads it asynchronously in the background.", "")]
		public SceneLoadType newGameLoadType = SceneLoadType.LoadLevel;

		[EditorHelp("SC Block Player Control", "Block the player controls while changing scenes.")]
		public bool newGameSCBlockPlayerControl = false;

		[EditorHelp("SC Block Camera Control", "Block the camera controls while changing scenes.")]
		public bool newGameSCBlockCameraControl = false;

		[EditorHelp("Stop Music", "The music is stopped when starting a new game.\n" +
			"If disabled, you can manage the music in your start schematic or the new game scene.", "")]
		public bool newGameStopMusic = true;

		[EditorHelp("Start Schematic", "Select the schematic asset that will be used as start schematic.\n" +
			"The start schematic is automatically executed when starting a new game (after loading the new game scene).\n" +
			"If a game starter is set up to start immediately in the scene, the start schematic will also be started immediately.\n" +
			"Use the start schematic to add your player combatant to the player group and spawn it in the scene.", "")]
		[EditorSeparator]
		public AssetSource<MakinomSchematicAsset> startSchematic = new AssetSource<MakinomSchematicAsset>();

		[EditorHelp("Set Start Group", "Use a combatant group as the player group at the start of a new game.\n" +
			"The group will be created before executing the start schematic.", "")]
		public bool setStartGroup = false;

		[EditorHelp("Combatant Group", "Select the combatant group that will be used as the player group.", "")]
		[EditorCondition("setStartGroup", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<CombatantGroupAsset> startGroup;

		// screen fades
		[EditorHelp("Own Screen Fade", "Use different screen fade settings when loading the new game scene.\n" +
			"If disabled, it'll use the default screen fade settings defined in the game settings.")]
		[EditorFoldout("Screen Fade Settings", "Optionally use a different screen fading when loading the new game scene.", "")]
		public bool newGameOwnScreenFade = false;

		[EditorEndFoldout(2)]
		[EditorCondition("newGameOwnScreenFade", true)]
		[EditorAutoInit]
		[EditorEndCondition]
		public ScreenFadeSettings newGameScreenFade;


		// menu choices
		[EditorFoldout("Menu Options", "The options of the start menu are defined here.", "")]
		[EditorEndFoldout]
		public StartMenuControl menu = new StartMenuControl();

		public StartMenuSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Start Menu"; }
		}
	}
}

