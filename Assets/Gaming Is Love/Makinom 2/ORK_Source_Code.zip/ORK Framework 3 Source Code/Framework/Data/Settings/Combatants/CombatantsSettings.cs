
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Animations;
using GamingIsLove.ORKFramework.Combatants;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class CombatantsSettings : GenericAssetListSettings<CombatantAsset, CombatantSetting>
	{
		// object variables
		[EditorHelp("Use Object Variables", "Automatically adds an 'Object Variables' component to the combatant's game object.\n" +
			"Object variables are used to bind variables to game objects in the scene.", "")]
		[EditorFoldout("Base Settings", "Define the basic settings for combatants.", "",
			"Object Variable Settings", "You can automatically add an 'Object Variables' component to a combatant's prefab.\n" +
			"The object variables can be initialized with default values.", "")]
		[EditorEndFoldout]
		public CombatantObjectVariableSetting objectVariableSetting = new CombatantObjectVariableSetting();

		// control maps
		[EditorHelp("Control Map", "Select the control map that will be available.", "")]
		[EditorFoldout("Default Control Maps", "Control maps can be used by player controlled combatants to bind actions to inputs.")]
		[EditorEndFoldout]
		[EditorArray("Add Control Map", "Adds a control map.", "",
			"Remove", "Removes the control map.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Control Map", "Select the control map that will be used.", ""
			})]
		public AssetSelection<ControlMapAsset>[] controlMap = new AssetSelection<ControlMapAsset>[0];

		// default schematics
		[EditorFoldout("Default Schematic Settings", "Combatants can perform schematics at the start and end of their turn.\n" +
			"Define the default schematics here, each combatant can individually override these schematics.", "",
			"Init Schematics", "Define the schematics that will be performed when first initializing a combatant.\n" +
			"The combatant will be used as 'Machine Object' and 'Starting Object'.\n" +
			"The schematics are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default schematics.", "")]
		[EditorEndFoldout]
		public FactionSchematicSetting initSchematics = new FactionSchematicSetting();

		[EditorFoldout("Spawn Schematics", "Define the schematics that will be performed when spawning a combatant.\n" +
			"The combatant will be used as 'Machine Object' and 'Starting Object'.\n" +
			"The schematics are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default schematics.", "")]
		[EditorEndFoldout]
		public FactionSchematicSetting spawnSchematics = new FactionSchematicSetting();

		[EditorFoldout("Battle Start Schematics", "Define the schematics that will be performed when the combatant enters a battle " +
			"(either at the start of a battle of when joining a running battle).\n" +
			"The combatant will be used as 'Machine Object' and 'Starting Object'.\n" +
			"The schematics are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default schematics.", "")]
		[EditorEndFoldout]
		public FactionSchematicSetting battleStartSchematics = new FactionSchematicSetting();

		[EditorFoldout("Battle End Schematics", "Define the schematics that will be performed when the combatant leaves a battle " +
			"(either at the end of a battle of when leaving a running battle).\n" +
			"The combatant will be used as 'Machine Object' and 'Starting Object'.\n" +
			"The schematics are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default schematics.", "")]
		[EditorEndFoldout]
		public FactionSchematicSetting battleEndSchematics = new FactionSchematicSetting();

		[EditorFoldout("Turn Start Schematics", "Define the schematics that will be performed at the " +
			"start of a combatant's turn (after the grid cell schematics).\n" +
			"The combatant will be used as 'Machine Object' and 'Starting Object'.\n" +
			"The schematics are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default schematics.", "")]
		[EditorEndFoldout]
		public FactionSchematicSetting turnStartSchematics = new FactionSchematicSetting();

		[EditorFoldout("Turn End Schematics", "Define the schematics that will be performed at the " +
			"end of a combatant's turn (before the grid cell schematics).\n" +
			"The combatant will be used as 'Machine Object' and 'Starting Object'.\n" +
			"The schematics are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default schematics.", "")]
		[EditorEndFoldout]
		public FactionSchematicSetting turnEndSchematics = new FactionSchematicSetting();

		[EditorFoldout("Status Reset Schematics", "Define the schematics that will be performed after a combatant's status was recalculated.\n" +
			"Status recalculation happens e.g. when equipment or status effects of a combatant change, 'Normal' type status values are changed, etc.\n" +
			"The combatant will be used as 'Machine Object' and 'Starting Object'.\n" +
			"The schematics are separated into player group, ally group and enemy group combatants.\n" +
			"Each combatant can individually override these default schematics.", "")]
		[EditorEndFoldout]
		public FactionSchematicSetting statusResetSchematics = new FactionSchematicSetting();

		[EditorFoldout("Custom Schematics", "Custom schematics can be used in other schematics using a 'Custom Combatant Schematic' node.\n" +
			"The combatant will be used as 'Machine Object' and 'Starting Object'.", "")]
		[EditorEndFoldout(3)]
		[EditorArray("Add Custom Schematics", "Adds custom schematics.", "",
			"Remove", "Removes the custom schematics.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Custom Schematics", "Define the schematics that will be performed when using a " +
				"'Custom Combatant Schematic' node with a matching key.\n" +
				"The combatant will be used as 'Machine Object' and 'Starting Object'.\n" +
				"The schematics are separated into player group, ally group and enemy group combatants.\n" +
				"Each combatant can individually override these default schematics.", ""
		})]
		public KeyFactionSchematicSetting[] customSchematics = new KeyFactionSchematicSetting[0];


		// UI settings
		// reaction portraits
		[EditorFoldout("UI Settings", "Define UI related settings for combatants.", "",
			"Reaction Portraits", "Show different portrait types based on things happening to a combatant.\n" +
			"E.g. showing a 'damage' portrait for a short time after receiving damage or a different portrait while a status effect is applied.\n" +
			"Show reaction portraits in your UI via 'Reaction Portrait' elements (setup depends on the used UI system).", "")]
		[EditorEndFoldout]
		public CombatantReactionPortraitSettings reactionPortraits = new CombatantReactionPortraitSettings();

		// research tree UI
		[EditorFoldout("Research Tree UI", "Define the research tree UI setup that'll be used to display merged research trees in tree view menus.\n" +
			"Used in 'Research (Tree View)' menu parts to display all research tree setups of a combatant.", "")]
		[EditorEndFoldout(2)]
		public UIResearchTreeSettings researchTreeUI = new UIResearchTreeSettings();


		// status settings
		// classes
		[EditorFoldout("Status Settings", "Define default status related settings.", "",
			"Class Settings", "Define the default class slots and added classes for all combatants.\n" +
			"Individual combatants can add/replace the default slots and classes.", "",
			"Initial Class Slots", "Define the class slots the combatant will have available and which classes are equipped on them.\n" +
			"Class slots can be later added/removed in a running game.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Initial Class Slot", "Adds a new class slot to the combatant.", "",
			"Remove", "Removes this class slot.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Initial Class Slot", "Define the class slot and class that'll be added to the combatant.", ""})]
		public InitialClassSlot[] initialClassSlot = new InitialClassSlot[0];

		[EditorFoldout("Add Classes", "Define classes that will be added to the combatant.\n" +
			"Classes can be later added/removed in a running game.\n" +
			"Classes used in the initial class slots don't need to be added here.", "")]
		[EditorEndFoldout(2)]
		[EditorArray("Add Class", "Adds a new class to the combatant.", "",
			"Remove", "Removes this class.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Class", "Define the class that'll be added to the combatant.", ""})]
		public AddClass[] addClass = new AddClass[0];

		// status bonuses
		[EditorFoldout("Status Bonuses", "Add bonus settings.\n" +
			"Bonuses can be given to chances, status values, attack/defence modifiers and change status effects.\n" +
			"Each bonus setting can depend on the game's difficulty.", "")]
		[EditorEndFoldout]
		public BonusSettings bonus = new BonusSettings();

		// random status bonuses
		[EditorFoldout("Random Status Bonuses", "Optionally add random status bonuses to the combatants.\n" +
			"The bonuses are added to the combatant when it's first created.", "")]
		[EditorEndFoldout]
		public RandomStatusBonusSettings randomBonus = new RandomStatusBonusSettings();

		// level up
		[EditorFoldout("Level Up Settings", "A combatant can receive bonuses when reaching a new base or class level.", "",
			"Base Level Up", "Settings for base level ups.\n" +
			"Can be overridden by each combatant individually.", "")]
		[EditorEndFoldout]
		public LevelUpBonus levelUp = new LevelUpBonus();

		[EditorFoldout("Class Level Up", "Settings for class level ups.\n" +
			"Can be overridden by each class individually.", "")]
		[EditorEndFoldout(2)]
		public LevelUpBonus classLevelUp = new LevelUpBonus();

		// body parts
		[EditorFoldout("Default Body Parts", "Optionally add body parts to the combatant.\n" +
			"Body parts are separate targets on a combatant and use a combatant setup for their status definition.\n" +
			"Individual combatants can add to or replace the default body parts.")]
		[EditorEndFoldout(2)]
		[EditorArray("Add Body Part", "Adds a body part to the combatant.\n" +
			"Body parts are separate targets on a combatant and use a combatant setup for their status definition.\n" +
			"Individual combatants can add to or replace the default body parts.", "",
			"Remove", "Removes the body part.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Body Part", "Select the base combatant and other settings for the body part.", ""
			})]
		public CombatantBodyPartSetting[] bodyPart = new CombatantBodyPartSetting[0];


		// attacks/abilities
		[EditorHelp("Multiple Ability Sources", "Abilities will be listed multiple times when coming from different sources " +
			"(e.g. learned ability and abilities from different equipment).\n" +
			"If disabled, only the ability with the highest level will be listed.")]
		[EditorFoldout("Attacks & Abilities", "Define the combatant's base attack, " +
			"counter attack, auto attack and ability development.", "")]
		public bool multipleAbilitySources = false;

		// base attack
		[EditorHelp("Action Stop Resets Index", "If a base attack is stopped (e.g. due to canceled action), " +
			"the base attack index is reset to the first attack.")]
		[EditorFoldout("Default Base Attack", "Define the combatant's base attack, " +
			"every active ability can be used as a base attack.\n" +
			"You can add multiple attacks to enable combo attacks - " +
			"the combatant will circle through the base attacks, starting with the first one.\n" +
			"Combatants can override the default base attack.", "")]
		public bool actionStopResetsAttackIndex = true;

		[EditorEndFoldout]
		[EditorArray("Add Base Attack", "Add an ability used as base attack.", "",
			"Remove", "Remove this ability.", "",
			removeCheckField = "ability", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Base Attack", "Define the ability that will be used as base attack.", ""
			})]
		public ActiveAbilitySelection[] baseAttack = new ActiveAbilitySelection[] { new ActiveAbilitySelection() };

		// counter attack
		[EditorFoldout("Default Counter Attack", "Define the combatant's counter attack, " +
			"every active ability can be used as a counter attack.\n" +
			"The combatant will use the counter attack when countering an action.\n" +
			"Combatants can override the default counter attack.", "")]
		[EditorEndFoldout]
		public ActiveAbilitySelection counterAttack = new ActiveAbilitySelection();

		// auto attack
		[EditorFoldout("Default Auto Attack Settings", "Auto attacks will perform periodically without ending a combatants turn or using it's timebar.\n" +
			"They are available for dynamic combat ('Turn Based', 'Active Time' and 'Phase' battles) or " +
			"'Real Time' battles with group target on auto attack enabled. Phase battles don't support auto attacks.\n" +
			"You can disable auto attacks in each battle system type individually.\n" +
			"Combatants can override the default auto attack settings.", "")]
		[EditorEndFoldout]
		public AutoAttack autoAttack = new AutoAttack();

		// default action combos
		[EditorHelp("Action Combo", "Select the action combo that will be available.", "")]
		[EditorFoldout("Default Action Combos", "Define action combos that will be available for all combatants.\n" +
			"Combatants can optionally add or replace the default combos.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Action Combo", "Adds an action combo.", "",
			"Remove", "Removes the action combo.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Action Combo", "Select the action combo that will be used.", ""
			})]
		public AssetSelection<ActionComboAsset>[] actionCombo = new AssetSelection<ActionComboAsset>[0];

		// ability availability
		[EditorFoldout("Ability Availability", "Optionally limit the abilities available to the combatant.\n" +
			"This doesn't affect the abilities the combatant has or can learn, only if they're listed in menus, " +
			"available for use (active abilities) or contribute to the combatant's status (passive abilities).\n" +
			"E.g. you can only make abilities currently set in shortcut slots available.\n" +
			"Menus can set up to still display all abilities, ignoring the limitations (e.g. for shortcut slot assignments).\n" +
			"Combatants can override the default ability availability.", "")]
		[EditorEndFoldout]
		public CombatantAbilityAvailability abilityAvailability = new CombatantAbilityAvailability();

		// shortcuts
		[EditorHelp("Use Class Shortcuts", "The combatant will use class shortcut lists.\n" +
			"I.e. the number of available shortcut lists and default shortcuts are defined by the current class - " +
			"changing the class will also change the shortcut lists.\n" +
			"If disabled, all classes share the same shortcut lists.", "")]
		[EditorFoldout("Shortcut Settings", "Shortcuts are used to quickly use items or abilities, or equip equipment.\n" +
			"They can be used via control maps or 'Combatant' type HUDs with shortcut elements.\n" +
			"Shortcuts are organized in lists, each list consists of an unspecified amount of slots (index based), " +
			"i.e. there's no limit to the number of shortcuts that can be added to a list. " +
			"Only the currently active list can be used - switching between lists can be done using schematics, " +
			"e.g. with a global machine called when pressing an input key.\n" +
			"Combatants can override the default shortcuts.", "")]
		public bool useClassShortcuts = true;

		[EditorEndFoldout(2)]
		[EditorCondition("useClassShortcuts", false)]
		[EditorEndCondition]
		public CombatantShortcutSettings shortcuts = new CombatantShortcutSettings();


		// inventory & equipment
		// start inventory settings
		[EditorFoldout("Inventory & Equipment", "Define the combatant's inventory and equipment.", "",
			"Default Start Inventory", "Define the inventory a newly generated combatant will have.\n" +
			"If group inventory is used, the combatant's inventory will be added to the group's inventory.\n" +
			"The start inventory can also be used as loot (victory gains), if the combatant is defeated by the player group.\n" +
			"Combatants can override the default start inventory.", "")]
		[EditorEndFoldout]
		public StartInventory startInventory = new StartInventory();

		[EditorFoldout("Default Loot Settings", "The loot settings define the currency, items, equipment or other things " +
			"the player group will receive upon defeating a combatant.\n" +
			"You can either use the combatant's start inventory or loot tables.\n" +
			"Combatants can override the default loot settings.", "")]
		[EditorEndFoldout]
		public CombatantLoot loot = new CombatantLoot();

		// available equipment
		[EditorFoldout("Default Available Equipment", "Define the equipment slots and equipment that will be available to combatants.\n" +
			"Classes can override the default available equipment, combatants can override the default and class available equipment.")]
		[EditorEndFoldout]
		public AvailableEquipmentSelection availableEquipment = new AvailableEquipmentSelection(AvailableEquipmentSelectionType.All);

		// steal content
		[EditorArray("Add Steal Level Range", "Adds a new steal setting for a defined level range.", "",
			"Remove", "Removes this steal setting.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[]{
				"Steal", "Define the leven range and item/currency steal settings.", ""
			})]
		[EditorFoldout("Default Steal Settings", "Add steal settings for defined level ranges to steal items/currency from the combatant.\n" +
			"Combatants can override the default steal settings.", "")]
		[EditorEndFoldout(2)]
		public StealContent[] stealContent = new StealContent[0];


		// battle settings
		// death settings
		[EditorFoldout("Battle Settings", "Define the combatant's battle related settings " +
			"like base chances, AI and death settings.", "",
			"Default Death Settings", "Define general settings related to a combatant's death and " +
			"the changes that happen when a combatant dies.\n" +
			"Combatants can override the default death settings.", "")]
		[EditorEndFoldout]
		public CombatantDeathSettings deathSettings = new CombatantDeathSettings();

		// auto start battles
		[EditorFoldout("Auto Start Battles", "A combatant can automatically start battles with the player upon defined conditions.\n" +
			"Only used when the player and the combatant are enemies and there is currently no battle running.\n" +
			"Combatants can override the default auto start settings.", "")]
		[EditorEndFoldout]
		public AutoStartBattleSettings autoStartBattles = new AutoStartBattleSettings(true);

		// grid cell size
		[EditorHelp("Use Grid Cell Size", "Define grid cells that will be occupied by the combatant.\n" +
			"If disabled, the combatant will only occupy 1 cell.\n" +
			"The combatant's origin cell (i.e. the cell the combatant is placed on, " +
			"e.g. the cell selected as the grid move target) will always be occupied by the combatant.", "")]
		[EditorFoldout("Default Grid Cell Size", "You can optionally define a grid cell size for combatants.\n" +
			"This defines which cells will be occupied by a combatant.\n" +
			"When not using a grid cell size, the combatant will only occupy 1 cell.\n" +
			"The combatant's origin cell (i.e. the cell the combatant is placed on, " +
			"e.g. the cell selected as the grid move target) will always be occupied by the combatant.\n" +
			"Cobmatants can override the default grid cell size.", "")]
		public bool useGridCellSize = false;

		[EditorEndFoldout]
		[EditorCondition("useGridCellSize", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public GridCellAreaSettings gridCellSize;

		// combatant links
		[EditorHelp("Clear Battle End", "All combatant links of a combatant will be removed when leaving/ending battles.", "")]
		[EditorFoldout("Combatant Links", "Combatants can be linked to others via the " +
			"'Link Combatants' node in schematics.\n" +
			"These links can be automatically released to free up memory.", "")]
		public bool combatantLinksClearBattleEnd = true;

		[EditorHelp("Auto Clear Dead", "Dead combatants will clear their own combatant links.", "")]
		[EditorEndFoldout]
		public bool combatantLinksAutoClearDead = false;

		// battle AI
		[EditorFoldout("Default Battle AI", "Define the default battle AIs that will be used by combatants.\n" +
			"Combatants can add their own battle AI or completely replace the default battle AI.")]
		[EditorEndFoldout]
		[EditorArray("Add Battle AI", "Adds a battle AI to the combatant.\n" +
			"The battle AIs will be used in the order they're added (i.e. starting with 'Battle AI 0').", "",
			"Remove", "Removes this battle AI.", "", isMove = true, isCopy = true,
			removeCheckField = "battleAI",
			foldout = true, foldoutText = new string[] {
				"Battle AI", "Define the battle AI that will be used and conditions that must be met.", ""
			})]
		public BattleAISelection[] battleAI = new BattleAISelection[0];

		// AI settings
		[EditorFoldout("Default AI Settings", "Player combatants can be AI controlled in battles.\n" +
			"If you set a player combatant to be AI controlled, you won't have to select battle commands (if he's not the actual player).\n" +
			"All non-player group combatants will always be AI controlled.\n" +
			"Combatants can override the default AI settings.")]
		[EditorEndFoldout]
		public CombatantAISettings aiSettings = new CombatantAISettings();

		// AI behaviour slots
		[EditorFoldout("AI Behaviour Slots", "AI behaviours are equipped on AI behaviour slots of a combatant.\n" +
			"The combatant's AI will first try to find a useable action in AI behaviours equipped to the slots.\n" +
			"If no action is found, the defined battle AIs will be used as a fallback.\n" +
			"Slots can also be added or removed using schematics.\n" +
			"Combatants can override the default AI behaviour slots.", "")]
		[EditorEndFoldout]
		[EditorArray("Add AI Behaviour Slot", "Adds a slot to equip an AI behaviour to the combatant.", "",
			"Remove", "Removes this AI behaviour slot.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"AI Behaviour Slot", "Define the AI behaviour that will be used.", ""
			})]
		public AIBehaviourSlotSetting[] aiBehaviourSlot = new AIBehaviourSlotSetting[0];

		// AI ruleset slots
		[EditorFoldout("AI Ruleset Slots", "AI rulesets are equipped on AI ruleset slots of a combatant.\n" +
			"The combatant's AI will be influenced by the equipped AI rulesets, e.g. preventing certain abilities from being used.\n" +
			"Slots can also be added or removed using schematics.\n" +
			"Combatants can override the default AI ruleset slots.", "")]
		[EditorEndFoldout]
		[EditorArray("Add AI Ruleset Slot", "Adds a slot to equip an AI ruleset to the combatant.", "",
			"Remove", "Removes this AI ruleset slot.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"AI Ruleset Slot", "Define the AI ruleset that will be used.", ""
			})]
		public AIRulesetSlotSetting[] aiRulesetSlot = new AIRulesetSlotSetting[0];

		// default battle animations
		[EditorFoldout("Default Battle Animations", "Define the schematics used to animate default actions, e.g. defend, escape or a combatant's death.\n" +
			"Combatants can override the default battle animations.", "")]
		[EditorEndFoldout(2)]
		public DefaultBattleAnimations battleAnimations = new DefaultBattleAnimations();


		// animation/movement
		// animations
		[EditorFoldout("Animations & Movement", "Define the combatant's animations and movement settings.", "",
			"Default Animation System", "Define the default animation system that will be used.\n" +
			"Combatants can override the default animation system.", "")]
		[EditorEndFoldout]
		public CombatantAnimationSystem animationSystem = new CombatantAnimationSystem();

		[EditorFoldout("Default Animations", "Define the default animations used by the combatant.\n" +
			"You can add multiple animation settings and additionally add different settings for battle, overriding field animations.\n" +
			"Combatants can add to or replace the default animations.", "")]
		[EditorEndFoldout]
		public AnimationsFieldBattle animations = new AnimationsFieldBattle();

		[EditorFoldout("Auto Animation", "ORK can automatically handle movement animations " +
			"(idle, walk, run, sprint, fall, land) based on the combatant's movement.\n" +
			"If disabled, you'll have to manage the movement animations with your own scripts or via schematics.\n" +
			"The auto animation can also be enabled/disabled using schematics.\n" +
			"Combatants can override the default auto animations.", "")]
		[EditorEndFoldout]
		public AutoAnimationSetting autoAnimation = new AutoAnimationSetting();

		// movement
		[EditorFoldout("Default Move Speed", "Define the default move speed of the combatants.\n" +
			"Combatants can override the default move speed settings.")]
		[EditorEndFoldout]
		public CombatantMoveSpeedSettings moveSpeed = new CombatantMoveSpeedSettings();

		[EditorFoldout("Default Movement Component", "Define the default component that will be used to move the combatant's game object.\n" +
			"The movement component is e.g. used by the move AI or when moving to interactions (player).")]
		[EditorEndFoldout]
		public MovementComponentSetting movementComponent = new MovementComponentSetting();

		[EditorFoldout("Default Move AI", "Optionally use a move AI to move combatants that are not directly controlled by the player, " +
			"i.e. other members of the player group and non-player combatants.\n" +
			"Combatants can override the default move AI.", "")]
		[EditorEndFoldout]
		public CombatantMoveAISettings moveAI = new CombatantMoveAISettings();

		// find ground
		[EditorFoldout("Default Find Ground", "Define how combatants check if their game object is on the ground or in the air.\n" +
			"This is e.g. used by auto animations and control maps.\n" +
			"Combatants can override the default find ground settings.", "")]
		[EditorEndFoldout]
		public FindGroundSettings findGround = new FindGroundSettings();

		// audio settings
		[EditorFoldout("Sound Settings", "Combatants use sounds to play default audio clips in schematics (e.g. a damage sound when being hit).\n" +
			"A sound is played if the sound's sound type is played on the combatant (through schematic nodes).\n" +
			"This makes it easier to share schematics between different combatants.\n" +
			"Combatants can add to and override (by defining the same sound type) the sounds defined here.", "")]
		[EditorEndFoldout(2)]
		public SoundSettings sounds = new SoundSettings();

		public CombatantsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<DataObject>("soundTemplate"))
			{
				this.sounds.soundTemplate.SetData(data.GetFile("soundTemplate"));
				DataObject[] tmpData = data.GetFileArray("battleSound");
				if(tmpData != null &&
					tmpData.Length > 0)
				{
					this.sounds.sound = new Sound[tmpData.Length];
					for(int i = 0; i < tmpData.Length; i++)
					{
						this.sounds.sound[i] = new Sound();
						this.sounds.sound[i].SetData(tmpData[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Combatants"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public Combatant Create(int index, Group group, bool showNotification, bool showConsole)
		{
			if(index >= 0 && index < this.assets.Count)
			{
				Combatant c = new Combatant();
				c.BaseInit(this.assets[index].Settings, group, showNotification, showConsole, false);
				return c;
			}
			return null;
		}

		public void SetStatusValueType(StatusValueSetting statusValue, StatusValueType type)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				for(int j = 0; j < this.assets[i].Settings.startValue.Length; j++)
				{
					if(this.assets[i].Settings.startValue[j].status.Is(statusValue))
					{
						ArrayHelper.RemoveAt(ref this.assets[i].Settings.startValue, j--);
					}
				}
				if(StatusValueType.Experience != type)
				{
					if(this.assets[i].Settings.expReward != null)
					{
						for(int j = 0; j < this.assets[i].Settings.expReward.Length; j++)
						{
							if(this.assets[i].Settings.expReward[j].status.Is(statusValue))
							{
								ArrayHelper.RemoveAt(ref this.assets[i].Settings.expReward, j--);
							}
						}
					}
				}
			}
		}

		public void StatusDevelopmentLevels(StatusDevelopment development)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.hasStatusDevelopment &&
					this.assets[i].Settings.statusDevelopment.Is(development))
				{
					development.AdjustLevel(ref this.assets[i].Settings.startLevel);
				}
			}
		}

		public List<CombatantSetting> GetByCombatantType(CombatantType type, bool checkParent)
		{
			List<CombatantSetting> list = new List<CombatantSetting>();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(type == null ||
					this.assets[i].Settings.IsType(type, checkParent))
				{
					list.Add(this.assets[i].Settings);
				}
			}
			return list;
		}
	}
}
