﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class ListAsArray<T> where T : class
	{
		protected T[] content;

		public ListAsArray(int size)
		{
			content = new T[size];
		}

		public virtual void Clear()
		{
			for(int i = 0; i < this.content.Length; i++)
			{
				this.content[i] = null;
			}
		}

		public virtual void Copy(ListAsArray<T> other)
		{
			for(int i = 0; i < this.content.Length; i++)
			{
				if(i < other.content.Length)
				{
					this.content[i] = other.content[i];
				}
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public virtual T this[int index]
		{
			get { return this.content[index]; }
			set { this.content[index] = value; }
		}

		public virtual int Length
		{
			get { return this.content.Length; }
		}

		public virtual int ContentCount
		{
			get
			{
				int count = 0;
				for(int i = 0; i < this.content.Length; i++)
				{
					if(this.content[i] != null)
					{
						count++;
					}
				}
				return count;
			}
		}


		/*
		============================================================================
		List functions
		============================================================================
		*/
		public virtual bool Add(T add)
		{
			for(int i = 0; i < this.content.Length; i++)
			{
				if(this.content[i] == null)
				{
					this.content[i] = add;
					return true;
				}
			}
			return false;
		}

		public virtual bool Remove(T remove)
		{
			for(int i = 0; i < this.content.Length; i++)
			{
				if(this.content[i] == remove)
				{
					this.content[i] = null;
					return true;
				}
			}
			return false;
		}

		public virtual T GetFirstAvailable()
		{
			for(int i = 0; i < this.content.Length; i++)
			{
				if(this.content[i] != null)
				{
					return this.content[i];
				}
			}
			return null;
		}

		public virtual bool Contains(T contains)
		{
			for(int i = 0; i < this.content.Length; i++)
			{
				if(this.content[i] == contains)
				{
					return true;
				}
			}
			return false;
		}

		public virtual int IndexOf(T of)
		{
			for(int i = 0; i < this.content.Length; i++)
			{
				if(this.content[i] == of)
				{
					return i;
				}
			}
			return -1;
		}
	}
}
