﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Grid Distance (User)", "Sort the combatants by grid distance to the user (combatant).", "")]
	public class GridDistanceUserCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Block Diagonal Distance 1", "Diagonal cells in square grids will have a distance of 2 instead of 1 " +
			"(when 'Diagonal Distance 1' is enabled in the grid settings).", "")]
		public bool blockDiagonalDistance1 = false;

		[EditorHelp("Ignore Size Cells", "Ignore the grid size cells of the combatants.\n" +
			"This will only use the combatant's origin cell (i.e. the cell the combatant is actually placed on).", "")]
		public bool ignoreSizeCells = false;

		[EditorHelp("Invert Order", "Invert the sort order, i.e. the farthest combatant will be the first in the list.")]
		public bool invertOrder = false;

		[EditorTitleLabel("User (Combatant)")]
		public T user = new T();

		public GridDistanceUserCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "Grid Distance(User)";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{
			list.Sort(new CombatantGridDistanceSorter(this.user.GetCombatant(call), this.blockDiagonalDistance1, this.ignoreSizeCells, this.invertOrder));
		}
	}
}
