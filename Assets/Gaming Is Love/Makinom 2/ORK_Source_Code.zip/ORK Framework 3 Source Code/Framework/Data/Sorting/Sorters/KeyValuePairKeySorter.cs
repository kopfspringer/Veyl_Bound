﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class KeyValuePairKeySorter<TKey, TValue> : IComparer<KeyValuePair<TKey, TValue>> where TKey : System.IComparable<TKey>
	{
		private bool invert = false;

		public KeyValuePairKeySorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(KeyValuePair<TKey, TValue> x, KeyValuePair<TKey, TValue> y)
		{
			if(this.invert)
			{
				return y.Key.CompareTo(x.Key);
			}
			else
			{
				return x.Key.CompareTo(y.Key);
			}
		}
	}
}
