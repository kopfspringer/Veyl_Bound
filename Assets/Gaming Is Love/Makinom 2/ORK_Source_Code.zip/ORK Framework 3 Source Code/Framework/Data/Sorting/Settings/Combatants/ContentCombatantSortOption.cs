﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Content", "Sort the combatants by content information (e.g. name or type name).", "")]
	public class ContentCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		public ContentSorter sorter = new ContentSorter();

		public ContentCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "Content(" + this.sorter.ToString() + ")";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{
			this.sorter.Sort(ref list);
		}
	}
}
