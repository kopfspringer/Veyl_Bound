﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class CombatantSortingSettings<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Sort Type", "Select how the combatants will be sorted:", "")]
		[EditorInfo(settingBaseType = typeof(BaseCombatantSortOption), settingAutoSetup = "settings")]
		public string type = "";

		[EditorSeparator]
		public BaseCombatantSortOption<T> settings = new DistanceUserCombatantSortOption<T>();

		public CombatantSortingSettings()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				DataObject data = this.settings.GetData();
				System.Type tmpType = ReflectionTypeHandler.Instance.GetType(this.type, typeof(BaseCombatantSortOption));
				if(tmpType != null)
				{
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						tmpType.MakeGenericType(typeof(T)));
					if(tmpSettings is BaseCombatantSortOption<T>)
					{
						this.settings = (BaseCombatantSortOption<T>)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new DistanceUserCombatantSortOption<T>();
						this.settings.SetData(data);
						this.type = this.settings.GetGenericTypeName();
					}
				}
				else
				{
					this.settings = new DistanceUserCombatantSortOption<T>();
					this.settings.SetData(data);
					this.type = this.settings.GetGenericTypeName();
				}
			}
		}

		public override string ToString()
		{
			return this.settings.ToString();
		}
	}
}
