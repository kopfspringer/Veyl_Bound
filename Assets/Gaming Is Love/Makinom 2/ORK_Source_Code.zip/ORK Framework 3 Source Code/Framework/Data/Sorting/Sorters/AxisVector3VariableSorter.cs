﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class AxisVector3VariableSorter : IComparer<IVariableSource>
	{
		private string variableKey = "";

		private AxisType axis = AxisType.X;

		private bool invert = false;

		public AxisVector3VariableSorter(string variableKey, AxisType axis, bool invert)
		{
			this.variableKey = variableKey;
			this.axis = axis;
			this.invert = invert;
		}

		public int Compare(IVariableSource x, IVariableSource y)
		{
			if(this.invert)
			{
				if((x == null || !x.HasVariables) &&
					(y == null || !y.HasVariables))
				{
					return 0;
				}
				else if(x != null &&
					(y == null || !y.HasVariables))
				{
					return -1;
				}
				else if((x == null || !x.HasVariables) &&
					y != null)
				{
					return 1;
				}
				else
				{
					int result = 0;
					if(AxisType.X == this.axis)
					{
						result = y.Variables.GetVector3(this.variableKey).x.CompareTo(
							x.Variables.GetVector3(this.variableKey).x);
					}
					else if(AxisType.Y == this.axis)
					{
						result = y.Variables.GetVector3(this.variableKey).y.CompareTo(
							x.Variables.GetVector3(this.variableKey).y);
					}
					else if(AxisType.Z == this.axis)
					{
						result = y.Variables.GetVector3(this.variableKey).z.CompareTo(
							x.Variables.GetVector3(this.variableKey).z);
					}
					if(result == 0 &&
						x is IContent &&
						y is IContent)
					{
						return ((IContent)y).GetName().CompareTo(((IContent)x).GetName());
					}
					return result;
				}
			}
			else
			{
				if((x == null || !x.HasVariables) &&
					(y == null || !y.HasVariables))
				{
					return 0;
				}
				else if(x != null &&
					(y == null || !y.HasVariables))
				{
					return -1;
				}
				else if((x == null || !x.HasVariables) &&
					y != null)
				{
					return 1;
				}
				else
				{
					int result = 0;
					if(AxisType.X == this.axis)
					{
						result = x.Variables.GetVector3(this.variableKey).x.CompareTo(
						   y.Variables.GetVector3(this.variableKey).x);
					}
					else if(AxisType.Y == this.axis)
					{
						result = x.Variables.GetVector3(this.variableKey).y.CompareTo(
							y.Variables.GetVector3(this.variableKey).y);
					}
					else if(AxisType.Z == this.axis)
					{
						result = x.Variables.GetVector3(this.variableKey).z.CompareTo(
							y.Variables.GetVector3(this.variableKey).z);
					}
					if(result == 0 &&
						x is IContent &&
						y is IContent)
					{
						return ((IContent)x).GetName().CompareTo(((IContent)y).GetName());
					}
					return result;
				}
			}
		}
	}
}
