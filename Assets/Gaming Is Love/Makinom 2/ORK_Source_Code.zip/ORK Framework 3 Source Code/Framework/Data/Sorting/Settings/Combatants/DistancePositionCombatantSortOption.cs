﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Distance (Position)", "Sort the combatants by distance to a defined position.", "")]
	public class DistancePositionCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Position")]
		public Vector3Value<T> position = new Vector3Value<T>();

		[EditorHelp("Invert Order", "Invert the sort order, i.e. the farthest combatant will be the first in the list.")]
		public bool invertOrder = false;

		[EditorHelp("Ignore Distance", "Enable the axes that will be ignored for the distance check.")]
		public AxisBool ignoreDistance = new AxisBool();

		public DistancePositionCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "Distance(" + this.position.ToString() + ")";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{
			list.Sort(new CombatantPositionDistanceSorter(this.position.GetValue(call), this.ignoreDistance, this.invertOrder));
		}
	}
}
