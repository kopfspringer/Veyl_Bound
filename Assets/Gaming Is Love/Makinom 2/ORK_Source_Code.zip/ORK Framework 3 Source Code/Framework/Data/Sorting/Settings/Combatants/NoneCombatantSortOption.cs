﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("None", "Doesn't sort the combatants, keeping the current order.", "")]
	public class NoneCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		public NoneCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "None";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{

		}
	}
}
