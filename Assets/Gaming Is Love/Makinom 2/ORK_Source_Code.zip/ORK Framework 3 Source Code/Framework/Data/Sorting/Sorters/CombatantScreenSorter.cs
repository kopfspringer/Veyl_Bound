﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CombatantScreenSorter : IComparer<Combatant>
	{
		private float origin;

		private bool inverse = false;

		public CombatantScreenSorter(float origin, bool inverse)
		{
			this.origin = origin;
			this.inverse = inverse;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(inverse)
			{
				if(x.GameObject == null &&
					y.GameObject == null)
				{
					return 0;
				}
				else if(x.GameObject != null &&
					y.GameObject == null)
				{
					return 1;
				}
				else if(x.GameObject == null &&
					y.GameObject != null)
				{
					return -1;
				}
				else
				{
					float xComPos = VectorHelper.WorldToScreenPosition(x.GameObject.transform.position).x - this.origin;
					float yComPos = VectorHelper.WorldToScreenPosition(y.GameObject.transform.position).x - this.origin;

					if(xComPos < 0 && yComPos >= 0)
					{
						return -1;
					}
					else if(xComPos >= 0 && yComPos < 0)
					{
						return 1;
					}
					return yComPos.CompareTo(xComPos);
				}
			}
			else
			{
				if(x.GameObject == null &&
					y.GameObject == null)
				{
					return 0;
				}
				else if(x.GameObject != null &&
					y.GameObject == null)
				{
					return -1;
				}
				else if(x.GameObject == null &&
					y.GameObject != null)
				{
					return 1;
				}
				else
				{
					float xComPos = VectorHelper.WorldToScreenPosition(x.GameObject.transform.position).x - this.origin;
					float yComPos = VectorHelper.WorldToScreenPosition(y.GameObject.transform.position).x - this.origin;

					if(xComPos < 0 && yComPos >= 0)
					{
						return 1;
					}
					else if(xComPos >= 0 && yComPos < 0)
					{
						return -1;
					}
					return xComPos.CompareTo(yComPos);
				}
			}
		}
	}
}
