﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Attack Modifier Value", "Sort the combatants by an attack modifier's value.", "")]
	public class AttackModifierValueCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		public AttackModifierAttributeSelection selection = new AttackModifierAttributeSelection();

		[EditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the modifier attribute.\n" +
			"- Base Value: The base value of the modifier attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the modifier attribute.\n" +
			"- Max Value: The maximum value of the modifier attribute.\n" +
			"- Start Value: The start value of the modifier attribute (i.e. the modifier attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		public ModifierGetValue getValue = ModifierGetValue.CurrentValue;

		[EditorHelp("Invert Order", "Invert the sort order, i.e. sorting from highest to lowest value.")]
		public bool invertOrder = false;

		public AttackModifierValueCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "Attack Modifier(" + this.selection.ToString() + ")";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{
			list.Sort(new AttackModifierValueSorter(this.selection, this.getValue, this.invertOrder));
		}
	}
}
