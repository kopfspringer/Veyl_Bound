﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public class EditorBattleGridFormationControl
	{
		// edit modes
		// -1 > default
		// -2 > change leader position
		// 0+ > change indexed position
		private int editIndex = -1;

		private bool isDoubleClick = false;


		// cell sizes
		private static int CellSize = 25;

		private static int CellOffset = 5;

		private static int CellCombined = 30;


		// GUIStyles
		private static GUIStyle frontLabelStyle;

		private static GUIStyle priorityLabelStyle;

		private static GUIStyle squareCellStyle;

		private static GUIStyle squareCellLeaderStyle;

		private static GUIStyle squareCellPositionStyle;

		private static GUIStyle hexagonalCellStyle;

		private static GUIStyle hexagonalCellLeaderStyle;

		private static GUIStyle hexagonalCellPositionStyle;

		public EditorBattleGridFormationControl()
		{
			if(EditorBattleGridFormationControl.frontLabelStyle == null)
			{
				System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();

				EditorBattleGridFormationControl.frontLabelStyle = new GUIStyle(GUI.skin.label);
				EditorBattleGridFormationControl.frontLabelStyle.alignment = TextAnchor.MiddleCenter;
				EditorBattleGridFormationControl.frontLabelStyle.fontStyle = FontStyle.Bold;

				EditorBattleGridFormationControl.priorityLabelStyle = new GUIStyle(GUI.skin.label);
				EditorBattleGridFormationControl.priorityLabelStyle.alignment = TextAnchor.UpperRight;
				EditorBattleGridFormationControl.priorityLabelStyle.fontSize = 9;
				EditorBattleGridFormationControl.priorityLabelStyle.padding = new RectOffset(0, 0, 0, 0);
				EditorBattleGridFormationControl.priorityLabelStyle.normal.textColor = Color.green;

				// square grid cells
				EditorBattleGridFormationControl.squareCellStyle = new GUIStyle();
				EditorBattleGridFormationControl.squareCellStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.square_grid_cell.png",
					25, 25);
				EditorBattleGridFormationControl.squareCellStyle.normal.textColor = Color.white;
				EditorBattleGridFormationControl.squareCellStyle.fixedWidth = 25;
				EditorBattleGridFormationControl.squareCellStyle.fixedHeight = 25;
				EditorBattleGridFormationControl.squareCellStyle.border = new RectOffset(0, 0, 0, 0);
				EditorBattleGridFormationControl.squareCellStyle.overflow = new RectOffset(0, 0, 0, 0);
				EditorBattleGridFormationControl.squareCellStyle.alignment = TextAnchor.MiddleCenter;

				EditorBattleGridFormationControl.squareCellLeaderStyle = new GUIStyle(EditorBattleGridFormationControl.squareCellStyle);
				EditorBattleGridFormationControl.squareCellLeaderStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.square_grid_cell_center_selected.png",
					25, 25);

				EditorBattleGridFormationControl.squareCellPositionStyle = new GUIStyle(EditorBattleGridFormationControl.squareCellStyle);
				EditorBattleGridFormationControl.squareCellPositionStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.square_grid_cell_selected.png",
					25, 25);

				// hexagonal grid cells
				EditorBattleGridFormationControl.hexagonalCellStyle = new GUIStyle(EditorBattleGridFormationControl.squareCellStyle);
				EditorBattleGridFormationControl.hexagonalCellStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.hexagonal_grid_cell.png",
					25, 25);

				EditorBattleGridFormationControl.hexagonalCellLeaderStyle = new GUIStyle(EditorBattleGridFormationControl.squareCellStyle);
				EditorBattleGridFormationControl.hexagonalCellLeaderStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.hexagonal_grid_cell_center_selected.png",
					25, 25);

				EditorBattleGridFormationControl.hexagonalCellPositionStyle = new GUIStyle(EditorBattleGridFormationControl.squareCellStyle);
				EditorBattleGridFormationControl.hexagonalCellPositionStyle.normal.background = EditorContent.LoadImage(assembly,
					"GamingIsLove.ORKFramework.Editor.Images.Grid.hexagonal_grid_cell_selected.png",
					25, 25);
			}
		}

		public int EditIndex
		{
			get { return this.editIndex; }
			set { this.editIndex = value; }
		}

		public void Edit(BattleGridFormation formation)
		{
			if(formation != null)
			{
				if(BattleGridType.Square == ORK.BattleGridSettings.type)
				{
					// max rows/columns
					this.CheckMaxSize(formation, false);

					// legend
					EditorGUILayout.BeginVertical();
					GUILayout.Label(new GUIContent("Empty Cell", EditorBattleGridFormationControl.squareCellStyle.normal.background));
					GUILayout.Label(new GUIContent("Formation Leader", EditorBattleGridFormationControl.squareCellLeaderStyle.normal.background));
					GUILayout.Label(new GUIContent("Formation Position", EditorBattleGridFormationControl.squareCellPositionStyle.normal.background));
					EditorGUILayout.EndVertical();

					EditorGUILayout.Separator();

					// grid display
					Rect rect = this.ShowInfo(formation);

					for(int row = 0; row < formation.rows; row++)
					{
						for(int column = 0; column < formation.columns; column++)
						{
							Rect cellRect = new Rect(rect.x + column * EditorBattleGridFormationControl.CellCombined,
								rect.y + row * EditorBattleGridFormationControl.CellCombined,
								EditorBattleGridFormationControl.CellSize, EditorBattleGridFormationControl.CellSize);

							this.EditCell(formation, ref cellRect, ref row, ref column, false,
								EditorBattleGridFormationControl.squareCellStyle,
								EditorBattleGridFormationControl.squareCellLeaderStyle,
								EditorBattleGridFormationControl.squareCellPositionStyle);
						}
					}
				}
				else if(BattleGridType.Hexagonal == ORK.BattleGridSettings.type)
				{
					// max rows/columns
					this.CheckMaxSize(formation, true);

					EditorGUILayout.HelpBox("All hexagonal grids are displayed as vertical (flat topped) grids.\n" +
						"For horizontal grids, the world space front will be rotated to the left by 30°.",
						MessageType.None);

					// legend
					EditorGUILayout.BeginVertical();
					GUILayout.Label(new GUIContent("Empty Cell", EditorBattleGridFormationControl.hexagonalCellStyle.normal.background));
					GUILayout.Label(new GUIContent("Formation Leader", EditorBattleGridFormationControl.hexagonalCellLeaderStyle.onNormal.background));
					GUILayout.Label(new GUIContent("Formation Position", EditorBattleGridFormationControl.hexagonalCellStyle.onNormal.background));
					EditorGUILayout.EndVertical();

					EditorGUILayout.Separator();

					// grid display
					Rect rect = this.ShowInfo(formation);

					for(int row = 0; row < formation.rows; row++)
					{
						for(int column = 0; column < formation.columns; column++)
						{
							float colMod = column % 2;
							Rect cellRect = new Rect(rect.x + column * EditorBattleGridFormationControl.CellCombined,
								rect.y + (row + (colMod * 0.5f)) * EditorBattleGridFormationControl.CellCombined,
								EditorBattleGridFormationControl.CellSize, EditorBattleGridFormationControl.CellSize);

							this.EditCell(formation, ref cellRect, ref row, ref column, true,
								EditorBattleGridFormationControl.hexagonalCellStyle,
								EditorBattleGridFormationControl.hexagonalCellLeaderStyle,
								EditorBattleGridFormationControl.hexagonalCellPositionStyle);
						}
					}
				}

				if(this.isDoubleClick &&
					Event.current.type == EventType.MouseUp &&
					!Event.current.shift)
				{
					this.isDoubleClick = false;
				}

				EditorTool.CheckHelpText("Grid Formation Mask", "Left-click on grid cells to place leader/positions.\n" +
					"Right-click to remove a placed position, the leader can only be removed when all positions have been removed.\n" +
					"Double-left-click to change the cell of an already placed leader/position.\n" +
					"Hold shift and left-click or right-click to change the priority of a position (green number).", "");
			}
		}

		private Rect ShowInfo(BattleGridFormation formation)
		{
			if(this.editIndex == -2)
			{
				EditorTool.Label("Changing Leader Position");
			}
			else if(this.editIndex >= 0)
			{
				EditorTool.Label("Changing Position " + this.editIndex);
			}
			else if(formation.leader.row == -1)
			{
				EditorTool.Label("Place Leader");
			}
			else
			{
				EditorTool.Label("Place Position " + formation.position.Length);
			}

			int columnSize = 10 + formation.columns * EditorBattleGridFormationControl.CellSize +
				(formation.columns - 1) * EditorBattleGridFormationControl.CellOffset;
			int rowSize = 10 + formation.rows * EditorBattleGridFormationControl.CellSize +
				(formation.rows - 1) * EditorBattleGridFormationControl.CellOffset;

			GUILayout.Label("Front", EditorBattleGridFormationControl.frontLabelStyle, GUILayout.Width(columnSize));
			return GUILayoutUtility.GetRect(columnSize, rowSize);
		}

		private void EditCell(BattleGridFormation formation,
			ref Rect cellRect, ref int row, ref int column, bool isHexagonal,
			GUIStyle emptyStyle, GUIStyle leaderStyle, GUIStyle positionStyle)
		{
			if(Event.current.type == EventType.MouseDown &&
				!Event.current.shift &&
				Event.current.clickCount == 2 &&
				cellRect.Contains(Event.current.mousePosition))
			{
				this.isDoubleClick = true;
			}

			// place leader
			if(formation.leader.row == -1)
			{
				GUI.Label(cellRect, "", emptyStyle);

				if(Event.current.type == EventType.MouseUp &&
					Event.current.button == 0 &&
					!Event.current.shift &&
					cellRect.Contains(Event.current.mousePosition))
				{
					formation.leader.row = row;
					formation.leader.column = column;
					Event.current.Use();
					GUI.changed = true;
				}
			}
			// is leader
			else if(formation.leader.row == row &&
				formation.leader.column == column)
			{
				GUI.Label(cellRect, "", leaderStyle);

				if(Event.current.type == EventType.MouseUp &&
					!Event.current.shift &&
					cellRect.Contains(Event.current.mousePosition))
				{
					if(Event.current.button == 1)
					{
						if(formation.position.Length == 0)
						{
							formation.leader.row = -1;
							formation.leader.column = -1;
							this.editIndex = -1;
							Event.current.Use();
							GUI.changed = true;
						}
					}
					else if(Event.current.button == 0)
					{
						if(this.editIndex >= 0 &&
							this.editIndex < formation.position.Length)
						{
							int tmpRow = 0;
							int tmpColumn = 0;
							this.GetOffsetFor(formation, this.editIndex, ref tmpRow, ref tmpColumn, isHexagonal);
							this.ChangeLeaderPosition(formation, tmpRow, tmpColumn, isHexagonal);
							this.SetOffsetFor(formation, this.editIndex, row, column, isHexagonal);
							this.editIndex = -1;
							Event.current.Use();
							GUI.changed = true;
						}
						else if(this.editIndex != -1)
						{
							this.editIndex = -1;
							Event.current.Use();
							GUI.changed = true;
						}
						else if(this.editIndex == -1 &&
							this.isDoubleClick)
						{
							this.editIndex = -2;
							this.isDoubleClick = false;
							Event.current.Use();
							GUI.changed = true;
						}
					}
				}
			}
			// other positions
			else
			{
				int positionIndex = this.GetPositionFor(formation, row, column, isHexagonal);
				int relativeRow = row - formation.leader.row;
				int relativeColumn = column - formation.leader.column;

				// is position
				if(positionIndex >= 0)
				{
					GUI.Label(cellRect, positionIndex.ToString(), positionStyle);
					GUI.Label(cellRect, formation.position[positionIndex].priority.ToString(), EditorBattleGridFormationControl.priorityLabelStyle);

					if(BattleGridFormationRotation.Select == formation.position[positionIndex].setRotation)
					{
						Color tmp = Handles.color;
						Handles.color = Color.yellow;
						Handles.DrawLine(cellRect.center, VectorHelper.CirclePosition(
							cellRect.center, cellRect.height / 2,
							180 + formation.position[positionIndex].rotation * -1));
						Handles.color = tmp;
					}

					if(Event.current.type == EventType.MouseUp &&
						cellRect.Contains(Event.current.mousePosition))
					{
						if(Event.current.shift)
						{
							if(this.editIndex == -1)
							{
								if(Event.current.button == 0)
								{
									formation.position[positionIndex].priority++;
									Event.current.Use();
									GUI.changed = true;
								}
								else if(Event.current.button == 1)
								{
									formation.position[positionIndex].priority--;
									if(formation.position[positionIndex].priority < 0)
									{
										formation.position[positionIndex].priority = 0;
									}
									Event.current.Use();
									GUI.changed = true;
								}
							}
						}
						else
						{
							if(Event.current.button == 1)
							{
								ArrayHelper.RemoveAt(ref formation.position, positionIndex);
								this.editIndex = -1;
								Event.current.Use();
								GUI.changed = true;
							}
							else if(Event.current.button == 0)
							{
								if(this.editIndex == positionIndex)
								{
									this.editIndex = -1;
									Event.current.Use();
									GUI.changed = true;
								}
								else if(this.editIndex == -2)
								{
									int tmpRow = formation.leader.row;
									int tmpColumn = formation.leader.column;
									this.ChangeLeaderPosition(formation, row, column, isHexagonal);
									this.SetOffsetFor(formation, positionIndex, tmpRow, tmpColumn, isHexagonal);
									this.editIndex = -1;
									Event.current.Use();
									GUI.changed = true;
								}
								else if(this.editIndex >= 0 &&
									this.editIndex < formation.position.Length)
								{
									int tmpRow = 0;
									int tmpColumn = 0;
									this.GetOffsetFor(formation, this.editIndex, ref tmpRow, ref tmpColumn, isHexagonal);
									this.SetOffsetFor(formation, positionIndex, tmpRow, tmpColumn, isHexagonal);
									this.SetOffsetFor(formation, this.editIndex, row, column, isHexagonal);
									this.editIndex = -1;
									Event.current.Use();
									GUI.changed = true;
								}
								else if(this.editIndex != -1)
								{
									this.editIndex = -1;
									Event.current.Use();
									GUI.changed = true;
								}
								else if(this.editIndex == -1 &&
									this.isDoubleClick)
								{
									this.editIndex = positionIndex;
									this.isDoubleClick = false;
									Event.current.Use();
									GUI.changed = true;
								}
							}
						}
					}
				}
				// empty cell
				else
				{
					GUI.Label(cellRect, "", emptyStyle);

					if(Event.current.type == EventType.MouseUp &&
						Event.current.button == 0 &&
						!Event.current.shift &&
						cellRect.Contains(Event.current.mousePosition))
					{
						if(this.editIndex == -1)
						{
							ArrayHelper.Add(ref formation.position,
								new BattleGridFormationPosition(isHexagonal ?
									CubeCoord.FromVerticalOdd(relativeRow, relativeColumn) :
									CubeCoord.FromOffset(relativeRow, relativeColumn)));
							this.editIndex = -1;
							Event.current.Use();
							GUI.changed = true;
						}
						else if(this.editIndex == -2)
						{
							this.ChangeLeaderPosition(formation, row, column, isHexagonal);
							this.editIndex = -1;
							Event.current.Use();
							GUI.changed = true;
						}
						else if(this.editIndex >= 0 &&
							this.editIndex < formation.position.Length)
						{
							this.SetOffsetFor(formation, this.editIndex, row, column, isHexagonal);
							this.editIndex = -1;
							Event.current.Use();
							GUI.changed = true;
						}
						else if(this.editIndex != -1)
						{
							this.editIndex = -1;
							Event.current.Use();
							GUI.changed = true;
						}
					}
				}
			}
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		private void CheckMaxSize(BattleGridFormation formation, bool isHexagonal)
		{
			this.CheckMaxSize(formation, formation.leader.row, formation.leader.column);

			for(int i = 0; i < formation.position.Length; i++)
			{
				int row = 0;
				int column = 0;
				if(isHexagonal)
				{
					formation.position[i].coord.ToVerticalOdd(ref row, ref column);
				}
				else
				{
					formation.position[i].coord.ToOffset(ref row, ref column);
				}
				this.CheckMaxSize(formation, row + formation.leader.row, column + formation.leader.column);
			}
		}

		private void CheckMaxSize(BattleGridFormation formation, int row, int column)
		{
			if(formation.rows <= row)
			{
				formation.rows = row + 1;
			}
			if(formation.columns <= column)
			{
				formation.columns = column + 1;
			}
		}

		private void GetOffsetFor(BattleGridFormation formation, int index, ref int row, ref int column, bool isHexagonal)
		{
			if(index >= 0 &&
				index < formation.position.Length)
			{
				if(isHexagonal)
				{
					formation.position[index].coord.ToVerticalOdd(ref row, ref column);
				}
				else
				{
					formation.position[index].coord.ToOffset(ref row, ref column);
				}
				row += formation.leader.row;
				column += formation.leader.column;
			}
		}

		private void SetOffsetFor(BattleGridFormation formation, int index, int row, int column, bool isHexagonal)
		{
			if(index >= 0 &&
				index < formation.position.Length)
			{
				if(isHexagonal)
				{
					formation.position[index].coord.Set(CubeCoord.FromVerticalOdd(
						row - formation.leader.row, column - formation.leader.column));
				}
				else
				{
					formation.position[index].coord.Set(CubeCoord.FromOffset(
						row - formation.leader.row, column - formation.leader.column));
				}
			}
		}

		private int GetPositionFor(BattleGridFormation formation, int row, int column, bool isHexagonal)
		{
			row -= formation.leader.row;
			column -= formation.leader.column;

			for(int i = 0; i < formation.position.Length; i++)
			{
				int tmpRow = 0;
				int tmpColumn = 0;
				if(isHexagonal)
				{
					formation.position[i].coord.ToVerticalOdd(ref tmpRow, ref tmpColumn);
				}
				else
				{
					formation.position[i].coord.ToOffset(ref tmpRow, ref tmpColumn);
				}
				if(row == tmpRow &&
					column == tmpColumn)
				{
					return i;
				}
			}
			return -1;
		}

		private void ChangeLeaderPosition(BattleGridFormation formation, int row, int column, bool isHexagonal)
		{
			for(int i = 0; i < formation.position.Length; i++)
			{
				int tmpRow = 0;
				int tmpColumn = 0;

				if(isHexagonal)
				{
					formation.position[i].coord.ToVerticalOdd(ref tmpRow, ref tmpColumn);
				}
				else
				{
					formation.position[i].coord.ToOffset(ref tmpRow, ref tmpColumn);
				}

				tmpRow += formation.leader.row;
				tmpColumn += formation.leader.column;

				if(isHexagonal)
				{
					formation.position[i].coord.Set(CubeCoord.FromVerticalOdd(
						tmpRow - row, tmpColumn - column));
				}
				else
				{
					formation.position[i].coord.Set(CubeCoord.FromOffset(
						tmpRow - row, tmpColumn - column));
				}
			}

			formation.leader.row = row;
			formation.leader.column = column;
		}
	}
}
