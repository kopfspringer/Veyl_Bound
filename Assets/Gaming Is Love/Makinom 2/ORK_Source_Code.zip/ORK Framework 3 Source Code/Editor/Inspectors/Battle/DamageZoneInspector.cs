
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(DamageZone))]
public class DamageZoneInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as DamageZone);
	}

	protected virtual void ComponentSetup(DamageZone target)
	{
		Undo.RecordObject(target, "Change to 'Damage Zone' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}
