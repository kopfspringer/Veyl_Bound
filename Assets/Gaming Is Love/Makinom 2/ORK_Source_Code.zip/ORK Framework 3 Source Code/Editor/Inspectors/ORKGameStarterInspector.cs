
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(ORKGameStarter))]
public class ORKGameStarterInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as ORKGameStarter);
	}

	private void ComponentSetup(ORKGameStarter target)
	{
		Undo.RecordObject(target, "Change to 'ORK Game Starter' on " + target.name);
		this.BaseInit(false);

		// settings
		if(this.baseEditor.BeginFoldout("ORK Game Start Settings", "", "", true))
		{
			if(this.ShowGameStarterProjectSettings(target))
			{
				target.loadStartMenuScene = EditorGUILayout.Toggle("Load Start Menu Scene", target.loadStartMenuScene);
				if(!target.loadStartMenuScene)
				{
					target.callStartMenu = EditorGUILayout.Toggle("Call Start Menu", target.callStartMenu);
					if(target.callStartMenu)
					{
						target.startGame = false;
						target.callAfter = EditorGUILayout.FloatField("Call After (s)", target.callAfter);
						if(target.callAfter < 0)
						{
							target.callAfter = 0;
						}
					}
					else
					{
						target.startGame = EditorGUILayout.Toggle("Start Game", target.startGame);
					}
				}

				target.schematicAsset = (GamingIsLove.Makinom.MakinomSchematicAsset)EditorGUILayout.ObjectField(
					"Start Schematic Asset", target.schematicAsset, typeof(GamingIsLove.Makinom.MakinomSchematicAsset), false);
			}

			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.EndSetup();
	}
}
