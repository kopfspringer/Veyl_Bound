
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class AbilityTypesTab : ORKGenericAssetListTab<AbilityTypeAsset, AbilityType>
	{
		public AbilityTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.AbilityTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.AbilityTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Ability Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Ability types are used to separate abilities.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/abilities/"; }
		}
	}
}

