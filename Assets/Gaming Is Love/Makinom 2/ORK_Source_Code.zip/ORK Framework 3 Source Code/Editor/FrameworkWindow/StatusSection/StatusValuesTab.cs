
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class StatusValuesTab : ORKGenericAssetListTab<StatusValueAsset, StatusValueSetting>
	{
		private bool editValues = false;

		private int minValue = 1;

		private int maxValue = 1;

		public StatusValuesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.StatusValues.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.StatusValues.SetAssets(this.assetList.Assets);
		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				StatusValueAsset maxHP = ScriptableObject.CreateInstance<StatusValueAsset>();
				maxHP.Settings = new StatusValueSetting("Max HP", 0, 9999);
				this.assetList.Add(maxHP);

				StatusValueAsset hp = ScriptableObject.CreateInstance<StatusValueAsset>();
				hp.Settings = new StatusValueSetting("HP", maxHP, StatusValueDeathType.OnMinimum, true);
				this.assetList.Add(hp);

				StatusValueAsset maxMP = ScriptableObject.CreateInstance<StatusValueAsset>();
				maxMP.Settings = new StatusValueSetting("Max MP", 0, 999);
				this.assetList.Add(maxMP);

				StatusValueAsset mp = ScriptableObject.CreateInstance<StatusValueAsset>();
				mp.Settings = new StatusValueSetting("MP", maxMP, StatusValueDeathType.None, false);
				this.assetList.Add(mp);

				StatusValueAsset exp = ScriptableObject.CreateInstance<StatusValueAsset>();
				exp.Settings = new StatusValueSetting("EXP", ExperienceType.Level);
				this.assetList.Add(exp);

				StatusValueAsset atk = ScriptableObject.CreateInstance<StatusValueAsset>();
				atk.Settings = new StatusValueSetting("ATK", 1, 255);
				this.assetList.Add(atk);

				StatusValueAsset def = ScriptableObject.CreateInstance<StatusValueAsset>();
				def.Settings = new StatusValueSetting("DEF", 1, 255);
				this.assetList.Add(def);
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Status Values"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up status values like health, MP, strength or experience.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/status-values/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<StatusTypeAsset, StatusType>(
							new string[] { "Status Type", "Filter the status value list by status type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			return this.Filter.assetFilterSelection[0].Check(
				this.assetList.Assets[index].Settings.statusType.Source.EditorAsset);
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void SettingChanged(IBaseData instance, string fieldName, object newValue)
		{
			StatusValueSetting statusValue = this.CurrentSettings;
			if(instance == statusValue &&
				fieldName == "type")
			{
				if(StatusValueType.Consumable == statusValue.type)
				{
					statusValue.startValue = 100;
					statusValue.startSetIn = ValueSetter.Percent;
				}
				else if(StatusValueType.Experience == statusValue.type)
				{
					statusValue.startValue = 0;
					statusValue.startSetIn = ValueSetter.Value;
				}
				else if(StatusValueType.Normal == statusValue.type)
				{
					statusValue.startValue = 1;
					statusValue.startSetIn = ValueSetter.Value;
				}
				EditorDataHelper.SetStatusValueType(statusValue, statusValue.type);
			}
		}

		public override void AutomationCallback(string info)
		{
			if(info == "edit:minmaxvalue")
			{
				StatusValueSetting statusValue = this.CurrentSettings;
				if(statusValue != null &&
					!statusValue.IsConsumable())
				{
					EditorGUILayout.Separator();
					EditorTool.BoldLabel("Value Range");
					EditorAutomation.Automate("useOtherMinMax", statusValue, this, true);
					EditorAutomation.Automate("otherMin", statusValue, this, true);
					EditorAutomation.Automate("otherMax", statusValue, this, true);

					if(!statusValue.useOtherMinMax)
					{
						if(this.editValues)
						{
							EditorAutomation.Automate("minValue", statusValue, this, true);
							EditorAutomation.Automate("maxValue", statusValue, this, true);

							EditorGUILayout.BeginHorizontal();
							if(EditorTool.SmallButton("Cancel", "Cancel editing the value range, all changes will be lost.", ""))
							{
								this.editValues = false;
								statusValue.minValue = this.minValue;
								statusValue.maxValue = this.maxValue;
							}
							if(EditorTool.SmallButton("Ok", "End editing the value range and accept the changes.", ""))
							{
								this.editValues = false;
								EditorDataHelper.StatusValueMinMaxChanged(statusValue);
							}
							GUILayout.FlexibleSpace();
							EditorGUILayout.EndHorizontal();
						}
						else
						{
							EditorTool.Label("Minimum Value: " + statusValue.minValue);
							EditorTool.Label("Maximum Value: " + statusValue.maxValue);

							if(EditorTool.Button(new GUIContent("Edit Value Range", EditorContent.Instance.EditIcon),
								"Change the minimum and maximum value of this status value.", ""))
							{
								this.editValues = true;
								this.minValue = statusValue.minValue;
								this.maxValue = statusValue.maxValue;
							}
						}
					}
				}
			}
			else if(info == "check:exptype")
			{
				StatusValueSetting statusValue = this.CurrentSettings;
				if(statusValue != null)
				{
					if(ExperienceType.Level == statusValue.expType)
					{
						for(int i = 0; i < this.assetList.Count; i++)
						{
							if(this.assetList.Assets[i].Settings != statusValue)
							{
								if(ExperienceType.Level == this.assetList.Assets[i].Settings.expType)
								{
									this.assetList.Assets[i].Settings.expType = ExperienceType.None;
								}
							}
						}
					}
					else if(ExperienceType.ClassLevel == statusValue.expType)
					{
						for(int i = 0; i < this.assetList.Count; i++)
						{
							if(this.assetList.Assets[i].Settings != statusValue)
							{
								if(ExperienceType.ClassLevel == this.assetList.Assets[i].Settings.expType)
								{
									this.assetList.Assets[i].Settings.expType = ExperienceType.None;
								}
							}
						}
					}
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}

