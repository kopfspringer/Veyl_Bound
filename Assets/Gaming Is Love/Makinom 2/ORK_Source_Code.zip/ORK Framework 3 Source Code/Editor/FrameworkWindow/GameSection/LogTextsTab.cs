
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class LogTextsTab : ORKGenericAssetListTab<LogTextAsset, LogText>
	{
		public LogTextsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.LogTexts.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.LogTexts.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Log Texts"; }
		}

		public override string HelpText
		{
			get
			{
				return "Log texts are added to logs to make information available to the player (e.g. via a menu screen).";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/logs/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<LogTypeAsset, LogType>(
							new string[] { "Log Type", "Filter the log text list by log type.", "" }),
						new FilteredListAssetSelection<LogAsset, Log>(
							new string[] { "Log", "Filter the log text list by log.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				LogType type = this.Filter.assetFilterSelection[0].Selection as LogType;
				if(this.assetList.Assets[index].Settings.log.Source.EditorAsset != null &&
					((LogAsset)(object)this.assetList.Assets[index].Settings.log.Source.EditorAsset).Settings.IsType(type, false))
				{
					return this.Filter.assetFilterSelection[1].Check(
						this.assetList.Assets[index].Settings.log.Source.EditorAsset);
				}
				return false;
			}
			return this.Filter.assetFilterSelection[1].Check(
				this.assetList.Assets[index].Settings.log.Source.EditorAsset);
		}
	}
}
