
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class QuestTasksTab : ORKGenericAssetListTab<QuestTaskAsset, QuestTaskSetting>
	{
		public QuestTasksTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.QuestTasks.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.QuestTasks.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Quest Tasks"; }
		}

		public override string HelpText
		{
			get
			{
				return "Quest tasks are used to track progress and give rewards in quests.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/quests/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<QuestTypeAsset, QuestType>(
							new string[] { "Quest Type", "Filter the task list by quest type.", "" }),
						new FilteredListAssetSelection<QuestAsset, QuestSetting>(
							new string[] { "Quest", "Filter the task list by quest.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				QuestType type = this.Filter.assetFilterSelection[0].Selection as QuestType;
				if(this.assetList.Assets[index].Settings.quest.Source.EditorAsset != null &&
					((QuestAsset)(object)this.assetList.Assets[index].Settings.quest.Source.EditorAsset).Settings.IsType(type, false))
				{
					return this.Filter.assetFilterSelection[1].Check(
						this.assetList.Assets[index].Settings.quest.Source.EditorAsset);
				}
				return false;
			}
			return this.Filter.assetFilterSelection[1].Check(
				this.assetList.Assets[index].Settings.quest.Source.EditorAsset);
		}
	}
}
