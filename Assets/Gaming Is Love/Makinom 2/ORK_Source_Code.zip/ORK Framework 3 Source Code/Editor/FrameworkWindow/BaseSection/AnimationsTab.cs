
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework.Animations;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public class AnimationsTab : ORKGenericAssetListTab<AnimationAsset, AnimationSetting>
	{
		private GameObject prefab;

		private RuntimeAnimatorController animatorController;

		public AnimationsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Animations"; }
		}

		public override string HelpText
		{
			get
			{
				return "Animations are used to play animations on combatants.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/animations/"; }
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "button:loadlegacyanimationfromprefab")
			{
				EditorTool.BoldLabel("Load From Prefab");
				EditorGUILayout.HelpBox("Load animations added to a prefab (via 'Animation' component).", MessageType.Info);
				this.prefab = (GameObject)EditorGUILayout.ObjectField("Prefab",
					this.prefab, typeof(GameObject), false, EditorTool.WIDTH);

				EditorGUI.BeginDisabledGroup(this.prefab == null);
				if(EditorTool.Button(new GUIContent("Load Animations", EditorContent.Instance.AddIcon,
						"Adds the animations found on the prefab to the legacy animations."),
					EditorTool.WIDTH))
				{
					AnimationSetting setting = this.CurrentSettings;
					if(setting != null &&
						this.prefab != null)
					{
						Animation animation = this.prefab.GetComponentInChildren<Animation>();
						if(animation != null)
						{
							List<ORKLegacyAnimation> list = new List<ORKLegacyAnimation>(setting.legacy);
							foreach(AnimationState state in animation)
							{
								if(state != null &&
									state.clip != null)
								{
									ORKLegacyAnimation newAnimation = new ORKLegacyAnimation();
									newAnimation.animation[0].name = state.clip.name;
									list.Add(newAnimation);
								}
							}
							setting.legacy = list.ToArray();
							this.prefab = null;
						}
					}
				}
				EditorGUI.EndDisabledGroup();
			}
			else if(info == "button:loadmecanimanimationfromprefab")
			{
				if(this.BeginFoldout("Load From Animator Controller", "Load animation states (not blend trees) added to an animator controller.", "", true))
				{
					EditorGUILayout.HelpBox("Load animation states (not blend trees) added to an animator controller.", MessageType.Info);
					this.animatorController = (RuntimeAnimatorController)EditorGUILayout.ObjectField("Animator Controller",
						this.animatorController, typeof(RuntimeAnimatorController), false, EditorTool.WIDTH);

					EditorGUI.BeginDisabledGroup(this.animatorController == null);
					if(EditorTool.Button(new GUIContent("Load Animations", EditorContent.Instance.AddIcon,
							"Adds the animation states (not blend trees) found in the animator controller to the Mecanim animations."),
						EditorTool.WIDTH))
					{
						AnimationSetting setting = this.CurrentSettings;
						if(setting != null &&
							this.animatorController != null)
						{
							if(this.animatorController is AnimatorOverrideController)
							{
								AnimatorOverrideController overrideController = this.animatorController as AnimatorOverrideController;
								if(overrideController != null &&
									overrideController.runtimeAnimatorController != null)
								{
									AnimatorController controller = overrideController.runtimeAnimatorController as AnimatorController;
									if(controller != null)
									{
										List<ORKMecanimAnimation> list = new List<ORKMecanimAnimation>(setting.mecanim);
										for(int i = 0; i < controller.layers.Length; i++)
										{
											foreach(ChildAnimatorState state in controller.layers[i].stateMachine.states)
											{
												if(state.state != null &&
													state.state.motion is AnimationClip)
												{
													AnimationClip clip = state.state.motion as AnimationClip;
													if(clip != null)
													{
														AnimationClip newClip = overrideController[clip];
														if(newClip != null)
														{
															clip = newClip;
														}

														ORKMecanimAnimation newAnimation = new ORKMecanimAnimation();
														newAnimation.animation[0].name = state.state.name;
														newAnimation.animation[0].layer = i;
														newAnimation.animation[0].durationType = MecanimDurationType.AnimationClip;
														if(state.state.name == clip.name)
														{
															newAnimation.animation[0].durationUseState = true;
														}
														else
														{
															newAnimation.animation[0].durationUseState = false;
															newAnimation.animation[0].durationClipName = clip.name;
														}
														list.Add(newAnimation);
													}
												}
											}
										}
										setting.mecanim = list.ToArray();
									}
								}
							}
							else
							{
								AnimatorController controller = this.animatorController as AnimatorController;
								if(controller != null)
								{
									List<ORKMecanimAnimation> list = new List<ORKMecanimAnimation>(setting.mecanim);
									for(int i = 0; i < controller.layers.Length; i++)
									{
										foreach(ChildAnimatorState state in controller.layers[i].stateMachine.states)
										{
											if(state.state != null &&
												state.state.motion is AnimationClip)
											{
												AnimationClip clip = state.state.motion as AnimationClip;
												if(clip != null)
												{
													ORKMecanimAnimation newAnimation = new ORKMecanimAnimation();
													newAnimation.animation[0].name = state.state.name;
													newAnimation.animation[0].layer = i;
													newAnimation.animation[0].durationType = MecanimDurationType.AnimationClip;
													if(state.state.name == clip.name)
													{
														newAnimation.animation[0].durationUseState = true;
													}
													else
													{
														newAnimation.animation[0].durationUseState = false;
														newAnimation.animation[0].durationClipName = clip.name;
													}
													list.Add(newAnimation);
												}
											}
										}
									}
									setting.mecanim = list.ToArray();
								}
							}
							this.animatorController = null;
						}
					}
					EditorGUI.EndDisabledGroup();
				}
				this.EndFoldout();
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
