
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework.Animations;

namespace GamingIsLove.ORKFramework.Editor
{
	public class AnimationTypesTab : ORKGenericAssetListTab<AnimationTypeAsset, AnimationType>
	{
		public AnimationTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				this.assetList.Add(AnimationTypesTab.CreateAsset("Idle", ORK.AnimationTypes.idle));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Walk", ORK.AnimationTypes.walk));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Run", ORK.AnimationTypes.run));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Sprint", ORK.AnimationTypes.sprint));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Jump", ORK.AnimationTypes.jump));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Fall", ORK.AnimationTypes.fall));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Land", ORK.AnimationTypes.land));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Damage", null));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Evade", null));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Death", ORK.AnimationTypes.death));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Revive", ORK.AnimationTypes.revive));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Victory", ORK.AnimationTypes.victory));
				this.assetList.Add(AnimationTypesTab.CreateAsset("Attack", null));

				ORK.AnimationTypes.actionCastIdle.Source.EditorAsset = ORK.AnimationTypes.idle.Source.EditorAsset;
				ORK.AnimationTypes.actionChooseIdle.Source.EditorAsset = ORK.AnimationTypes.idle.Source.EditorAsset;
				ORK.AnimationTypes.actionWaitIdle.Source.EditorAsset = ORK.AnimationTypes.idle.Source.EditorAsset;
				ORK.AnimationTypes.turnEndedIdle.Source.EditorAsset = ORK.AnimationTypes.idle.Source.EditorAsset;
			}
		}

		protected static AnimationTypeAsset CreateAsset(string name, AssetSelection<AnimationTypeAsset> defaultSelection)
		{
			AnimationTypeAsset asset = ScriptableObject.CreateInstance<AnimationTypeAsset>();
			asset.Settings = new AnimationType(name);
			if(defaultSelection != null)
			{
				defaultSelection.Source.EditorAsset = asset;
			}
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Animation Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Animation types are used to play animations on combatants.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/animations/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings for default animation types.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.AnimationTypes; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.AnimationTypes;
				}
				return base.DisplayedSettings;
			}
		}
	}
}

