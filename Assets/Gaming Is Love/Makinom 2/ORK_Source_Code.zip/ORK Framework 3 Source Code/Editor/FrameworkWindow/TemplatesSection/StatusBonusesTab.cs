
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class StatusBonusesTab : ORKGenericAssetListTab<StatusBonusAsset, StatusBonus>
	{
		public StatusBonusesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Status Bonuses"; }
		}

		public override string HelpText
		{
			get
			{
				return "Status bonuses can be used as templates for bonuses given by status effects, equipment, classes and other things.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/status/status-bonuses/"; }
		}
	}
}
