
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.UI;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ShopsTab : ORKGenericAssetListTab<ShopAsset, ShopSetting>
	{
		public ShopsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Shops"; }
		}

		public override string HelpText
		{
			get
			{
				return "Shops are used to purchase items, equipment and other things via 'Shop Interaction' components.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/shops/"; }
		}

		public override void AutomationCallback(string info)
		{
			if(info == "label:exchangemenu")
			{
				if(this.assetList.AssetExists(this.index))
				{
					ShopAsset shop = this.assetList.Assets[this.index];
					if(shop != null &&
						shop.Settings.useInventoryExchangeMenu &&
						shop.Settings.menuScreen.StoredAsset != null &&
						!shop.Settings.menuScreen.StoredAsset.Settings.IsInventoryExchange())
					{
						EditorGUILayout.HelpBox("The selected menu screen doesn't contain an 'Inventory Exchange' menu part.\n" +
							"The menu screen will not be displayed.",
							MessageType.Error);
					}
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}

