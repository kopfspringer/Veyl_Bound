
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class EquipmentTab : ORKGenericAssetListTab<EquipmentAsset, Equipment>
	{
		private int arrayIndex = 0;

		private string[] sections = new string[] { "1" };

		public EquipmentTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Equipment.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Equipment.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Equipment"; }
		}

		public override string HelpText
		{
			get
			{
				return "Equipment is used to give status bonuses to combatants while being equipped.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/equipment/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<ItemTypeAsset, ItemType>(
							new string[] { "Item Type", "Filter the equipment list by item type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				ItemType type = this.Filter.assetFilterSelection[0].Selection as ItemType;
				return this.assetList.Assets[index].Settings.IsType(type, false);
			}
			return true;
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			Equipment equipment = this.CurrentSettings;
			if(equipment != null)
			{
				// equipment level
				// check level index for buttons
				this.CheckArrayIndex(equipment.level.Length);

				// check level index for settings display
				this.CheckArrayIndex(equipment.level.Length);

				// show level settings
				EditorAutomation.Automate(equipment.level[this.arrayIndex], this);

				// level up points
				equipment.level[0].lvlPoints = 0;
				for(int i = 1; i < equipment.level.Length; i++)
				{
					if(equipment.level[i].lvlPoints < equipment.level[i - 1].lvlPoints)
					{
						equipment.level[i].lvlPoints = equipment.level[i - 1].lvlPoints + 1;
					}
				}
			}
		}

		protected override void ShowSearchBarExtension()
		{
			Equipment equipment = this.CurrentSettings;
			if(equipment != null)
			{
				EditorGUILayout.BeginVertical(GUILayout.Height(24));
				EditorGUILayout.BeginHorizontal();
				EditorTool.BoldLabel("Levels");
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.AddIcon, "Add a new level (copy of the last level)."), EditorTool.WIDTH_30))
				{
					ArrayHelper.Add(ref equipment.level, equipment.level[equipment.level.Length - 1].GetCopy());
					this.arrayIndex = equipment.level.Length - 1;
				}
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.CopyIcon, "Copy this level."), EditorTool.WIDTH_30))
				{
					ArrayHelper.Add(ref equipment.level, equipment.level[this.arrayIndex].GetCopy());
					this.arrayIndex = equipment.level.Length - 1;
				}
				EditorGUI.BeginDisabledGroup(equipment.level.Length == 1);
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.RemoveIcon, "Remove this level."), EditorTool.WIDTH_30))
				{
					ArrayHelper.RemoveAt(ref equipment.level, this.arrayIndex);
				}
				EditorGUI.EndDisabledGroup();

				if(this.sections.Length != equipment.level.Length)
				{
					this.sections = new string[equipment.level.Length];
					for(int i = 0; i < this.sections.Length; i++)
					{
						this.sections[i] = (i + 1).ToString();
					}
				}

				EditorTool.SelectionGridCenter("LevelGridSearchbar", ref this.arrayIndex, this.sections, 10, 55);

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
				GUILayout.FlexibleSpace();
				EditorGUILayout.EndVertical();
			}
		}

		private void CheckArrayIndex(int max)
		{
			if(this.arrayIndex < 0)
			{
				this.arrayIndex = 0;
			}
			else if(this.arrayIndex >= max)
			{
				this.arrayIndex = max - 1;
			}
		}


		/*
		============================================================================
		Name/description help labels
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "textcodes:name" ||
				info == "textcodes:shortname")
			{
				EditorGUILayout.HelpBox("<level> = current equipment level",
					MessageType.Info, true);
			}
			else if(info == "textcodes:description" ||
				info == "textcodes:customcontent")
			{
				EditorGUILayout.HelpBox("<bonus> = bonuses\n" +
					"<durability> = equipment durability, <durability1> = durability format 0.0, <durability2> = durability format 0.00\n" +
					"<durabilitymax> = max durability, <durabilitymax1> = max durability format 0.0, <durabilitymax2> = max durability format 0.00\n" +
					"<level> = current equipment level",
					MessageType.Info, true);
			}
			else if(info == "buttons:levels")
			{
				Equipment equipment = this.CurrentSettings;

				if(equipment != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.MediumButton(new GUIContent("Add Level", EditorContent.Instance.AddIcon, "Add a new level (copy of the last level)."),
						"Adds a new equipment level.\n" +
						"The new level is a copy of the last equipment level.", ""))
					{
						ArrayHelper.Add(ref equipment.level, equipment.level[equipment.level.Length - 1].GetCopy());
						this.arrayIndex = equipment.level.Length - 1;
					}
					if(EditorTool.MediumButton(new GUIContent("Copy Level", EditorContent.Instance.CopyIcon, "Copy this level."),
						"The selected equipment level will be copied.", ""))
					{
						ArrayHelper.Add(ref equipment.level, equipment.level[this.arrayIndex].GetCopy());
						this.arrayIndex = equipment.level.Length - 1;
					}
					EditorGUI.BeginDisabledGroup(equipment.level.Length == 1);
					if(EditorTool.MediumButton(new GUIContent("Remove Level", EditorContent.Instance.RemoveIcon, "Remove this level."),
						"The selected equipment level will be removed.", ""))
					{
						ArrayHelper.RemoveAt(ref equipment.level, this.arrayIndex);
					}
					EditorGUI.EndDisabledGroup();
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();

					if(this.sections.Length != equipment.level.Length)
					{
						this.sections = new string[equipment.level.Length];
						for(int i = 0; i < this.sections.Length; i++)
						{
							this.sections[i] = (i + 1).ToString();
						}
					}

					EditorTool.SelectionGridCenter("LevelGrid", ref this.arrayIndex, this.sections, 10, 55);

					EditorTool.Separator(2);
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}

		public override void InstanceCallback(string info, object instance)
		{
			if(info == "button:createslotsettemplate")
			{
				if(instance is EquipmentSlotSet)
				{
					EditorGUILayout.Separator();
					GenericAssetList<EquipmentSlotSetTemplateAsset> assetList = EditorDataHandler.Instance.GetAssets<EquipmentSlotSetTemplateAsset>();
					if(EditorTool.Button(new GUIContent("Create Slot Set Template", EditorContent.Instance.AddIcon),
						"Creates a new equipment paslotrt set template using the defined slot set settings.", ""))
					{
						EquipmentSlotSet slotSet = instance as EquipmentSlotSet;

						EquipmentSlotSetTemplateAsset asset = ScriptableObject.CreateInstance<EquipmentSlotSetTemplateAsset>();
						asset.Settings = new EquipmentSlotSetTemplate("New");
						asset.Settings.slotSet = slotSet.slotSet;
						assetList.Add(asset);

						slotSet.type = EquipmentSlotSetType.Template;
						slotSet.template = new AssetSelection<EquipmentSlotSetTemplateAsset>();
						slotSet.template.Source.EditorAsset = asset;
					}
				}
			}
			else if(info == "button:equipableon")
			{
				EquipableOn setting = instance as EquipableOn;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<EquipmentSlotAsset>> list = new List<AssetSelection<EquipmentSlotAsset>>();
						GenericAssetList<EquipmentSlotAsset> equipmentSlots = EditorDataHandler.Instance.GetAssets<EquipmentSlotAsset>();
						for(int i = 0; i < equipmentSlots.Count; i++)
						{
							AssetSelection<EquipmentSlotAsset> newSlot = new AssetSelection<EquipmentSlotAsset>();
							newSlot.Source.EditorAsset = equipmentSlots.Assets[i];
							list.Add(newSlot);
						}
						setting.equipSlot = list.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						setting.equipSlot = new AssetSelection<EquipmentSlotAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else if(info == "button:blockslot")
			{
				EquipableOn setting = instance as EquipableOn;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<EquipmentSlotAsset>> list = new List<AssetSelection<EquipmentSlotAsset>>();
						GenericAssetList<EquipmentSlotAsset> equipmentSlots = EditorDataHandler.Instance.GetAssets<EquipmentSlotAsset>();
						for(int i = 0; i < equipmentSlots.Count; i++)
						{
							AssetSelection<EquipmentSlotAsset> newSlot = new AssetSelection<EquipmentSlotAsset>();
							newSlot.Source.EditorAsset = equipmentSlots.Assets[i];
							list.Add(newSlot);
						}
						setting.blockSlot = list.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						setting.blockSlot = new AssetSelection<EquipmentSlotAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else if(info == "button:blockviewer")
			{
				EquipableOn setting = instance as EquipableOn;
				if(setting != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.ShowButton(new GUIContent("Set All", EditorContent.Instance.AddIcon),
						"Sets up all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						List<AssetSelection<EquipmentSlotAsset>> list = new List<AssetSelection<EquipmentSlotAsset>>();
						GenericAssetList<EquipmentSlotAsset> equipmentSlots = EditorDataHandler.Instance.GetAssets<EquipmentSlotAsset>();
						for(int i = 0; i < equipmentSlots.Count; i++)
						{
							AssetSelection<EquipmentSlotAsset> newSlot = new AssetSelection<EquipmentSlotAsset>();
							newSlot.Source.EditorAsset = equipmentSlots.Assets[i];
							list.Add(newSlot);
						}
						setting.blockViewer = list.ToArray();
					}
					if(EditorTool.ShowButton(new GUIContent("Clear", EditorContent.Instance.RemoveIcon),
						"Removes all equipment slots.", "",
						EditorTool.WIDTH_150))
					{
						setting.blockViewer = new AssetSelection<EquipmentSlotAsset>[0];
					}
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}
	}
}
