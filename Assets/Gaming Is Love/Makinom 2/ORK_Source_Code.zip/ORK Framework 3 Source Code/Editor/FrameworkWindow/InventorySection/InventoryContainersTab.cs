﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class InventoryContainersTab : ORKGenericAssetListTab<InventoryContainerAsset, InventoryContainerSetting>
	{
		public InventoryContainersTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.InventoryContainers.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.InventoryContainers.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Inventory Containers"; }
		}

		public override string HelpText
		{
			get
			{
				return "Optionally use a slot-based inventory containers, where each item stack occupies a slot.\n" +
					"You can set up multiple inventory containers with slots, e.g. to separate items and equipment, or separate based on item type.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/inventory-system-overview/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings for inventory containers, e.g. if the slot-based inventory containers are used.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.InventoryContainers; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.InventoryContainers;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
