
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class ItemTypesTab : ORKGenericAssetListTab<ItemTypeAsset, ItemType>
	{
		public ItemTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.ItemTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.ItemTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Item Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Item types are used to separate items and other purchaseable things.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/inventory-system-overview/"; }
		}
	}
}

