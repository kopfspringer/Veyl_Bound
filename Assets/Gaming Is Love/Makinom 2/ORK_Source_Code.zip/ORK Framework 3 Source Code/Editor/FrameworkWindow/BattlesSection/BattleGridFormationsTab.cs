﻿
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleGridFormationsTab : ORKGenericAssetListTab<BattleGridFormationAsset, BattleGridFormation>
	{
		private EditorBattleGridFormationControl gridFormationControl;

		public BattleGridFormationsTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle Grid Formations"; }
		}

		public override string HelpText
		{
			get
			{
				return "Battle grid formations are used in grid battles to move or place combatants in formation positions.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/battles/battle-grid-formations/"; }
		}


		/*
		============================================================================
		Automation functions
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "editor:GridFormation")
			{
				BattleGridFormation formation = this.CurrentSettings;
				if(formation != null)
				{
					EditorGUILayout.Separator();
					if(EditorTool.Button("Clear Formation", "Resets the formation.", ""))
					{
						formation.leader.row = -1;
						formation.leader.column = -1;
						formation.position = new BattleGridFormationPosition[0];
					}
					if(this.gridFormationControl == null)
					{
						this.gridFormationControl = new EditorBattleGridFormationControl();
					}
					this.gridFormationControl.Edit(formation);
					if(GUI.changed)
					{
						this.parent.Repaint();
					}
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}

		public override void InstanceCallback(string info, object instance)
		{
			if(info == "editor:GridFormationChange")
			{
				BattleGridFormation formation = this.CurrentSettings;
				if(formation != null)
				{
					if(this.gridFormationControl == null)
					{
						this.gridFormationControl = new EditorBattleGridFormationControl();
					}

					if(instance is BattleGridFormationLeader)
					{
						if(formation.leader.row >= 0)
						{
							if(this.gridFormationControl.EditIndex == -2)
							{
								if(EditorTool.MediumButton("Cancel", "Cancel changing the leader's position.", ""))
								{
									this.gridFormationControl.EditIndex = -1;
								}
							}
							else if(EditorTool.MediumButton("Change Position", "Change the position of the leader.\n" +
								"Click on any cell to swap the positions, or place on the current leader position to cancel.", ""))
							{
								this.gridFormationControl.EditIndex = -2;
							}
						}
					}
					else if(instance is BattleGridFormationPosition)
					{
						for(int i = 0; i < formation.position.Length; i++)
						{
							if(formation.position[i] == instance)
							{
								if(this.gridFormationControl.EditIndex == i)
								{
									if(EditorTool.MediumButton("Cancel", "Cancel changing the position.", ""))
									{
										this.gridFormationControl.EditIndex = -1;
									}
								}
								else if(EditorTool.MediumButton("Change Position", "Change the position.\n" +
									"Click on any cell to swap the positions, or place on the current position to cancel.", ""))
								{

									this.gridFormationControl.EditIndex = i;
								}
								return;
							}
						}
						this.gridFormationControl.EditIndex = -1;
					}
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}
	}
}

