﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public class OptionCategoriesTab : ORKGenericAssetListTab<OptionCategoryAsset, OptionCategorySetting>
	{
		public OptionCategoriesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Options.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Options.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Option Categories"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up option categories with their options, the default options menu and where options are saved.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/ui-system/option-categories/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings related to options, e.g. where the options file is saved and the default options menu.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.Options; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.Options;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
