﻿
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;

namespace GamingIsLove.Makinom.Editor
{
	public class TextCodeSettingsTab : BaseEditorTab
	{
		public TextCodeSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Text Codes"; }
		}

		public override string HelpText
		{
			get { return "Set up custom text codes."; }
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/ui-system/text-codes/"; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.TextCodes; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.TextCodes; }
		}
	}
}
