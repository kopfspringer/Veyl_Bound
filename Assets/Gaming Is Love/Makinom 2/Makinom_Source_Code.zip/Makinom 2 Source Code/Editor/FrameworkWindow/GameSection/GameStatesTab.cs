
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class GameStatesTab : GenericAssetListTab<GameStateAsset, GameState>
	{
		public GameStatesTab(MakinomEditorWindow parent) : base(parent)
		{
			Maki.GameStates.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			Maki.GameStates.SetAssets(this.assetList.Assets);
		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				this.assetList.Add(GameStatesTab.CreateAsset(
					"Game Running", false,
						new GameStateChangeType[] { new GameStateChangeType(new StartGameGameStateChangeType()) },
						new GameStateChangeType[] { new GameStateChangeType(new StopGameGameStateChangeType()) }));
				this.assetList.Add(GameStatesTab.CreateAsset(
					"Game Paused", false,
						new GameStateChangeType[] { new GameStateChangeType(new PauseGameStateChangeType()) },
						new GameStateChangeType[] { new GameStateChangeType(new UnpauseGameStateChangeType()) }));
				this.assetList.Add(GameStatesTab.CreateAsset(
					"Changing Scene", false,
						new GameStateChangeType[] { new GameStateChangeType(new StartSceneChangeGameStateChangeType()) },
						new GameStateChangeType[] { new GameStateChangeType(new EndSceneChangeGameStateChangeType()) }));
				this.assetList.Add(GameStatesTab.CreateAsset(
					"Blocking Machine", false,
						new GameStateChangeType[] { new GameStateChangeType(new StartBlockingMachineGameStateChangeType()) },
						new GameStateChangeType[] { new GameStateChangeType(new EndBlockingMachineGameStateChangeType()) }));
				this.assetList.Add(GameStatesTab.CreateAsset(
					"In Control", true,
						new GameStateChangeType[] { new GameStateChangeType(new UnblockPlayerControlGameStateChangeType()) },
						new GameStateChangeType[] { new GameStateChangeType(new BlockPlayerControlGameStateChangeType()) }));
			}
		}

		public static GameStateAsset CreateAsset(string name, bool initialState,
			GameStateChangeType[] autoActivate, GameStateChangeType[] autoInactivate)
		{
			GameStateAsset asset = ScriptableObject.CreateInstance<GameStateAsset>();
			asset.Settings = new GameState(name, initialState, autoActivate, autoInactivate);
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Game States"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up game states for your game.\n" +
					"They're used for checking conditions and requirements, e.g. when to display a HUD or block a machine from executing.\n" +
					"E.g. if the 'Game Paused' state is active you'd most likely want to hide some HUDs and block the player/camera control machines.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/game-states/"; }
		}
	}
}
