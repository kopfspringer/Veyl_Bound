
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Formulas;
using GamingIsLove.Makinom.Formulas.Nodes;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class FormulasTab : GenericAssetListTab<FormulaAsset, Formula>
	{
		private FormulaAsset formula;

		private int lastIndex = -1;

		private bool resetList = false;


		// node editor
		private NodeEditor nodeEditor;

		private Rect nodeRect = new Rect(0, 0, 0, 0);


		// test
		private float initialValue = 0;

		private string testResult = "";

		public FormulasTab(MakinomEditorWindow parent) : base(parent)
		{
			this.nodeEditor = new NodeEditor(this,
				EditorContent.Instance.FormulaClipboard,
				this.AddNode, this.RemoveNode, this.AddNodeGroup, this.RemoveNodeGroup,
				this.AddLayer, null);

			this.nodeEditor.SetNodeInfos(typeof(BaseFormulaNode), typeof(FormulaGateNode));
		}

		public override bool FocusSearchField()
		{
			if(Event.current.mousePosition.x < EditorDataHandler.Instance.EditorAsset.SubSectionDrag +
				EditorDataHandler.Instance.EditorAsset.TabListDrag)
			{
				if(this.listSearchField != null)
				{
					this.listSearchField.SetFocus();
					return true;
				}
			}
			else
			{
				this.nodeEditor.FocusSearchField();
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Formulas"; }
		}

		public override string HelpText
		{
			get
			{
				return "Use formulas to set up complex float value calculations.\n" +
					"Formulas are created using a node editor.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		public override void Reloaded()
		{
			base.Reloaded();
			this.formula = null;
			this.initialValue = 0;
			this.testResult = "";
			this.lastIndex = -1;
		}

		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<FormulaTypeAsset, FormulaType>(
							new string[] { "Formula Type", "Filter the formula list by formula type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool EnableSearchBarFoldoutButtons
		{
			get
			{
				if(this.nodeEditor.IsNodeSelected &&
					this.nodeEditor.Selected.Count > 1)
				{
					return true;
				}
				return false;
			}
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		protected override void RemoveData()
		{
			base.RemoveData();
			this.resetList = true;
		}

		public override void ShowTab()
		{
			this.ClearShow();

			EditorGUILayout.BeginHorizontal();

			this.ShowList();

			this.Editor.TabListDrag();

			EditorGUILayout.BeginVertical();

			EditorGUI.BeginDisabledGroup(!this.editable);
			this.ShowSettings();
			this.CloseAllFoldouts();
			EditorGUI.EndDisabledGroup();

			EditorGUILayout.EndVertical();
			EditorGUILayout.EndHorizontal();

			if(GUI.changed)
			{
				this.Editor.Repaint();
			}
		}

		public override void ShowSettings()
		{
			if(this.assetList.AssetExists(this.index))
			{
				if(this.index != this.lastIndex ||
					this.resetList)
				{
					this.resetList = false;
					this.formula = this.assetList.Assets[this.index];
					this.nodeEditor.SelectNode(this.formula.Settings.setting, false, -1);
					this.nodeEditor.Layer = this.formula.Settings.setting.nodeLayer;
					this.nodeEditor.FirstFocus = true;
					this.lastIndex = this.index;

					// remove empty nodes
					for(int i = 0; i < this.formula.Settings.setting.node.Length; i++)
					{
						if(this.formula.Settings.setting.node[i] == null)
						{
							CommentNode tmp = new CommentNode();
							tmp.comment = "null node loaded";
							this.formula.Settings.setting.node[i] = tmp;
							Debug.LogWarning("Replacing null node at index " + i + " with comment node.\n" +
								"This can be the result of a custom node script that has been removed from the project.\n" +
								"Saving the formula will also save the comment the node.");
						}
					}
				}
			}
			else
			{
				this.formula = null;
			}

			if(this.formula != null)
			{
				this.nodeRect.Set(
					EditorDataHandler.Instance.EditorAsset.SubSectionDrag + EditorDataHandler.Instance.EditorAsset.TabListDrag + 22,
					EditorTool.SectionHeight,
					this.Editor.position.width - EditorDataHandler.Instance.EditorAsset.SubSectionDrag - EditorDataHandler.Instance.EditorAsset.TabListDrag - 22,
					this.Editor.position.height - EditorTool.SectionHeight - EditorTool.SaveButtonHeight - EditorDataHandler.Instance.EditorAsset.FormulaDrag);

				GUILayoutUtility.GetRect(this.nodeRect.width, this.nodeRect.height);

				// node display
				if(this.nodeEditor.showSettings)
				{
					this.Editor.FormulaDrag();

					EditorGUILayout.BeginHorizontal(GUILayout.Height(EditorDataHandler.Instance.EditorAsset.FormulaDrag));

					this.BeforeSettings();

					EditorGUILayout.BeginVertical();
					this.ShowSearchSettings();

					// node settings
					this.SettingsScroll = EditorGUILayout.BeginScrollView(this.SettingsScroll);

					if(this.nodeEditor.NewStartNode != null &&
						EditorTool.Button("View All Nodes", "Exits the current limited node view and displays all nodes.", ""))
					{
						this.nodeEditor.NewStartNode = null;
					}

					// node settings
					if(this.nodeEditor.Selected != null)
					{
						for(int i = 0; i < this.nodeEditor.Selected.Count; i++)
						{
							if(this.nodeEditor.Selected[i] != null)
							{
								if(this.nodeEditor.Selected[i] == this.formula.Settings.setting)
								{
									this.guidField.Edit(this.formula.Settings, this);
									EditorAutomation.Automate(this.formula.Settings, this);
								}
								else
								{
									NodeInfo nodeInfo = this.nodeEditor.GetNodeInfo(this.nodeEditor.Selected[i].GetType());
									if(this.BeginFoldout(nodeInfo.content, nodeInfo.info, true))
									{
										nodeInfo.ShowSubMenuInfo();

										if(!(this.nodeEditor.Selected[i] is FormulaGateNode))
										{
											EditorGUILayout.BeginHorizontal();
											EditorAutomation.Automate("active", this.nodeEditor.Selected[i], this, true);
											if(EditorTool.MicroButton("Focus", "Focus the node editor on this node.\n" +
												"Can also be done using the keyboard shortcut 'CTRL + F'.", ""))
											{
												this.nodeEditor.FocusNode(this.nodeEditor.Selected[i]);
											}
											GUILayout.FlexibleSpace();
											EditorGUILayout.EndHorizontal();
										}
										else
										{
											if(EditorTool.MicroButton("Focus", "Focus the node editor on this node.\n" +
												"Can also be done using the keyboard shortcut 'CTRL + F'.", ""))
											{
												this.nodeEditor.FocusNode(this.nodeEditor.Selected[i]);
											}
										}

										// override name
										EditorGUILayout.BeginHorizontal();
										EditorAutomation.Automate("overrideNodeName", this.nodeEditor.Selected[i], this, true);
										EditorAutomation.Automate("nodeName", this.nodeEditor.Selected[i], this, true);
										GUILayout.FlexibleSpace();
										EditorGUILayout.EndHorizontal();

										if(this.nodeEditor.Selected[i].IsEnabled)
										{
											EditorGUILayout.Separator();
											EditorAutomation.Automate(this.nodeEditor.Selected[i], this);
										}
										EditorGUILayout.Separator();
									}
									this.EndFoldout();
								}
							}
						}

						// test formula
						if(this.BeginFoldout("Test Formula", "Do a test calculation of the formula.", "", false))
						{
							if(EditorContent.Extensions.Count > 0)
							{
								if(this.BeginFoldout("General Test",
									"Run a test calculation using 2 selected game objects in your scene.", "", true))
								{
									this.ShowTest();
									EditorGUILayout.Separator();
								}
								this.EndFoldout();
							}
							else
							{
								this.ShowTest();
							}

							for(int i = 0; i < EditorContent.Extensions.Count; i++)
							{
								EditorContent.Extensions[i].ShowFormulaTest(this, this.formula);
							}

							EditorGUILayout.Separator();
						}
						this.EndFoldout();
					}
					EditorGUILayout.EndScrollView();
					EditorGUILayout.EndVertical();

					this.AfterSettings();

					EditorGUILayout.EndHorizontal();
				}
			}
		}

		protected virtual void ShowTest()
		{
			EditorGUILayout.HelpBox("Select 2 game objects in your scene view to be able to test 'Position' nodes.",
				MessageType.Info);
			EditorGUILayout.Separator();

			EditorGUILayout.LabelField("Result", this.testResult);
			if(EditorTool.Button("Calculate", "Calculate this formula using the 2 selected game objects.", ""))
			{
				this.testResult = this.formula.Settings.Calculate(
					new FormulaCall(
						this.initialValue,
						Selection.objects.Length > 0 ? Selection.objects[0] as GameObject : null,
						Selection.objects.Length > 1 ? Selection.objects[1] as GameObject : null,
						null, null, 0)).ToString();
			}

			EditorGUILayout.Separator();
			EditorTool.Field<float>("Initial Value", ref this.initialValue,
				"The initial value used when calculating the formula.", "",
				null, this);
		}

		public override void InstanceCallback(string info, System.Object instance)
		{
			if(info == "buttons:randomnode")
			{
				if(instance is RandomNode)
				{
					if(EditorTool.Button("Add Node", "Adds a random node to the list.", ""))
					{
						ArrayHelper.Add(ref ((RandomNode)instance).random, -1);
					}
					if(((RandomNode)instance).random.Length > 1 &&
						EditorTool.Button("Remove Node", "Removes the last random node from the list.", ""))
					{
						ArrayHelper.RemoveAt(ref ((RandomNode)instance).random, ((RandomNode)instance).random.Length - 1);
					}
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}

		public override void ShowAfterEditor()
		{
			if(this.formula != null)
			{
				// node grid
				this.nodeEditor.ShowNodes(this.nodeRect,
					this.formula.Settings.setting,
					this.formula.Settings.setting.node,
					this.formula.Settings.setting.group,
					null,
					ref this.formula.Settings.setting.layer);

				if(GUI.changed)
				{
					this.parent.Repaint();
				}
			}
		}


		/*
		============================================================================
		Node functions
		============================================================================
		*/
		public BaseNode[] AddNode(BaseNode node)
		{
			if(this.formula != null && node is BaseFormulaNode)
			{
				ArrayHelper.Add(ref this.formula.Settings.setting.node, (BaseFormulaNode)node);
				return this.formula.Settings.setting.node;
			}
			return null;
		}

		public BaseNode[] RemoveNode(BaseNode node)
		{
			if(this.formula != null && node is BaseFormulaNode)
			{
				ArrayHelper.Remove(ref this.formula.Settings.setting.node, (BaseFormulaNode)node);
				return this.formula.Settings.setting.node;
			}
			return null;
		}

		public NodeGroup[] AddNodeGroup(NodeGroup group)
		{
			if(this.formula != null)
			{
				ArrayHelper.Add(ref this.formula.Settings.setting.group, group);
				return this.formula.Settings.setting.group;
			}
			return null;
		}

		public NodeGroup[] RemoveNodeGroup(NodeGroup group)
		{
			if(this.formula != null)
			{
				ArrayHelper.Remove(ref this.formula.Settings.setting.group, group);
				return this.formula.Settings.setting.group;
			}
			return null;
		}

		public string[] AddLayer()
		{
			if(this.formula != null)
			{
				ArrayHelper.Add(ref this.formula.Settings.setting.layer, "New Layer");
				return this.formula.Settings.setting.layer;
			}
			return null;
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override bool CheckFilterCondition(int index)
		{
			return this.Filter.assetFilterSelection[0].Check(
				this.assetList.Assets[index].Settings.setting.formulaType.Source.EditorAsset);
		}
	}
}
