
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class PortraitTypesTab : GenericAssetListTab<PortraitTypeAsset, PortraitType>
	{
		public PortraitTypesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Portrait Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Use portrait types to set up different portrait images for scene objects, dialogues and other things.\n" +
					"E.g. set up 'Happy' and 'Sad' portraits for a scene object and use them in dialogues when needed.";
			}
		}

		public override string HelpInfo
		{
			get { return ""; }
		}
	}
}

