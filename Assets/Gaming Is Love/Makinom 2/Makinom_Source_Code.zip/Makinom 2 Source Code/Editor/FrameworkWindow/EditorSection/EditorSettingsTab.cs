
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public sealed class EditorSettingsTab : BaseEditorTab
	{
		public EditorSettingsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Editor Settings"; }
		}

		public override string HelpText
		{
			get { return "Customize the editor UI and behaviour."; }
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.EditorSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.EditorSettings; }
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		public override void ShowSettings()
		{
			bool tmpSeparateEnums = Maki.EditorSettings.popupSeparateEnums;
			EditorAutomation.Automate(Maki.EditorSettings, this);

			/*if(tmpSeparateEnums != Maki.EditorSettings.popupSeparateEnums)
			{
				EditorAttributes.ClearSortedEnums();
			}*/
		}

		public override void SettingChanged(IBaseData instance, string fieldName, object newValue)
		{
			if(instance == Maki.EditorSettings &&
				fieldName == "popupSeparateEnums")
			{
				EditorAttributes.ClearSortedEnums();
			}
		}

		public override void AutomationCallback(string info)
		{
			if(info == "button:editorhelpexport")
			{
				EditorGUILayout.Separator();

				UnityEngine.Object tmp = EditorDataHandler.Instance.EditorAsset.EditorHelpLanguageTexts;
				EditorTool.AssetField(new GUIContent("Editor Help (CSV)", "Select the CSV file (UTF-8 formatted) that contains your translated editor texts."),
					ref tmp, typeof(TextAsset), "", null, this);
				if(EditorDataHandler.Instance.EditorAsset.EditorHelpLanguageTexts != tmp)
				{
					EditorDataHandler.Instance.EditorAsset.EditorHelpLanguageTexts = tmp as TextAsset;
					EditorAttributes.Instance.Clear();
				}

				if(EditorTool.Button("Export Default Help", "Export the default help texts (english) as a CSV with UTF-8 formatting.", ""))
				{
					EditorAttributes.Instance.SaveEditorHelpExport(EditorUtility.SaveFilePanel("Save Editor Help Export (CSV)", "",
						"EditorHelp_English", "csv"));
				}
			}
			else if(info == "button:resetDrag")
			{
				EditorGUILayout.Separator();
				if(EditorTool.Button("Reset Drag Bars", "Reset the drag bars to their default positions.", ""))
				{
					this.Editor.ResetDrags();
				}
			}
			else if(info == "button:resetBasicNodeColors")
			{
				EditorGUILayout.Separator();
				if(EditorTool.Button("Reset Colors", "Reset the basic node colors.", ""))
				{
					Maki.EditorSettings.startNodeColor = new Color(0.6f, 1, 0.6f, 1);
					Maki.EditorSettings.layerGateNodeColor = new Color(1, 1, 0.5f, 1);
					Maki.EditorSettings.baseNodeColor = new Color(1, 1, 1, 1);
					Maki.EditorSettings.selectedNodeColor = new Color(0.6f, 0.8f, 1, 1);
					Maki.EditorSettings.selectedSlotColor = new Color(0.45f, 0.65f, 0.85f, 1);
					Maki.EditorSettings.disabledNodeColor = new Color(0.6f, 0.6f, 0.6f, 1);
					Maki.EditorSettings.unreachableNodeColor = new Color(1, 0.4f, 0.4f, 1);
				}
			}
			else if(info == "button:resetTypeNodeColors")
			{
				EditorGUILayout.Separator();
				if(EditorTool.Button("Reset Colors", "Reset the type node colors.", ""))
				{
					Maki.EditorSettings.animationNodeColor = new Color(1, 0.69f, 0.247f, 1);
					Maki.EditorSettings.functionNodeColor = new Color(0.831f, 0.373f, 1, 1);
					Maki.EditorSettings.gameObjectNodeColor = new Color(0.808f, 1, 0.439f, 1);
					Maki.EditorSettings.gameNodeColor = new Color(1, 0.498f, 0.365f, 1);
					Maki.EditorSettings.inputNodeColor = new Color(1, 1, 0, 1);
					Maki.EditorSettings.machineNodeColor = new Color(0.533f, 0.655f, 0.804f, 1);
					Maki.EditorSettings.movementNodeColor = new Color(0.463f, 0.831f, 1, 1);
					Maki.EditorSettings.uiNodeColor = new Color(0.278f, 1, 0.839f, 1);
					Maki.EditorSettings.valueNodeColor = new Color(1, 0.365f, 0.635f, 1);
				}
			}
			else if(info == "button:resetNodeConnectionColors")
			{
				EditorGUILayout.Separator();
				if(EditorTool.Button("Reset Colors", "Reset the type node colors.", ""))
				{
					Maki.EditorSettings.childConnectionColor = new Color(0, 0.9f, 0, 1);
					Maki.EditorSettings.parentConnectionColor = new Color(0, 0, 0.9f, 1);
				}
			}
			else if(info == "button:resetNodeGridColors")
			{
				EditorGUILayout.Separator();
				if(EditorTool.Button("Reset Colors", "Reset the grid colors.", ""))
				{
					Maki.EditorSettings.gridLineColor = new Color(0.122f, 0.173f, 0.22f, 1);
					Maki.EditorSettings.gridLineFullColor = new Color(0.063f, 0.086f, 0.11f, 1);
					Maki.EditorSettings.gridBackgroundColor = new Color(0.204f, 0.286f, 0.369f, 1);
				}
			}
			else if(info == "button:resetDebugColors")
			{
				EditorGUILayout.Separator();
				if(EditorTool.Button("Reset Colors", "Reset the debug colors.", ""))
				{
					Maki.EditorSettings.debugConnectionColor = Color.yellow;
					Maki.EditorSettings.debugConnectionCurrentColor = new Color(1, 0.5f, 0, 1);
					Maki.EditorSettings.debugNodeColor = Color.yellow;
					Maki.EditorSettings.debugNodeCurrentColor = new Color(1, 0.5f, 0, 1);
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}

