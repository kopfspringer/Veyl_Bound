
using GamingIsLove.Makinom;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	public class VariableChangeTemplatesTab : GenericAssetListTab<VariableChangeTemplateAsset, VariableChangeTemplate>
	{
		public VariableChangeTemplatesTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Variable Change Templates"; }
		}

		public override string HelpText
		{
			get { return "Set up reusable templates for variable changes."; }
		}

		public override string HelpInfo
		{
			get { return "https://makinom.com/guide/documentation/features/variables/"; }
		}
	}
}

