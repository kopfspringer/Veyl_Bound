
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(StoreTerrainChanges))]
public class StoreTerrainChangesInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as StoreTerrainChanges);
	}
	
	private void ComponentSetup(StoreTerrainChanges target)
	{
		Undo.RecordObject(target, "Change to 'Store Terrain Changes' on " + target.name);
		this.BaseInit(true);

		if(this.baseEditor.BeginFoldout("Terrain Settings", "", "", true))
		{
			GUILayout.TextArea("The object ID is used to keep track of terrain's changes.\n" +
				"If terrains share the same ID, their changes will also be shared.\n" +
				"The object ID is used game-wide, i.e. also in different scenes.");
			
			if(EditorTool.Button("Get New Object ID", EditorTool.WIDTH) || target.objectID == "")
			{
				target.objectID = System.Guid.NewGuid().ToString();
			}
			target.objectID = EditorGUILayout.TextField(target.objectID);
			
			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.EndSetup();
	}
}