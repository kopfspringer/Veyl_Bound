
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(InteractionMachineComponent))]
public class InteractionMachineInspector : BaseMachineInspector
{
	protected bool moveToFoldout = false;

	public override void OnInspectorGUI()
	{
		this.MachineSetup(target as InteractionMachineComponent);
	}

	private void MachineSetup(InteractionMachineComponent target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Interaction Machine' on " + target.name);
		this.BaseInit(true);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.BaseMachineSetup(target);

		if(GUI.changed)
		{
			if(Application.isPlaying)
			{
				target.settings.startSetting.inputKey.ResetStoredAsset();
			}
		}
		this.EndSetup();
	}
}
