
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;

[CustomEditor(typeof(AutoMachineComponent))]
public class AutoMachineInspector : BaseMachineInspector
{
	public override void OnInspectorGUI()
	{
		this.MachineSetup(target as AutoMachineComponent);
	}

	private void MachineSetup(AutoMachineComponent target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Auto Machine' on " + target.name);
		this.BaseInit(true);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.BaseMachineSetup(target);

		this.EndSetup();
	}
}
