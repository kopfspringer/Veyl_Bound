
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(CollisionMachineComponent))]
public class CollisionMachineInspector : BaseMachineInspector
{
	public override void OnInspectorGUI()
	{
		this.MachineSetup(target as CollisionMachineComponent);
	}

	private void MachineSetup(CollisionMachineComponent target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Collision Machine' on " + target.name);
		this.BaseInit(true);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.BaseMachineSetup(target);

		this.EndSetup();
	}
}
