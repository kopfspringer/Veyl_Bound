﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(ComponentManager))]
public class ComponentManagerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as ComponentManager);
	}

	private void ComponentSetup(ComponentManager target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Component Manager' on " + target.name);
		this.BaseInit(true);

		this.ShowSerializedProperty("notes");

		EditorGUILayout.HelpBox("Enables or disables added components, colliders, renderers or LOD groups based on the defined conditions.\n" +
			"The 'Component Manager' doesn't work if itself is disabled.",
			MessageType.Info);

		this.ShowSerializedProperty("components");
		this.ShowSerializedProperty("colliders");
		this.ShowSerializedProperty("renderers");
		this.ShowSerializedProperty("lodGroups");

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}