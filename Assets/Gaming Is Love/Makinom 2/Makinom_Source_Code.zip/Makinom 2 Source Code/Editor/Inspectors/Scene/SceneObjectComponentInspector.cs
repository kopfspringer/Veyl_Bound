
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SceneObjectComponent))]
public class SceneObjectComponentInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as SceneObjectComponent);
	}

	private void ComponentSetup(SceneObjectComponent target)
	{
		Undo.RecordObject(target, "Change to 'Scene Object Component' on " + target.name);
		this.BaseInit(true);

		if(this.baseEditor.BeginFoldout("Scene Object Settings", "", "", true))
		{
			EditorAutomation.Automate(target.settings, this.baseEditor);

			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		if(this.baseEditor.BeginFoldout("Condition Settings", "", "", true))
		{
			EditorAutomation.Automate(target.conditionSetting, this.baseEditor);

			EditorGUILayout.Separator();
		}
		this.baseEditor.EndFoldout();

		this.EndSetup();
	}
}
