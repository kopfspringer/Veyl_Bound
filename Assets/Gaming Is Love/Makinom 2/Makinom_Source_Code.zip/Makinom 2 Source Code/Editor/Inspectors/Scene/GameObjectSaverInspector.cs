﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(GameObjectSaverComponent))]
public class GameObjectSaverInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as GameObjectSaverComponent);
	}

	protected virtual void ComponentSetup(GameObjectSaverComponent target)
	{
		Undo.RecordObject(target, "Change to 'Game Object Saver' on " + target.name);
		this.BaseInit(false);

		EditorGUILayout.HelpBox("This component will remember data about this game object between scene changes and in save games.\n" +
			"The game object is identified by the 'Scene GUID', which needs to be unique in the scene.\n" +
			"Also saves data from attached components attached to the game object (and child objects) implementing the 'IComponentSaveData' interface.\n" +
			"Please note that this component only works for game objects already placed in your scene, not for game objects spawned in-game.\n" +
			"The save game settings (in 'UI > Save Game Settings') define if the data is actually saved with save games or only remembered during play.",
			MessageType.Info);

		EditorGUILayout.Separator();

		// scene GUID
		target.SceneGUID = EditorGUILayout.TextField(new GUIContent("Scene GUID",
			"The 'Scene GUID' is used to identify this game object's data in a save game.\n" +
			"It needs to be unique in the scene."),
			target.SceneGUID);
		if(GUILayout.Button("Generate New Scene GUID") ||
			target.SceneGUID == "")
		{
			target.SceneGUID = System.Guid.NewGuid().ToString();
		}

		EditorGUILayout.Separator();

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}