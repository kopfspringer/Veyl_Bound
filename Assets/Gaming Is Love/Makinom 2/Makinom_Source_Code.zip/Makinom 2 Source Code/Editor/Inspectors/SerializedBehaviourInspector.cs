﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	[CustomEditor(typeof(SerializedBehaviour), true)]
	public class SerializedBehaviourInspector : BaseInspector
	{
		public override void OnInspectorGUI()
		{
			this.ShowSettings(((SerializedBehaviour)target).SerializedSettings, false);
		}
	}
}
