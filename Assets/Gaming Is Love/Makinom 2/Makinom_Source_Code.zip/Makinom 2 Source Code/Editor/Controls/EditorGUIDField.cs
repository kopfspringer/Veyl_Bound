﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System;
using System.IO;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorGUIDField
	{
		private Rect lastBounds;

		private static char[] NotAllowedCharacters = new char[] { ' ', '/', '?', '<', '>', '\\', ':', '*', '|', '"' };

		public EditorGUIDField()
		{

		}

		public void Edit(BaseIndexData instance, BaseEditorTab baseEditor)
		{
			if(instance != null &&
				baseEditor != null &&
				baseEditor.InstanceType != null)
			{
				EditorGUILayout.BeginHorizontal();
				if(EditorTool.Button(EditorContent.Instance.CopyToClipboardContent, EditorTool.WIDTH_30))
				{
					EditorGUIUtility.systemCopyBuffer = instance.GUID;
				}
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.OpenLinkIcon, "Use the content's name as the GUID."), EditorTool.WIDTH_30))
				{
					string newGUID = instance.EditorName;
					using(StringReader reader = new StringReader(newGUID))
					{
						newGUID = reader.ReadLine();
					}
					IAssetList assetList = EditorDataHandler.Instance.GetAssetList(baseEditor.InstanceType);

					if(instance.GUID != newGUID)
					{
						if(newGUID.IndexOfAny(NotAllowedCharacters) >= 0)
						{
							newGUID = newGUID.Replace(" ", "").
								Replace("/", "").
								Replace("?", "").
								Replace("<", "").
								Replace(">", "").
								Replace("\\", "").
								Replace(":", "").
								Replace("*", "").
								Replace("|", "").
								Replace("\"", "");
						}
						if(newGUID != "")
						{
							if(!assetList.ContainsGUID(newGUID))
							{
								string oldGUID = instance.GUID;
								instance.GUID = newGUID;
								EditorDataHandler.Instance.GUIDChanged(baseEditor.InstanceType, oldGUID, newGUID);
							}
							else
							{
								EditorUtility.DisplayDialog("GUID Not Changed", "The GUID '" + newGUID + "' is already in use.", "Ok");
							}
						}
					}
				}
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.EditBigIcon, "Change this GUID."),
					EditorTool.WIDTH_30))
				{
					if(Event.current.type == EventType.Repaint)
					{
						this.lastBounds = GUILayoutUtility.GetLastRect();
					}

					PopupWindow.Show(new Rect(this.lastBounds.xMax, this.lastBounds.y, 0, 0),
						new GUIDPopup(baseEditor, instance,
							EditorDataHandler.Instance.GetAssetList(baseEditor.InstanceType),
							baseEditor.InstanceType));
				}
				else if(Event.current.type == EventType.Repaint)
				{
					this.lastBounds = GUILayoutUtility.GetLastRect();
				}

				EditorGUILayout.BeginVertical();
				EditorGUILayout.LabelField("GUID", instance.GUID, EditorTool.W_EXPAND);
				EditorGUILayout.LabelField("ID/Index", instance.ID.ToString(), EditorTool.W_EXPAND);
				EditorGUILayout.EndVertical();
				EditorGUILayout.EndHorizontal();
			}
		}

		private class GUIDPopup : PopupWindowContent
		{
			private BaseEditorTab baseEditor;

			private BaseIndexData instance;

			private IAssetList assetList;

			private System.Type type;

			private string newGUID = "";

			private Vector2 windowSize = new Vector2(500, 116);

			public GUIDPopup(BaseEditorTab baseEditor, BaseIndexData instance,
				IAssetList assetList, System.Type type)
			{
				this.baseEditor = baseEditor;
				this.instance = instance;
				this.assetList = assetList;
				this.type = type;
				this.newGUID = this.instance.GUID;
			}

			public override Vector2 GetWindowSize()
			{
				return this.windowSize;
			}

			public override void OnOpen()
			{
				if(this.baseEditor != null)
				{
					this.baseEditor.BlockScroll = true;
				}
			}

			public override void OnClose()
			{
				if(this.baseEditor != null)
				{
					this.baseEditor.BlockScroll = false;
					this.baseEditor.Editor.Focus();
				}
			}

			public override void OnGUI(Rect rect)
			{
				EditorGUILayout.BeginVertical(EditorContent.Instance.PopupListStyle);

				EditorGUILayout.LabelField("Current GUID", this.instance.GUID);

				this.newGUID = EditorGUILayout.TextField("New GUID", this.newGUID);

				EditorGUILayout.Separator();

				bool allowed = true;
				if(this.instance.GUID == this.newGUID)
				{
					allowed = false;
					EditorGUILayout.HelpBox("Current GUID", MessageType.Error);
				}
				else if(this.newGUID == "")
				{
					allowed = false;
					EditorGUILayout.HelpBox("GUID can't be empty", MessageType.Error);
				}
				else if(this.newGUID.IndexOfAny(NotAllowedCharacters) >= 0)
				{
					allowed = false;
					EditorGUILayout.HelpBox("No space or /?<>\\:*|\" allowed in a GUID", MessageType.Error);
				}
				else if(this.assetList.ContainsGUID(this.newGUID))
				{
					allowed = false;
					EditorGUILayout.HelpBox("GUID already in use", MessageType.Error);
				}
				else
				{
					EditorGUILayout.HelpBox("GUID available", MessageType.Info);
				}

				EditorGUILayout.BeginHorizontal();
				EditorGUI.BeginDisabledGroup(!allowed);
				if(EditorTool.Button("Ok"))
				{
					string oldGUID = this.instance.GUID;
					this.instance.GUID = this.newGUID;
					EditorDataHandler.Instance.GUIDChanged(this.type, oldGUID, this.newGUID);
					this.editorWindow.Close();
				}
				EditorGUI.EndDisabledGroup();
				if(EditorTool.Button("Cancel"))
				{
					this.editorWindow.Close();
				}

				EditorGUILayout.EndHorizontal();

				EditorGUILayout.EndVertical();
				if(Event.current.type == EventType.Repaint)
				{
					this.windowSize.y = GUILayoutUtility.GetLastRect().height;
				}
			}
		}
	}
}
