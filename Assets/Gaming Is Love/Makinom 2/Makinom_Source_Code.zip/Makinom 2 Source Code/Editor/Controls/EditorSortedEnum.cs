﻿
using UnityEngine;
using System.Collections.Generic;
using System;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorSortedEnum
	{
		private List<EnumValue> values;

		public string[] names;

		public EditorSortedEnum(object enumType)
		{
			Type type = enumType.GetType();
			if(type.IsEnum)
			{
				Array tmp = Enum.GetValues(type);
				this.values = new List<EnumValue>();
				for(int i = 0; i < tmp.Length; i++)
				{
					this.values.Add(new EnumValue(tmp.GetValue(i), type));
				}

				bool sort = true;
				object[] attr = type.GetCustomAttributes(typeof(EditorUnsortedEnumAttribute), true);
				if(attr.Length > 0)
				{
					sort = false;
				}
				if(sort)
				{
					this.values.Sort(new EnumSorter());
				}

				this.names = new string[this.values.Count];
				for(int i = 0; i < this.values.Count; i++)
				{
					this.names[i] = this.values[i].name;
				}
			}
			else
			{
				throw new ArgumentException("Must be an enum.", "enumType");
			}
		}

		public int GetIndex(object value)
		{
			for(int i = 0; i < this.values.Count; i++)
			{
				if(this.values[i].value.Equals(value))
				{
					return i;
				}
			}
			return -1;
		}

		public object GetValue(int index)
		{
			if(this.values != null &&
				index >= 0 &&
				index < this.values.Count)
			{
				return this.values[index].value;
			}
			return 0;
		}

		private class EnumValue
		{
			public string name;

			public object value;

			public EnumValue(object value, Type type)
			{
				this.value = value;
				this.name = value.ToString();

				bool attributeFound = false;
				if(Maki.EditorSettings.popupSeparateEnums)
				{
					MemberInfo[] info = type.GetMember(this.name);
					if(info != null && info.Length > 0)
					{
						EditorNameAttribute attr = Attribute.GetCustomAttribute(info[0],
						typeof(EditorNameAttribute)) as EditorNameAttribute;
						if(attr != null)
						{
							this.name = attr.name;
							attributeFound = true;
						}
					}
				}

				if(!attributeFound)
				{
					this.name = System.Text.RegularExpressions.Regex.Replace(this.name,
						"([a-z](?=[A-Z0-9])|[A-Z0-9](?=[A-Z][a-z]))", "$1 ");
				}
			}
		}

		private class EnumSorter : IComparer<EnumValue>
		{
			public EnumSorter()
			{

			}

			public int Compare(EnumValue x, EnumValue y)
			{
				string tmpX = x.name.Contains("/") ?
					x.name.Substring(0, x.name.IndexOf("/")) :
					x.name;

				string tmpY = y.name.Contains("/") ?
					y.name.Substring(0, y.name.IndexOf("/")) :
					y.name;

				int result = tmpX.CompareTo(tmpY);
				if(result == 0)
				{
					return x.name.CompareTo(y.name);
				}
				else
				{
					return result;
				}
			}
		}
	}
}
