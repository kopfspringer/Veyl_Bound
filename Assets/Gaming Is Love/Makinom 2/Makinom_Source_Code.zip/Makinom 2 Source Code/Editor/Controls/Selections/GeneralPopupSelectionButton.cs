﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class GeneralPopupSelectionButton
	{
		protected Rect lastBounds;

		public GeneralPopupSelectionButton()
		{

		}

		public virtual void Show(GUIContent content, string helpText, string helpInfo,
			string[] items, string[] descriptions, string favoriteInfo, string popupName,
			NotifyInt selectCallback, Notify closeCallback, BaseEditor baseEditor)
		{
			if(EditorTool.MediumButton(content, helpText, helpInfo))
			{
				if(Event.current.type == EventType.Repaint)
				{
					this.lastBounds = GUILayoutUtility.GetLastRect();
				}
				PopupWindow.Show(this.lastBounds,
					new GeneralSelectionPopup(popupName, -1, items, descriptions, favoriteInfo, this.lastBounds.height,
						EditorGUIUtility.GUIToScreenPoint(
							new Vector2(this.lastBounds.x, this.lastBounds.y + this.lastBounds.height)),
						this.lastBounds, selectCallback, closeCallback, baseEditor));
			}
			else if(Event.current.type == EventType.Repaint)
			{
				this.lastBounds = GUILayoutUtility.GetLastRect();
			}
		}

		public virtual void Show(GUIContent content, string helpText, string helpInfo,
			string[] items, string[] descriptions, string favoriteInfo, string popupName,
			NotifyInt selectCallback, Notify closeCallback, BaseEditor baseEditor,
			GUIStyle style, params GUILayoutOption[] options)
		{
			if(GUILayout.Button(content, style, options))
			{
				if(Event.current.type == EventType.Repaint)
				{
					this.lastBounds = GUILayoutUtility.GetLastRect();
				}
				PopupWindow.Show(this.lastBounds,
					new GeneralSelectionPopup(popupName, -1, items, descriptions, favoriteInfo, this.lastBounds.height,
						EditorGUIUtility.GUIToScreenPoint(
							new Vector2(this.lastBounds.x, this.lastBounds.y + this.lastBounds.height)),
						this.lastBounds, selectCallback, closeCallback, baseEditor));
			}
			else if(Event.current.type == EventType.Repaint)
			{
				this.lastBounds = GUILayoutUtility.GetLastRect();
			}
		}
	}
}
