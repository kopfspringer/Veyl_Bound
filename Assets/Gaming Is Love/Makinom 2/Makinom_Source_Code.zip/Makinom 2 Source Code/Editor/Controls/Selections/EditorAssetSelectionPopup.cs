﻿
using UnityEngine;
using UnityEditor;
using UnityEditor.AnimatedValues;
using UnityEditor.IMGUI.Controls;
using System.Collections.Generic;
using System;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorAssetSelectionPopup : PopupWindowContent
	{
		protected BaseEditor baseEditor;

		protected string name = "";

		protected AssetSource selection;

		protected System.Type assetType;

		protected List<Element> tree = new List<Element>();

		protected List<Element> displayList = new List<Element>();

		protected Element header;

		protected bool hasTypes = false;

		protected bool typeSeparation = false;


		// animation
		protected AnimFloat animation = new AnimFloat(0);

		protected List<Element> previousList = new List<Element>();

		protected Element previousHeader;


		// input
		protected int index = -1;

		protected int selectedIndex = -1;

		protected bool mouseMoved = false;

		protected bool holdingArrowKey = false;

		protected float holdTimeout = 0;

		protected bool isClosing = false;


		// search field
		protected SearchField searchField = new SearchField();

		protected string lastSearch = "";

		protected string search = "";


		// sorting
		protected int sorting = 0;

		protected GUIContent[] sortingContent;


		// gui
		protected Vector2 scroll = Vector2.zero;

		protected bool topMode = false;

		protected Vector2 callPosition;

		protected float activatorHeight;

		protected Vector2 windowSize;

		protected float searchFieldHeight = 28;

		protected float sortFieldHeight = 29;

		protected float typeHeaderHeight = 30;

		protected float headerHeight = 30;

		protected float listHeight = 0;

		protected float listCursorHeight = 0;


		// callbacks
		private EditorAssetSelectionPopupField.Closed selectCallback;

		protected Notify closeCallback;

		public EditorAssetSelectionPopup(string name, ref AssetSource selection, BaseEditor baseEditor,
			EditorAssetSelectionConditionAttribute condition,
			float activatorHeight, Vector2 callPosition, Rect callBounds,
			EditorAssetSelectionPopupField.Closed selectCallback, Notify closeCallback)
		{
			this.name = name;
			this.selection = selection;
			this.selectCallback = selectCallback;
			this.closeCallback = closeCallback;
			this.baseEditor = baseEditor;
			this.assetType = this.selection.GetAssetType();

			this.windowSize.x = 300;
			this.activatorHeight = activatorHeight;
			this.callPosition = callPosition;
			if(callBounds.x + 300 > Screen.width)
			{
				this.callPosition.x = this.callPosition.x + callBounds.width - 300;
			}

			if(typeof(IHasTypeAsset).IsAssignableFrom(this.assetType))
			{
				this.hasTypes = true;
				this.typeSeparation = Maki.EditorSettings.popupTypeSeparation;

				this.sortingContent = new GUIContent[]
				{
					new GUIContent("ID", "Sort by ID/index"),
					new GUIContent("Name", "Sort by name"),
					new GUIContent("Type ID", "Sort by type ID/index"),
					new GUIContent("Type Name", "Sort by type name")
				};
			}
			else
			{
				this.sortingContent = new GUIContent[]
				{
					new GUIContent("ID", "Sort by ID/index"),
					new GUIContent("Name", "Sort by name")
				};
			}

			this.headerHeight = this.hasTypes && this.typeSeparation ?
				Mathf.Ceil(EditorContent.Instance.PopupListHeaderStyle.CalcHeight(
					new GUIContent("Header"), this.windowSize.x) + EditorContent.Instance.PopupListHeaderStyle.margin.vertical) :
				0;
			this.typeHeaderHeight = Mathf.Ceil(EditorStyles.boldLabel.CalcHeight(
				new GUIContent("Type Name"), this.windowSize.x) + EditorStyles.boldLabel.margin.vertical);

			this.sorting = this.hasTypes ?
				EditorDataHandler.Instance.EditorAsset.TypeDataSelectionSorting :
				EditorDataHandler.Instance.EditorAsset.DataSelectionSorting;

			this.animation.speed = 3;

			if(this.baseEditor is BaseEditorTab)
			{
				this.CreateTree(condition, EditorDataHandler.Instance.GetAssets(this.assetType));
			}
			else
			{
				this.CreateTree(condition, EditorDataHandler.FindAssets(this.assetType));
			}
			this.UpdateList();
			this.searchField.SetFocus();
		}

		public virtual void Close()
		{
			this.isClosing = true;
			this.editorWindow.Close();
		}

		public override void OnOpen()
		{
			if(this.baseEditor != null)
			{
				this.baseEditor.BlockScroll = true;
			}
			this.animation.valueChanged.AddListener(this.editorWindow.Repaint);
			this.editorWindow.Focus();
		}

		public override void OnClose()
		{
			if(this.baseEditor != null)
			{
				this.baseEditor.BlockScroll = false;
			}
			if(this.hasTypes)
			{
				EditorDataHandler.Instance.EditorAsset.TypeDataSelectionSorting = this.sorting;
			}
			else
			{
				EditorDataHandler.Instance.EditorAsset.DataSelectionSorting = this.sorting;
			}
			if(this.closeCallback != null)
			{
				this.closeCallback();
			}
		}


		/*
		============================================================================
		Bound functions
		============================================================================
		*/
		protected virtual void UpdateHeight(float height)
		{
			this.topMode = false;
			this.windowSize.y = this.searchFieldHeight + this.sortFieldHeight + this.headerHeight + height;
			this.listHeight = this.windowSize.y - (this.searchFieldHeight + this.sortFieldHeight);
			this.listCursorHeight = this.listHeight - this.headerHeight;
		}

		public override Vector2 GetWindowSize()
		{
			return this.windowSize;
		}

		public virtual bool CursorInList()
		{
			float y = Event.current.mousePosition.y - this.scroll.y;
			return y >= 0 && y < this.listCursorHeight;
		}


		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public override void OnGUI(Rect rect)
		{
			if(EditorWindow.focusedWindow != this.editorWindow)
			{
				this.Close();
				return;
			}

			EditorGUILayout.BeginVertical();

			this.topMode = this.editorWindow.position.y < this.callPosition.y;
			if(this.topMode)
			{
				if(this.animation.isAnimating)
				{
					Rect bounds = new Rect(this.animation.value * this.editorWindow.position.width, 0,
						this.editorWindow.position.width, this.listHeight);
					GUILayoutUtility.GetRect(this.editorWindow.position.width, this.listHeight);

					// previous list
					GUILayout.BeginArea(bounds);
					this.ShowList(this.previousList);
					this.ShowHeader(this.previousHeader);
					GUILayout.EndArea();

					// current list
					bounds.x += this.editorWindow.position.width * (this.animation.target * -1);
					GUILayout.BeginArea(bounds);
					this.ShowList(this.displayList);
					this.ShowHeader(this.header);
					GUILayout.EndArea();
				}
				else
				{
					this.ShowList(this.displayList);
					this.ShowHeader(this.header);
				}
				this.ShowSort();
				this.ShowSearch();
			}
			else
			{
				this.ShowSearch();
				this.ShowSort();

				if(this.animation.isAnimating)
				{
					Rect bounds = new Rect(this.animation.value * this.editorWindow.position.width,
						this.searchFieldHeight + this.sortFieldHeight,
						this.editorWindow.position.width, this.listHeight);
					GUILayoutUtility.GetRect(this.editorWindow.position.width, this.listHeight);

					// previous list
					GUILayout.BeginArea(bounds);
					this.ShowHeader(this.previousHeader);
					this.ShowList(this.previousList);
					GUILayout.EndArea();

					// current list
					bounds.x += this.editorWindow.position.width * (this.animation.target * -1);
					GUILayout.BeginArea(bounds);
					this.ShowHeader(this.header);
					this.ShowList(this.displayList);
					GUILayout.EndArea();
				}
				else
				{
					this.ShowHeader(this.header);
					this.ShowList(this.displayList);
				}
			}

			EditorGUILayout.EndVertical();


			// input
			if(this.displayList.Count > 0)
			{
				if(Event.current.type == EventType.MouseMove)
				{
					this.mouseMoved = true;
					this.editorWindow.Repaint();
				}

				// list navigation
				if(Event.current.keyCode == KeyCode.UpArrow)
				{
					if(Event.current.type == EventType.KeyUp)
					{
						this.holdingArrowKey = false;
						this.holdTimeout = 0;
					}
					else if(this.holdTimeout < Time.realtimeSinceStartup)
					{
						bool started = false;
						if(this.holdingArrowKey)
						{
							this.holdTimeout = Time.realtimeSinceStartup + 0.025f;
						}
						else
						{
							started = true;
							this.holdTimeout = Time.realtimeSinceStartup + 0.5f;
							this.holdingArrowKey = true;
						}

						if(this.selectedIndex == -1)
						{
							this.selectedIndex = this.displayList.Count - 1;
						}
						else
						{
							this.selectedIndex--;
							if(this.selectedIndex == 0 &&
								!started)
							{
								this.holdTimeout += 0.5f;
							}
							else if(this.selectedIndex < 0)
							{
								this.selectedIndex = this.displayList.Count - 1;
							}
						}
						this.editorWindow.Repaint();
						this.UpdateScrollPosition();
					}
				}
				else if(Event.current.keyCode == KeyCode.DownArrow)
				{
					if(Event.current.type == EventType.KeyUp)
					{
						this.holdingArrowKey = false;
						this.holdTimeout = 0;
					}
					else if(this.holdTimeout < Time.realtimeSinceStartup)
					{
						bool started = false;
						if(this.holdingArrowKey)
						{
							this.holdTimeout = Time.realtimeSinceStartup + 0.025f;
						}
						else
						{
							started = true;
							this.holdTimeout = Time.realtimeSinceStartup + 0.5f;
							this.holdingArrowKey = true;
						}

						if(this.selectedIndex == -1)
						{
							this.selectedIndex = 0;
						}
						else
						{
							this.selectedIndex++;
							if(this.selectedIndex == this.displayList.Count - 1 &&
								!started)
							{
								this.holdTimeout += 0.5f;
							}
							else if(this.selectedIndex >= this.displayList.Count)
							{
								this.selectedIndex = 0;
							}
						}
						this.editorWindow.Repaint();
						this.UpdateScrollPosition();
					}
				}
				// parent navigation
				else if(Event.current.keyCode == KeyCode.LeftArrow)
				{
					if(Event.current.type == EventType.KeyUp &&
						this.header != null)
					{
						Event.current.Use();
						this.selectedIndex = -1;
						this.previousHeader = this.header;
						this.header = this.header.parent;

						// animation
						this.previousList.Clear();
						this.previousList.AddRange(this.displayList);
						this.animation.value = 0;
						this.animation.target = 1;

						this.UpdateList();
						this.selectedIndex = this.displayList.IndexOf(this.previousHeader);
						this.editorWindow.Repaint();
					}
				}
				else if(Event.current.keyCode == KeyCode.RightArrow)
				{
					if(Event.current.type == EventType.KeyUp &&
						this.selectedIndex >= 0 &&
						this.selectedIndex < this.displayList.Count &&
						this.displayList[this.selectedIndex] is TypeElement)
					{
						Event.current.Use();
						this.displayList[this.selectedIndex].Accepted();
						this.selectedIndex = 0;
					}
				}
			}
			// accept/cancel
			if(Event.current.type == EventType.KeyUp)
			{
				if(Event.current.keyCode == KeyCode.Escape)
				{
					this.Close();
				}
				else if(Event.current.keyCode == KeyCode.Return ||
					Event.current.keyCode == KeyCode.KeypadEnter)
				{
					if(this.selectedIndex >= 0 &&
						this.selectedIndex < this.displayList.Count)
					{
						this.displayList[this.selectedIndex].Accepted();
					}
				}
			}
		}

		protected virtual void ShowSearch()
		{
			if(!this.isClosing)
			{
				EditorGUILayout.BeginVertical(EditorContent.Instance.PopupListStyle);
				this.search = this.searchField.OnGUI(this.search);
				if(this.search != this.lastSearch)
				{
					this.lastSearch = this.search;
					this.header = null;
					this.UpdateList();
				}
				EditorGUILayout.EndVertical();

				if(Event.current.type == EventType.Repaint)
				{
					this.searchFieldHeight = GUILayoutUtility.GetLastRect().height;
				}
			}
		}

		protected virtual void ShowSort()
		{
			int tmpSorting = this.sorting;

			EditorGUILayout.BeginHorizontal(EditorContent.Instance.PopupListStyle);
			for(int i = 0; i < this.sortingContent.Length; i++)
			{
				if(GUILayout.Toggle(this.sorting == i, this.sortingContent[i], "button"))
				{
					this.sorting = i;
				}
			}
			EditorGUILayout.EndHorizontal();

			if(this.sorting != tmpSorting)
			{
				this.UpdateList();
			}

			if(Event.current.type == EventType.Repaint)
			{
				this.sortFieldHeight = GUILayoutUtility.GetLastRect().height;
			}
		}

		protected virtual void ShowHeader(Element header)
		{
			if(this.hasTypes &&
				this.typeSeparation)
			{
				if(header != null)
				{
					if(GUILayout.Button(header.DisplayName,
							EditorContent.Instance.PopupListHeaderStyle) &&
						!this.animation.isAnimating)
					{
						this.selectedIndex = -1;
						this.previousHeader = header;
						this.header = header.parent;

						// animation
						this.previousList.Clear();
						this.previousList.AddRange(this.displayList);
						this.animation.value = 0;
						this.animation.target = 1;

						this.UpdateList();
						this.selectedIndex = this.displayList.IndexOf(this.previousHeader);
						this.editorWindow.Repaint();
					}
					EditorContent.Instance.DrawLeftArrow();
				}
				else
				{
					GUILayout.Label(this.name,
						EditorContent.Instance.PopupListHeaderStyle);
				}
			}
		}

		protected virtual void ShowList(List<Element> list)
		{
			this.scroll = EditorGUILayout.BeginScrollView(this.scroll);
			EditorGUILayout.BeginVertical();

			if(list.Count > 0)
			{
				if(!this.typeSeparation &&
					this.sorting >= 2)
				{
					string lastType = "";
					for(int i = 0; i < list.Count; i++)
					{
						if(lastType != list[i].TypeName)
						{
							lastType = list[i].TypeName;
							EditorTool.BoldLabel(lastType);
						}

						list[i].Show(i);
					}
				}
				else
				{
					for(int i = 0; i < list.Count; i++)
					{
						list[i].Show(i);
					}
				}
			}

			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();

			if(this.mouseMoved &&
				Event.current.type == EventType.Repaint)
			{
				this.mouseMoved = false;
				this.selectedIndex = -1;
				this.editorWindow.Repaint();
			}
		}

		protected virtual void UpdateList()
		{
			this.displayList.Clear();

			float height = 0;

			if(this.search == "")
			{
				for(int i = 0; i < this.tree.Count; i++)
				{
					if(this.tree[i].parent == this.header)
					{
						this.displayList.Add(this.tree[i]);
						height += this.tree[i].Height;
					}
				}
			}
			else
			{
				string[] searchSplit = this.search.Split(new char[] { ' ' },
					StringSplitOptions.RemoveEmptyEntries);

				for(int i = 0; i < this.tree.Count; i++)
				{
					if(this.tree[i].DisplayName.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0 ||
						this.tree[i].TypeName.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0 ||
						this.tree[i].Description.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0)
					{
						this.displayList.Add(this.tree[i]);
						height += this.tree[i].Height;
					}
					else
					{
						int count = 0;
						for(int j = 0; j < searchSplit.Length; j++)
						{
							if(this.tree[i].DisplayName.IndexOf(searchSplit[j], System.StringComparison.OrdinalIgnoreCase) >= 0 ||
								this.tree[i].TypeName.IndexOf(searchSplit[j], System.StringComparison.OrdinalIgnoreCase) >= 0 ||
								this.tree[i].Description.IndexOf(searchSplit[j], System.StringComparison.OrdinalIgnoreCase) >= 0)
							{
								count++;
							}
						}
						if(count == searchSplit.Length)
						{
							this.displayList.Add(this.tree[i]);
							height += this.tree[i].Height;
						}
					}
				}
			}

			this.displayList.Sort(new EditorDataSelectionSorter(this.sorting));

			string lastType = "";
			if(!this.typeSeparation &&
				this.sorting >= 2)
			{
				for(int i = 0; i < this.displayList.Count; i++)
				{
					if(lastType != this.displayList[i].TypeName)
					{
						lastType = this.displayList[i].TypeName;
						height += this.typeHeaderHeight;
					}
				}
			}

			this.UpdateIndex();
			this.UpdateHeight(height);
		}

		protected virtual void UpdateIndex()
		{
			this.index = -1;
			this.selectedIndex = -1;

			for(int i = 0; i < this.displayList.Count; i++)
			{
				if(this.displayList[i].asset == this.selection.Source.EditorAsset)
				{
					this.index = i;
					this.selectedIndex = i;
					break;
				}
			}
		}

		protected virtual void UpdateScrollPosition()
		{
			if(this.selectedIndex == 0)
			{
				this.scroll.y = 0;
			}
			else
			{
				float indexPos = 0;
				float selectedHeight = 0;
				if(this.selectedIndex >= 0 &&
					this.selectedIndex < this.displayList.Count)
				{
					selectedHeight = this.displayList[this.selectedIndex].Height;

					if(!this.typeSeparation &&
						this.sorting >= 2)
					{
						string lastType = "";
						for(int i = 0; i < this.selectedIndex; i++)
						{
							if(lastType != this.displayList[i].TypeName)
							{
								lastType = this.displayList[i].TypeName;
								indexPos += this.typeHeaderHeight;
							}
							indexPos += this.displayList[i].Height;

							if(i == this.selectedIndex - 1 &&
								lastType != this.displayList[this.selectedIndex].TypeName)
							{
								selectedHeight += this.typeHeaderHeight;
							}
						}
					}
					else
					{
						for(int i = 0; i < this.selectedIndex; i++)
						{
							indexPos += this.displayList[i].Height;
						}
					}
				}

				if(indexPos < this.scroll.y)
				{
					this.scroll.y = indexPos;
				}
				else if((this.scroll.y + this.editorWindow.position.height - this.searchFieldHeight -
					this.sortFieldHeight - this.headerHeight) < indexPos + selectedHeight)
				{
					this.scroll.y += (indexPos + selectedHeight) -
						(this.scroll.y + this.editorWindow.position.height - this.searchFieldHeight -
							this.sortFieldHeight - this.headerHeight);
				}
			}
		}

		protected virtual void CreateTree(EditorAssetSelectionConditionAttribute condition, List<IMakinomGenericAsset> data)
		{
			this.tree.Clear();
			this.tree.Add(new NoneElement(null, this));
			if(this.hasTypes &&
				this.typeSeparation)
			{
				Dictionary<IMakinomGenericAsset, Element> lookup = new Dictionary<IMakinomGenericAsset, Element>();
				for(int i = 0; i < data.Count; i++)
				{
					if(condition == null ||
						EditorAutomation.CheckConditions(data[i].EditorSettings,
							condition.checkField, condition.fieldValue, condition.fieldCheck, Needed.All))
					{
						IMakinomGenericAsset typeAsset = ((IHasTypeAsset)data[i]).TypeAsset;
						if(typeAsset == null)
						{
							this.tree.Add(new Element(data[i], this));
						}
						else
						{
							Element parent;
							if(!lookup.TryGetValue(typeAsset, out parent))
							{
								parent = new TypeElement(typeAsset, this);
								lookup.Add(typeAsset, parent);
								this.tree.Add(parent);
							}
							this.tree.Add(new Element(data[i], this, parent));
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < data.Count; i++)
				{
					if(condition == null ||
						EditorAutomation.CheckConditions(data[i].EditorSettings,
							condition.checkField, condition.fieldValue, condition.fieldCheck, Needed.All))
					{
						this.tree.Add(new Element(data[i], this));
					}
				}
			}
		}

		protected class EditorDataSelectionSorter : IComparer<Element>
		{
			protected int sorting = 0;

			public EditorDataSelectionSorter(int sorting)
			{
				this.sorting = sorting;
			}

			public int Compare(Element x, Element y)
			{
				if(this.sorting == 0)
				{
					return x.ID.CompareTo(y.ID);
				}
				else if(this.sorting == 1)
				{
					int tmp = x.Name.CompareTo(y.Name);
					if(tmp == 0)
					{
						return x.ID.CompareTo(y.ID);
					}
					return tmp;
				}
				else if(this.sorting == 2)
				{
					int tmp = x.TypeID.CompareTo(y.TypeID);
					if(tmp == 0)
					{
						return x.ID.CompareTo(y.ID);
					}
					return tmp;
				}
				else if(this.sorting == 3)
				{
					int tmp = x.TypeName.CompareTo(y.TypeName);
					if(tmp == 0)
					{
						tmp = x.Name.CompareTo(y.Name);
						if(tmp == 0)
						{
							return x.ID.CompareTo(y.ID);
						}
					}
					return tmp;
				}
				return 0;
			}
		}

		protected class Element
		{
			protected EditorAssetSelectionPopup popup;

			public Element parent;

			public IMakinomGenericAsset asset;

			public IMakinomGenericAsset typeAsset;

			protected string description = "";

			protected GUIContent content;

			protected float labelHeight = 30;

			public Element(IMakinomGenericAsset asset, EditorAssetSelectionPopup popup) : this(asset, popup, null)
			{

			}

			public Element(IMakinomGenericAsset asset, EditorAssetSelectionPopup popup, Element parent)
			{
				this.asset = asset;
				this.popup = popup;
				this.parent = parent;

				if(this.asset != null)
				{
					// type
					if(this.popup.hasTypes)
					{
						this.typeAsset = this.asset is IHasTypeAsset ?
							((IHasTypeAsset)this.asset).TypeAsset : null;
					}

					// description
					IContent content = this.asset.EditorSettings as IContent;
					if(content != null)
					{
						this.description = content.GetDescription();
					}
				}
				this.content = new GUIContent(this.DisplayName, Maki.EditorSettings.popupAssetTooltip ? this.Description : "");
				this.labelHeight = Mathf.Ceil(EditorContent.Instance.PopupListStyle.CalcHeight(this.content, this.popup.windowSize.x));
			}

			public virtual int ID
			{
				get { return this.asset.EditorSettings.ID; }
			}

			public virtual string Name
			{
				get { return this.asset.EditorSettings.EditorName; }
			}

			public virtual int TypeID
			{
				get
				{
					return this.typeAsset != null ?
						this.typeAsset.EditorSettings.ID : -1;
				}
			}

			public virtual string TypeName
			{
				get
				{
					return this.typeAsset != null ?
						this.typeAsset.EditorSettings.EditorName : "";
				}
			}

			public virtual string Description
			{
				get { return this.description; }
			}

			public virtual string DisplayName
			{
				get
				{
					return this.asset.GetEditorPopupName(
						this.popup.hasTypes && !this.popup.typeSeparation);
				}
			}

			public virtual void Show(int i)
			{
				if(GUILayout.Button(this.content,
					this.popup.index == i ?
						EditorContent.Instance.SelectedPopupListStyle :
						(this.popup.selectedIndex == i ?
							EditorContent.Instance.HoverPopupListStyle :
							EditorContent.Instance.PopupListStyle)) &&
					!this.popup.animation.isAnimating)
				{
					this.Accepted();
				}
				else if(this.popup.mouseMoved &&
					Event.current.type == EventType.Repaint &&
					GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition) &&
					this.popup.CursorInList())
				{
					this.popup.mouseMoved = false;
					this.popup.selectedIndex = i;
					this.popup.editorWindow.Repaint();
				}
			}

			public virtual float Height
			{
				get { return this.labelHeight; }
			}

			public virtual void Accepted()
			{
				if(this.popup.selectCallback != null)
				{
					this.popup.selectCallback(this.asset as UnityEngine.Object);
				}
				this.popup.Close();
			}
		}

		protected class NoneElement : Element
		{
			public NoneElement(IMakinomGenericAsset asset, EditorAssetSelectionPopup popup) : this(asset, popup, null)
			{

			}

			public NoneElement(IMakinomGenericAsset asset, EditorAssetSelectionPopup popup, Element parent) : base(asset, popup, parent)
			{

			}

			public override int ID
			{
				get { return -1; }
			}

			public override string Name
			{
				get { return ""; }
			}

			public override int TypeID
			{
				get { return -1; }
			}

			public override string TypeName
			{
				get { return ""; }
			}

			public override string DisplayName
			{
				get { return "-: None"; }
			}
		}

		protected class TypeElement : Element
		{
			public TypeElement(IMakinomGenericAsset asset, EditorAssetSelectionPopup popup) : this(asset, popup, null)
			{

			}

			public TypeElement(IMakinomGenericAsset asset, EditorAssetSelectionPopup popup, Element parent) : base(asset, popup, parent)
			{

			}

			public override int ID
			{
				get { return -1; }
			}

			public override string Name
			{
				get { return ""; }
			}

			public override int TypeID
			{
				get { return this.asset.EditorSettings.ID; }
			}

			public override string TypeName
			{
				get { return this.asset.EditorSettings.EditorName; }
			}

			public override string DisplayName
			{
				get { return this.asset.EditorSettings.EditorName; }
			}

			public override void Show(int i)
			{
				if(GUILayout.Button(this.content,
					this.popup.index == i ?
						EditorContent.Instance.SelectedPopupListTypeStyle :
						(this.popup.selectedIndex == i ?
							EditorContent.Instance.HoverPopupListTypeStyle :
							EditorContent.Instance.PopupListTypeStyle)) &&
					!this.popup.animation.isAnimating)
				{
					this.Accepted();
				}
				else if(this.popup.mouseMoved &&
					Event.current.type == EventType.Repaint &&
					GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition) &&
					this.popup.CursorInList())
				{
					this.popup.mouseMoved = false;
					this.popup.selectedIndex = i;
					this.popup.editorWindow.Repaint();
				}

				EditorContent.Instance.DrawRightArrow(true);
			}

			public override void Accepted()
			{
				this.popup.selectedIndex = -1;
				this.popup.previousHeader = this.popup.header;
				this.popup.header = this;

				// animation
				this.popup.previousList.Clear();
				this.popup.previousList.AddRange(this.popup.displayList);
				this.popup.animation.value = 0;
				this.popup.animation.target = -1;

				// clear search
				this.popup.search = "";
				this.popup.lastSearch = "";
				this.popup.searchField = new SearchField();
				this.popup.searchField.SetFocus();

				// update popup
				this.popup.UpdateList();
				this.popup.editorWindow.Repaint();
			}
		}
	}
}
