﻿
using UnityEngine;
using UnityEditor;
using UnityEditor.IMGUI.Controls;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorAssetSelectionPopupField
	{
		public delegate void Closed(UnityEngine.Object value);

		private MakinomEditorWindow parent;

		private Rect lastBounds;

		private bool isOpen = false;

		private bool changed = false;


		// next value
		private bool setNextValue = false;

		private UnityEngine.Object nextValue = null;

		public EditorAssetSelectionPopupField()
		{

		}

		public bool IsOpen
		{
			get { return this.isOpen; }
		}

		public void Edit(GUIContent content, ref AssetSource selection, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor)
		{
			if(this.changed &&
				Event.current.type == EventType.Repaint)
			{
				if(this.setNextValue)
				{
					this.setNextValue = false;
					selection.Source.EditorAsset = this.nextValue;
					selection.ResetStoredAsset();
					this.nextValue = null;
					GUI.FocusControl("");
				}
				GUI.changed = true;
				this.changed = false;
			}

			if(baseEditor != null && !baseEditor.isInspector)
			{
				if(this.parent == null)
				{
					this.parent = baseEditor is BaseEditorTab ?
						((BaseEditorTab)baseEditor).Editor :
						MakinomEditorWindow.Instance;
				}

				EditorGUILayout.BeginHorizontal();
			}

			GUILayoutOption layout = EditorTool.WIDTH_150;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
			}
			else if(attributes != null && attributes.width != null)
			{
				layout = attributes.width.GetWidth();
			}
			else if(Maki.EditorSettings.popupLonger)
			{
				layout = EditorTool.WIDTH_LONG;
			}

			EditorTool.BeginSetting(content.text, false);
			EditorGUILayout.BeginHorizontal();

			bool showName = attributes == null ||
				attributes.width == null ||
				!attributes.width.hideName ||
				baseEditor.isInspector;

			// name label
			if(showName)
			{
				EditorGUILayout.PrefixLabel(content);
			}

			// popup button
			if(EditorGUILayout.DropdownButton(
				new GUIContent(selection.Source.EditorAsset != null ?
					((IMakinomGenericAsset)selection.Source.EditorAsset).GetEditorPopupName(false) : "-: None",
					showName ? "" : content.tooltip),
				FocusType.Keyboard, layout))
			{
				GUI.FocusControl(content.text);
				this.isOpen = true;
				PopupWindow.Show(this.lastBounds,
					new EditorAssetSelectionPopup(content.text, ref selection, baseEditor,
						attributes != null ? attributes.assetSelectionCondition : null, this.lastBounds.height,
						EditorGUIUtility.GUIToScreenPoint(
							new Vector2(this.lastBounds.x, this.lastBounds.y + this.lastBounds.height)),
						this.lastBounds, this.SelectValue, this.PopupClosed));
			}
			else if(Event.current.type == EventType.Repaint)
			{
				this.lastBounds = GUILayoutUtility.GetLastRect();
			}

			EditorGUILayout.EndHorizontal();
			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, false);

			// buttons
			if(this.parent != null)
			{
				// add button
				EditorGUI.BeginDisabledGroup(attributes != null &&
					attributes.info != null &&
					attributes.info.blockDataPlusButton);
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.PlusIcon, "Adds new data to the list.")))
				{
					selection.Source.EditorAsset = EditorDataHandler.Instance.Add(selection.GetAssetType()) as UnityEngine.Object;
				}
				EditorTool.CheckHelpText("Add Data", "Adds new data to the list.", "");
				EditorGUI.EndDisabledGroup();

				// edit button
				EditorGUI.BeginDisabledGroup(selection.Source.EditorAsset == null);
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.EditIcon, "Navigates to this data's settings.")))
				{
					this.parent.EditSetting(selection.GetAssetType(), selection.Source.EditorAsset as IMakinomGenericAsset);
				}
				EditorTool.CheckHelpText("Edit Settings", "Navigates to this data's settings.", "");
				EditorGUI.EndDisabledGroup();

				EditorAutomation.Automate("type", selection, baseEditor, true);

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
			}
			else
			{
				EditorAutomation.Automate("type", selection, baseEditor, true);
			}
		}

		public void Edit(GUIContent content, AssetSource selection, string helpInfo,
			AttributeHelper attributes, BaseEditor baseEditor, EditorAssetSelectionPopupField.Closed selectCallback)
		{
			if(this.changed &&
				Event.current.type == EventType.Repaint)
			{
				GUI.changed = true;
				this.changed = false;
			}

			if(baseEditor != null && !baseEditor.isInspector)
			{
				if(this.parent == null)
				{
					this.parent = baseEditor is BaseEditorTab ?
						((BaseEditorTab)baseEditor).Editor :
						MakinomEditorWindow.Instance;
				}

				EditorGUILayout.BeginHorizontal();
			}

			GUILayoutOption layout = EditorTool.WIDTH_150;
			if(baseEditor != null && baseEditor.isInspector)
			{
				layout = EditorTool.W_EXPAND;
			}
			else if(attributes != null && attributes.width != null)
			{
				layout = attributes.width.GetWidth();
			}
			else if(Maki.EditorSettings.popupLonger)
			{
				layout = EditorTool.WIDTH_LONG;
			}

			EditorTool.BeginSetting(content.text, false);
			EditorGUILayout.BeginHorizontal();

			bool showName = attributes == null ||
				attributes.width == null ||
				!attributes.width.hideName ||
				baseEditor.isInspector;

			// name label
			if(showName)
			{
				EditorGUILayout.PrefixLabel(content);
			}

			// popup button
			if(EditorGUILayout.DropdownButton(
				new GUIContent(selection.Source.EditorAsset != null ?
					((IMakinomGenericAsset)selection.Source.EditorAsset).GetEditorPopupName(false) : "-: None",
					showName ? "" : content.tooltip),
				FocusType.Keyboard, layout))
			{
				GUI.FocusControl(content.text);
				this.isOpen = true;
				PopupWindow.Show(this.lastBounds,
					new EditorAssetSelectionPopup(content.text, ref selection, baseEditor,
						attributes != null ? attributes.assetSelectionCondition : null, this.lastBounds.height,
						EditorGUIUtility.GUIToScreenPoint(
							new Vector2(this.lastBounds.x, this.lastBounds.y + this.lastBounds.height)),
						this.lastBounds, selectCallback, this.PopupClosed));
			}
			else if(Event.current.type == EventType.Repaint)
			{
				this.lastBounds = GUILayoutUtility.GetLastRect();
			}

			EditorGUILayout.EndHorizontal();
			EditorTool.EndSetting(content.text, content.tooltip, helpInfo, false);

			// buttons
			if(this.parent != null)
			{
				// add button
				EditorGUI.BeginDisabledGroup(attributes != null &&
					attributes.info != null &&
					attributes.info.blockDataPlusButton);
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.PlusIcon, "Adds new data to the list.")))
				{
					selection.Source.EditorAsset = EditorDataHandler.Instance.Add(selection.GetAssetType()) as UnityEngine.Object;
				}
				EditorTool.CheckHelpText("Add Data", "Adds new data to the list.", "");
				EditorGUI.EndDisabledGroup();

				// edit button
				EditorGUI.BeginDisabledGroup(selection.Source.EditorAsset == null);
				if(EditorTool.Button(new GUIContent("", EditorContent.Instance.EditIcon, "Navigates to this data's settings.")))
				{
					this.parent.EditSetting(selection.GetAssetType(), selection.Source.EditorAsset as IMakinomGenericAsset);
				}
				EditorTool.CheckHelpText("Edit Settings", "Navigates to this data's settings.", "");
				EditorGUI.EndDisabledGroup();

				EditorAutomation.Automate("type", selection, baseEditor, true);

				GUILayout.FlexibleSpace();
				EditorGUILayout.EndHorizontal();
			}
			else
			{
				EditorAutomation.Automate("type", selection, baseEditor, true);
			}
		}

		public void EditSimple(string name, ref AssetSource selection, string helpText, string helpInfo,
			BaseEditor baseEditor, bool hideName, bool expandWidth)
		{
			if(this.changed &&
				Event.current.type == EventType.Repaint)
			{
				if(this.setNextValue)
				{
					this.setNextValue = false;
					selection.Source.EditorAsset = this.nextValue;
					selection.ResetStoredAsset();
					this.nextValue = null;
					GUI.FocusControl("");
				}
				GUI.changed = true;
				this.changed = false;
			}

			if(baseEditor != null && !baseEditor.isInspector)
			{
				if(this.parent == null)
				{
					this.parent = baseEditor is BaseEditorTab ?
						((BaseEditorTab)baseEditor).Editor :
						MakinomEditorWindow.Instance;
				}
			}

			GUILayoutOption layout = EditorTool.WIDTH_150;
			if(expandWidth || (baseEditor != null && baseEditor.isInspector))
			{
				layout = EditorTool.W_EXPAND;
			}

			EditorTool.BeginSetting(name, false);
			EditorGUILayout.BeginHorizontal();

			// name label
			if(!hideName)
			{
				EditorGUILayout.PrefixLabel(new GUIContent(name, helpText));
			}

			// popup button
			if(EditorGUILayout.DropdownButton(
				new GUIContent(selection.Source.EditorAsset != null ?
					((IMakinomGenericAsset)selection.Source.EditorAsset).GetEditorPopupName(false) : "-: None",
					hideName ? helpText : ""),
				FocusType.Keyboard, layout))
			{
				GUI.FocusControl(name);
				this.isOpen = true;
				PopupWindow.Show(this.lastBounds,
					new EditorAssetSelectionPopup(name, ref selection, baseEditor,
						null, this.lastBounds.height,
						EditorGUIUtility.GUIToScreenPoint(
							new Vector2(this.lastBounds.x, this.lastBounds.y + this.lastBounds.height)),
						this.lastBounds, this.SelectValue, this.PopupClosed));
			}
			else if(Event.current.type == EventType.Repaint)
			{
				this.lastBounds = GUILayoutUtility.GetLastRect();
			}
			EditorGUILayout.EndHorizontal();
			EditorTool.EndSetting(name, helpText, helpInfo, false);
		}

		private void SelectValue(UnityEngine.Object value)
		{
			this.setNextValue = true;
			this.nextValue = value;
			if(this.parent != null)
			{
				this.parent.Repaint();
			}
		}

		private void PopupClosed()
		{
			this.changed = true;
			this.isOpen = false;
			if(this.parent != null)
			{
				this.parent.Focus();
			}
		}
	}
}
