﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Net;

namespace GamingIsLove.Makinom.Editor.Packages
{
	public class PackageDownloader
	{
		protected MakinomExtensionManager.DownloadInfo source;

		protected WebClient client;

		protected string path;

		public int progress = 0;

		public PackageDownloader(MakinomExtensionManager.DownloadInfo source, string url, string fileName)
		{
			this.source = source;

			MakinomAssetHelper.CreateFolder(MakinomAssetHelper.DOWNLOAD_PATH);
			this.path = MakinomAssetHelper.DOWNLOAD_PATH + fileName;

			this.client = new WebClient();
			this.client.DownloadProgressChanged += this.DownloadProgressChanged;
			this.client.DownloadFileCompleted += this.DownloadFileCompleted;
			this.client.DownloadFileAsync(new System.Uri(url), this.path);
		}

		protected virtual void DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
		{
			this.progress = e.ProgressPercentage;
			this.source.section.parent.Repaint();
		}

		protected virtual void DownloadFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
		{
			if(e.Error == null)
			{
				AssetDatabase.Refresh();
				this.source.section.parent.Repaint();
				this.source.downloader = null;
				AssetDatabase.ImportPackage(this.path, true);
			}
		}
	}
}
