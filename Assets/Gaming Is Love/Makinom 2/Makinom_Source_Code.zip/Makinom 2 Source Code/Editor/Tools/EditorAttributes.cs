
using UnityEngine;
using GamingIsLove.Makinom.Schematics.Nodes;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.IO;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorAttributes
	{
		// instance
		private static EditorAttributes instance;

		private static System.Object instanceLock = new System.Object();


		// attribute data
		private Dictionary<System.Type, Dictionary<string, AttributeHelper>> attributes =
			new Dictionary<System.Type, Dictionary<string, AttributeHelper>>();

		private Dictionary<System.Type, EditorHelpAttribute> typeHelp = new Dictionary<System.Type, EditorHelpAttribute>();

		private Dictionary<System.Type, object> sortedEnum = new Dictionary<System.Type, object>();


		// node data
		private Dictionary<System.Type, Dictionary<System.Type, NodeInfo>> nodeInfos =
			new Dictionary<System.Type, Dictionary<System.Type, NodeInfo>>();


		// setting selection data
		private Dictionary<System.Type, EditorSortedSettingInfo> settingInfos =
			new Dictionary<System.Type, EditorSortedSettingInfo>();


		// language help import
		private Dictionary<string, GUIContent> helpImport = null;

		private EditorAttributes()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of EditorAttributes!");
			}
			else
			{
				instance = this;
			}
		}

		public static EditorAttributes Instance
		{
			get
			{
				if(instance == null)
				{
					lock(instanceLock)
					{
						if(instance == null)
						{
							new EditorAttributes();
						}
					}
				}
				return instance;
			}
		}

		public void Clear()
		{
			this.helpImport = null;

			this.attributes.Clear();
			this.typeHelp.Clear();
			this.sortedEnum.Clear();
			this.nodeInfos.Clear();
			this.settingInfos.Clear();
		}


		/*
		============================================================================
		Editor attribute handling
		============================================================================
		*/
		public static Dictionary<string, AttributeHelper> GetAttributes(System.Type type)
		{
			Dictionary<string, AttributeHelper> attributes;
			if(!EditorAttributes.Instance.attributes.TryGetValue(type, out attributes))
			{
				attributes = EditorAttributes.CreateAttributes(type);
				EditorAttributes.Instance.attributes.Add(type, attributes);
			}
			return attributes;
		}

		public static AttributeHelper GetAttribute(System.Reflection.FieldInfo fieldInfo, System.Type type)
		{
			Dictionary<string, AttributeHelper> attributes = EditorAttributes.GetAttributes(type);
			AttributeHelper helper;
			if(attributes != null &&
				attributes.TryGetValue(fieldInfo.Name, out helper))
			{
				return helper;
			}
			else
			{
				return EditorAttributes.GetFieldAttributes(fieldInfo);
			}
		}


		/*
		============================================================================
		Node help text handling
		============================================================================
		*/
		public static EditorHelpAttribute GetTypeHelpText(System.Type type)
		{
			EditorHelpAttribute help;
			if(!EditorAttributes.Instance.typeHelp.TryGetValue(type, out help))
			{
				object[] tmp = type.GetCustomAttributes(typeof(EditorHelpAttribute), true);
				if(tmp.Length > 0)
				{
					help = (EditorHelpAttribute)tmp[0];
				}
				else
				{
					tmp = type.GetCustomAttributes(typeof(EditorSettingInfoAttribute), true);
					if(tmp.Length > 0)
					{
						EditorSettingInfoAttribute info = (EditorSettingInfoAttribute)tmp[0];
						help = new EditorHelpAttribute(info.listName, info.content.tooltip);
					}
					else
					{
						help = new EditorHelpAttribute("Unknown", "");
					}
				}

				// get from import
				if(EditorAttributes.Instance.HasHelpImport)
				{
					GUIContent content = null;
					if(EditorAttributes.Instance.helpImport.TryGetValue(
						ReflectionTypeHandler.GetGenericTypeName(type), out content))
					{
						help = new EditorHelpAttribute(help);
						help.content = content;
					}
				}

				EditorAttributes.Instance.typeHelp.Add(type, help);
			}
			return help;
		}


		/*
		============================================================================
		Enum sort handling
		============================================================================
		*/
		public static EditorSortedEnum GetSortedEnum(object enumType)
		{
			System.Type type = enumType.GetType();
			object sorted;
			if(!EditorAttributes.Instance.sortedEnum.TryGetValue(type, out sorted))
			{
				sorted = new EditorSortedEnum(enumType);
				EditorAttributes.Instance.sortedEnum.Add(type, sorted);
			}
			return (EditorSortedEnum)sorted;
		}

		public static void ClearSortedEnums()
		{
			EditorAttributes.Instance.sortedEnum.Clear();
		}


		/*
		============================================================================
		Node info handling
		============================================================================
		*/
		public static Dictionary<System.Type, NodeInfo> GetNodeInfos(System.Type baseType)
		{
			Dictionary<System.Type, NodeInfo> list;
			if(!EditorAttributes.Instance.nodeInfos.TryGetValue(baseType, out list))
			{
				list = new Dictionary<System.Type, NodeInfo>();
				System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				for(int i = 0; i < assembly.Length; i++)
				{
					EditorAttributes.AddNodeInfoFromAssembly(baseType, assembly[i], ref list);
				}
				EditorAttributes.Instance.nodeInfos.Add(baseType, list);
			}
			return list;
		}

		private static void AddNodeInfoFromAssembly(System.Type baseType, System.Reflection.Assembly assembly,
			ref Dictionary<System.Type, NodeInfo> list)
		{
			try
			{
				System.Type[] types = assembly.GetTypes();
				for(int i = 0; i < types.Length; i++)
				{
					System.Type type = types[i].IsNested ? types[i].DeclaringType : types[i];
					if(!list.ContainsKey(type) &&
						!type.IsAbstract &&
						baseType.IsAssignableFrom(type))
					{
						GUIContent content = null;
						string info = "";
						object[] attr = type.GetCustomAttributes(typeof(EditorHelpAttribute), true);
						if(attr.Length > 0)
						{
							EditorHelpAttribute tmp = (EditorHelpAttribute)attr[0];
							content = tmp.content;
							info = tmp.info;
						}
						else
						{
							content = new GUIContent("", "");
						}

						// get from import
						if(EditorAttributes.Instance.HasHelpImport)
						{
							GUIContent importContent = null;
							if(EditorAttributes.Instance.helpImport.TryGetValue(
								ReflectionTypeHandler.GetGenericTypeName(type), out importContent))
							{
								content = importContent;
							}
						}

						string[] subMenu = new string[0];
						attr = type.GetCustomAttributes(typeof(NodeInfoAttribute), true);
						if(attr.Length > 0)
						{
							subMenu = (attr[0] as NodeInfoAttribute).subMenu;
						}
						list.Add(type, new NodeInfo(content, info, subMenu));
					}
				}
			}
			catch(System.Reflection.ReflectionTypeLoadException ex)
			{
				Debug.LogWarning("Issue while searching for nodes: " + ex.Message);
			}
		}

		public static NodeInfo GetNodeInfo(System.Type type)
		{
			try
			{
				if(!type.IsAbstract)
				{
					GUIContent content = null;
					string info = "";
					object[] attr = type.GetCustomAttributes(typeof(EditorHelpAttribute), true);
					if(attr.Length > 0)
					{
						EditorHelpAttribute tmp = (EditorHelpAttribute)attr[0];
						content = tmp.content;
						info = tmp.info;
					}
					else
					{
						content = new GUIContent("", "");
					}

					// get from import
					if(EditorAttributes.Instance.HasHelpImport)
					{
						GUIContent importContent = null;
						if(EditorAttributes.Instance.helpImport.TryGetValue(
							ReflectionTypeHandler.GetGenericTypeName(type), out importContent))
						{
							content = importContent;
						}
					}

					string[] subMenu = new string[0];
					attr = type.GetCustomAttributes(typeof(NodeInfoAttribute), true);
					if(attr.Length > 0)
					{
						subMenu = (attr[0] as NodeInfoAttribute).subMenu;
					}
					return new NodeInfo(content, info, subMenu);
				}
			}
			catch(System.Reflection.ReflectionTypeLoadException ex)
			{
				Debug.LogWarning("Issue while searching for nodes: " + ex.Message);
			}
			return null;
		}


		/*
		============================================================================
		Setting info handling
		============================================================================
		*/
		public static EditorSortedSettingInfo GetSettingInfos(System.Type baseType)
		{
			if(!EditorAttributes.Instance.settingInfos.ContainsKey(baseType))
			{
				List<SettingInfo> list = new List<SettingInfo>();
				List<System.Type> addedTypes = new List<System.Type>();
				System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				for(int i = 0; i < assembly.Length; i++)
				{
					EditorAttributes.AddSettingInfoFromAssembly(baseType, assembly[i],
						ref addedTypes, ref list);
				}
				EditorAttributes.Instance.settingInfos.Add(baseType, new EditorSortedSettingInfo(list));
			}
			return EditorAttributes.Instance.settingInfos[baseType];
		}

		private static void AddSettingInfoFromAssembly(System.Type baseType, System.Reflection.Assembly assembly,
			ref List<System.Type> addedTypes, ref List<SettingInfo> list)
		{
			try
			{
				System.Type[] types = assembly.GetTypes();
				for(int i = 0; i < types.Length; i++)
				{
					System.Type type = types[i].IsNested ? types[i].DeclaringType : types[i];
					if(!addedTypes.Contains(type) &&
						!type.IsAbstract &&
						baseType.IsAssignableFrom(type))
					{
						SettingInfo info = null;
						object[] attr = type.GetCustomAttributes(typeof(EditorSettingInfoAttribute), true);
						if(attr.Length > 0)
						{
							info = new SettingInfo(type, (EditorSettingInfoAttribute)attr[0]);
						}

						// get from import
						if(EditorAttributes.Instance.HasHelpImport)
						{
							GUIContent content = null;
							if(EditorAttributes.Instance.helpImport.TryGetValue(
								ReflectionTypeHandler.GetGenericTypeName(type),
								out content))
							{
								info.content = content;
							}
						}

						list.Add(info != null ? info : new SettingInfo(type));
						addedTypes.Add(type);
					}
				}
			}
			catch(System.Reflection.ReflectionTypeLoadException ex)
			{
				Debug.LogWarning("Issue while searching for settings: " + ex.Message);
			}
		}


		/*
		============================================================================
		Attribute functions
		============================================================================
		*/
		public static Dictionary<string, AttributeHelper> CreateAttributes(System.Type type)
		{
			Dictionary<string, AttributeHelper> list = new Dictionary<string, AttributeHelper>();
			if(type != null)
			{
				FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(type);
				for(int i = 0; i < field.Length; i++)
				{
					list.Add(field[i].Name, EditorAttributes.GetFieldAttributes(field[i]));
				}
			}
			return list;
		}

		public static AttributeHelper GetFieldAttributes(FieldInfo fieldInfo)
		{
			AttributeHelper attributes = new AttributeHelper();
			attributes.help = EditorAttributes.GetHelpTexts(fieldInfo, fieldInfo.Name);
			attributes.hide = EditorAttributes.GetEditorHide(fieldInfo);
			attributes.highlightSettings = EditorAttributes.GetHighlightSettings(fieldInfo);
			attributes.info = EditorAttributes.GetEditorInfo(fieldInfo);
			attributes.width = EditorAttributes.GetAttribute<EditorWidthAttribute>(fieldInfo);
			attributes.limit = EditorAttributes.GetAttribute<EditorLimitAttribute>(fieldInfo);
			attributes.array = EditorAttributes.GetArrayInfo(fieldInfo);
			attributes.reflection = EditorAttributes.GetAttribute<EditorReflectionFieldAttribute>(fieldInfo);

			// layout
			attributes.foldout = EditorAttributes.GetAttribute<EditorFoldoutAttribute>(fieldInfo);
			attributes.endFoldout = EditorAttributes.GetAttribute<EditorEndFoldoutAttribute>(fieldInfo);
			attributes.separator = EditorAttributes.GetSeparators(fieldInfo);
			attributes.indent = EditorAttributes.GetIndents(fieldInfo);
			attributes.titleLabel = EditorAttributes.GetAttribute<EditorTitleLabelAttribute>(fieldInfo);
			attributes.label = EditorAttributes.GetAttribute<EditorLabelAttribute>(fieldInfo);
			attributes.combinedField = EditorAttributes.GetClassAttribute<EditorCombinedFieldAttribute>(fieldInfo);

			// conditions
			attributes.condition = EditorAttributes.GetAttributeArray<EditorConditionAttribute>(fieldInfo);
			attributes.conditionCallback = EditorAttributes.GetAttributeArray<EditorConditionCallbackAttribute>(fieldInfo);
			attributes.elseCondition = EditorAttributes.GetAttribute<EditorElseConditionAttribute>(fieldInfo);
			attributes.endCondition = EditorAttributes.GetAttribute<EditorEndConditionAttribute>(fieldInfo);
			attributes.autoInit = EditorAttributes.GetAttribute<EditorAutoInitAttribute>(fieldInfo);
			attributes.defaultValue = EditorAttributes.GetAttribute<EditorDefaultValueAttribute>(fieldInfo);
			attributes.assetSelectionCondition = EditorAttributes.GetAttribute<EditorAssetSelectionConditionAttribute>(fieldInfo);

			// callbacks
			attributes.callback = EditorAttributes.GetAttributeArray<EditorCallbackAttribute>(fieldInfo);

			return attributes;
		}

		public static int GetHighlightSettings(FieldInfo fieldInfo)
		{
			object[] tmp = fieldInfo.FieldType.IsArray ?
				fieldInfo.FieldType.GetElementType().GetCustomAttributes(typeof(HighlightSettingsAttribute), true) :
				fieldInfo.FieldType.GetCustomAttributes(typeof(HighlightSettingsAttribute), true);
			if(tmp.Length > 0)
			{
				return ((HighlightSettingsAttribute)tmp[0]).color;
			}
			else
			{
				return -1;
			}
		}

		public static EditorHelpAttribute GetHelpTexts(FieldInfo fieldInfo, string name)
		{
			EditorHelpAttribute help = null;
			object[] tmp = fieldInfo.GetCustomAttributes(typeof(EditorHelpAttribute), true);
			if(tmp.Length > 0)
			{
				help = (EditorHelpAttribute)tmp[0];
			}
			else
			{
				help = new EditorHelpAttribute(name, "");
			}

			// get from import
			if(EditorAttributes.Instance.HasHelpImport)
			{
				GUIContent content = null;
				if(EditorAttributes.Instance.helpImport.TryGetValue(
					ReflectionTypeHandler.GetGenericTypeName(fieldInfo.DeclaringType) + "." + fieldInfo.Name,
					out content))
				{
					help = new EditorHelpAttribute(help);
					help.content = content;
				}
			}

			return help;
		}

		public static int GetEditorHide(FieldInfo fieldInfo)
		{
			object[] tmp = fieldInfo.GetCustomAttributes(typeof(EditorHideAttribute), true);
			if(tmp.Length > 0)
			{
				return ((EditorHideAttribute)tmp[0]).always ? 2 : 1;
			}
			else
			{
				return 0;
			}
		}

		public static EditorInfoAttribute GetEditorInfo(FieldInfo fieldInfo)
		{
			object[] tmp = fieldInfo.GetCustomAttributes(typeof(EditorInfoAttribute), true);
			if(tmp.Length > 0)
			{
				return tmp[0] as EditorInfoAttribute;
			}
			else
			{
				return new EditorInfoAttribute();
			}
		}

		public static EditorArrayAttribute GetArrayInfo(FieldInfo fieldInfo)
		{
			object[] tmp = fieldInfo.GetCustomAttributes(typeof(EditorArrayAttribute), true);
			if(tmp.Length > 0)
			{
				return tmp[0] as EditorArrayAttribute;
			}
			else
			{
				return new EditorArrayAttribute();
			}
		}

		public static T GetAttribute<T>(FieldInfo fieldInfo) where T : System.Attribute
		{
			object[] tmp = fieldInfo.GetCustomAttributes(typeof(T), true);
			if(tmp.Length > 0)
			{
				return tmp[0] as T;
			}
			return null;
		}

		public static T[] GetAttributeArray<T>(FieldInfo fieldInfo) where T : System.Attribute
		{
			return fieldInfo.GetCustomAttributes(typeof(T), true) as T[];
		}

		public static T GetClassAttribute<T>(FieldInfo fieldInfo) where T : System.Attribute
		{
			object[] tmp = fieldInfo.FieldType.IsArray ?
				fieldInfo.FieldType.GetElementType().GetCustomAttributes(typeof(T), true) :
				fieldInfo.FieldType.GetCustomAttributes(typeof(T), true);
			if(tmp.Length > 0)
			{
				return tmp[0] as T;
			}
			return null;
		}

		public static int GetSeparators(FieldInfo fieldInfo)
		{
			object[] tmp = fieldInfo.GetCustomAttributes(typeof(EditorSeparatorAttribute), true);
			if(tmp.Length > 0)
			{
				return ((EditorSeparatorAttribute)tmp[0]).count;
			}
			return 0;
		}

		public static int GetIndents(FieldInfo fieldInfo)
		{
			object[] tmp = fieldInfo.GetCustomAttributes(typeof(EditorIndentAttribute), true);
			if(tmp.Length > 0)
			{
				return ((EditorIndentAttribute)tmp[0]).count;
			}
			return 0;
		}


		/*
		============================================================================
		Export functions
		============================================================================
		*/
		public bool HasHelpImport
		{
			get
			{
				if(this.helpImport == null)
				{
					this.LoadEditorHelpExport();
				}
				return this.helpImport != null;
			}
		}

		public void SaveEditorHelpExport(string path)
		{
			if(!string.IsNullOrEmpty(path))
			{
				List<EditorHelpExport> list = EditorAttributes.Instance.GetEditorHelpExport();

				string separator = ";";
				string encloser = "\"";

				StringBuilder builder = new StringBuilder();
				builder.Append("Identification;Name;Description");

				for(int i = 0; i < list.Count; i++)
				{
					// identification
					builder.Append("\n").Append(list[i].identification);
					// name
					builder.Append(separator).Append(encloser).Append(list[i].content.text).Append(encloser);
					// text
					string helpText = list[i].content.tooltip;
					if(helpText.Contains("\""))
					{
						helpText = helpText.Replace("\"", "\"\"");
					}
					builder.Append(separator).Append(encloser).Append(helpText).Append(encloser);
				}


				using(StreamWriter writer = new StreamWriter(path))
				{
					writer.Write(builder.ToString());
					writer.Flush();
					writer.Close();
				}
			}
		}

		public void LoadEditorHelpExport()
		{
			this.helpImport = new Dictionary<string, GUIContent>();

			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
			if(editorAsset != null &&
				editorAsset.EditorHelpLanguageTexts != null)
			{
				string data = editorAsset.EditorHelpLanguageTexts.text.Replace("\r\n", "\n").Replace("\r", "\n");

				// header
				int index = data.IndexOf("\n");
				int currentIndex = index + 1;

				// data
				string separator = ";";
				string encloser = "\"";
				string textEnd = encloser + separator;
				string textEndLine = encloser + "\n";

				try
				{
					while(index >= 0 && index < data.Length)
					{
						// export ID
						index = data.IndexOf(separator, currentIndex);

						if(index >= 0 && index < data.Length)
						{
							string identification = data.Substring(currentIndex, index - currentIndex);
							currentIndex = index + separator.Length;

							// name
							string name = "";
							if(data.IndexOf(encloser, currentIndex) == currentIndex)
							{
								currentIndex += encloser.Length;
								index = data.IndexOf(textEnd, currentIndex);
								name = data.Substring(currentIndex, index - currentIndex).Replace("\"\"", "\"");
								currentIndex = index + textEnd.Length;
							}
							else
							{
								index = data.IndexOf(separator, currentIndex);
								name = data.Substring(currentIndex, index - currentIndex).Replace("\"\"", "\"");
								currentIndex = index + separator.Length;
							}

							// help text
							string helpText = "";
							if(data.IndexOf(encloser, currentIndex) == currentIndex)
							{
								currentIndex += encloser.Length;
								index = data.IndexOf(textEndLine, currentIndex);
								if(index == -1)
								{
									index = data.Length;
								}
								helpText = data.Substring(currentIndex, index - currentIndex).Replace("\"\"", "\"");
								currentIndex = index + textEndLine.Length;
							}
							else
							{
								index = data.IndexOf("\n", currentIndex);
								if(index == -1)
								{
									index = data.Length;
								}
								helpText = data.Substring(currentIndex, index - currentIndex).Replace("\"\"", "\"");
								currentIndex = index + "\n".Length;
							}

							if(!this.helpImport.ContainsKey(identification))
							{
								this.helpImport.Add(identification, new GUIContent(name, helpText));
							}
						}
					}
				}
				catch(System.Exception ex)
				{
					Debug.LogWarning("Unexpected data while reading CSV (UTF-8) editor help file.\n" +
						ex.Message + "\n" + ex.StackTrace);
				}
			}
		}

		public List<EditorHelpExport> GetEditorHelpExport()
		{
			System.Type baseType = typeof(IBaseData);
			List<EditorHelpExport> list = new List<EditorHelpExport>();
			HashSet<string> check = new HashSet<string>();
			Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
			for(int i = 0; i < assembly.Length; i++)
			{
				EditorAttributes.AddEditorHelpExportFromAssembly(baseType, assembly[i], ref list, ref check);
			}
			return list;
		}

		private static void AddEditorHelpExportFromAssembly(System.Type baseType, Assembly assembly,
			ref List<EditorHelpExport> list, ref HashSet<string> check)
		{
			try
			{
				System.Type[] types = assembly.GetTypes();
				for(int i = 0; i < types.Length; i++)
				{
					System.Type type = types[i].IsNested ? types[i].DeclaringType : types[i];
					if(!type.IsAbstract &&
						baseType.IsAssignableFrom(type))
					{
						// class help
						EditorHelpExport export = null;
						// help texts
						object[] tmp = type.GetCustomAttributes(typeof(EditorHelpAttribute), true);
						if(tmp.Length > 0)
						{
							string name = ReflectionTypeHandler.GetGenericTypeName(type);
							if(!check.Contains(name))
							{
								check.Add(name);
								export = new EditorHelpExport(name);
								export.content = ((EditorHelpAttribute)tmp[0]).content;
							}
						}
						else
						{
							tmp = type.GetCustomAttributes(typeof(EditorSettingInfoAttribute), true);
							if(tmp.Length > 0)
							{
								string name = ReflectionTypeHandler.GetGenericTypeName(type);
								if(!check.Contains(name))
								{
									check.Add(name);
									export = new EditorHelpExport(name);
									export.content = ((EditorSettingInfoAttribute)tmp[0]).content;
								}
							}
						}
						if(export != null)
						{
							list.Add(export);
						}


						FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(type);
						for(int j = 0; j < field.Length; j++)
						{
							export = null;
							// help texts
							tmp = field[j].GetCustomAttributes(typeof(EditorHelpAttribute), true);
							if(tmp.Length > 0)
							{
								string name = ReflectionTypeHandler.GetGenericTypeName(field[j].DeclaringType) + "." + field[j].Name;
								if(!check.Contains(name))
								{
									check.Add(name);
									export = new EditorHelpExport(name);
									export.content = ((EditorHelpAttribute)tmp[0]).content;
								}
							}
							if(export != null)
							{
								list.Add(export);
							}
						}
					}
				}
			}
			catch(System.Reflection.ReflectionTypeLoadException ex)
			{
				Debug.LogWarning("Issue while searching for editor help export: " + ex.Message);
			}
		}

		public class EditorHelpExport
		{
			public string identification = null;

			public GUIContent content = null;

			public EditorHelpExport(string identification)
			{
				this.identification = identification;
			}
		}
	}
}

