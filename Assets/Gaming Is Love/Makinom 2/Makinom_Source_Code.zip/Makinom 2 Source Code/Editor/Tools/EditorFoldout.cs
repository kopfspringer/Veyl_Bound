﻿
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorFoldout
	{
		private string path = "";


		// info
		private GUIContent content;

		private string helpInfo = "";

		private int depth = -1;

		private string storeName = "";


		// state
		private MakinomEditorAsset.FoldoutState state = new MakinomEditorAsset.FoldoutState();
		private bool expanded = true;

		private bool displayed = true;

		private bool searchMark = false;


		// scroll
		private float startPosition = 0;

		private float endPosition = 0;

		private bool visible = false;


		// color
		private Rect colorBounds = new Rect();

		private Color color = Color.white;

		public EditorFoldout(string path, GUIContent content, string helpInfo, bool expanded, string storeName)
		{
			this.path = path;
			this.content = content;
			this.helpInfo = helpInfo;
			this.expanded = expanded;

			if(storeName != "")
			{
				this.storeName = storeName + this.content.text;
				if(Maki.EditorSettings.rememberFoldouts)
				{
					EditorContent.Instance.TryGetFoldoutExpandedState(this.storeName, ref this.expanded);
				}
				if(Maki.EditorSettings.useFoldoutColors)
				{
					EditorContent.Instance.TryGetFoldoutColor(this.storeName, ref this.color);
				}
			}
		}

		public void Init(GUIContent content, string helpInfo, string storeName)
		{
			this.content = content;
			this.helpInfo = helpInfo;

			if(storeName != "")
			{
				this.storeName = storeName + this.content.text;
				if(Maki.EditorSettings.rememberFoldouts)
				{
					EditorContent.Instance.TryGetFoldoutExpandedState(this.storeName, ref this.expanded);
				}
				if(Maki.EditorSettings.useFoldoutColors)
				{
					EditorContent.Instance.TryGetFoldoutColor(this.storeName, ref this.color);
				}
			}
		}


		/*
		============================================================================
		Properties functions
		============================================================================
		*/
		public string Path
		{
			get { return this.path; }
		}

		public string Name
		{
			get { return this.content.text; }
		}

		public string HelpText
		{
			get { return this.content.tooltip; }
		}

		public string HelpInfo
		{
			get { return this.helpInfo; }
		}

		public int Depth
		{
			get { return this.depth; }
			set { this.depth = value; }
		}

		public bool Expanded
		{
			get { return this.expanded; }
			set
			{
				if(this.expanded != value)
				{
					this.expanded = value;
					if(Maki.EditorSettings.rememberFoldouts)
					{
						EditorContent.Instance.SetFoldoutExpandedState(this.storeName, this.expanded);
					}
				}
			}
		}

		public bool Displayed
		{
			get { return this.displayed; }
			set { this.displayed = value; }
		}

		public bool SearchMark
		{
			get { return this.searchMark; }
			set { this.searchMark = value; }
		}

		public float StartPosition
		{
			get { return this.startPosition; }
		}

		public float EndPosition
		{
			get { return this.endPosition; }
		}

		public bool Visible
		{
			get { return this.visible; }
		}


		/*
		============================================================================
		Foldout functions
		============================================================================
		*/
		public void Open(BaseEditor editor)
		{
			if(editor.isInspector)
			{
				EditorTool.BeginFoldoutInspector(ref this.expanded, this.content, helpInfo);
			}
			else if(Maki.EditorSettings.useFoldoutColors)
			{
				Color tmpColor = GUI.backgroundColor;
				GUI.backgroundColor = this.color;

				if(!Maki.EditorSettings.prettyFoldouts)
				{
					bool tmp = this.expanded;
					EditorTool.BeginFoldout(ref tmp, this.content, helpInfo);
					this.Expanded = tmp;
				}
				else
				{
					bool tmp = this.expanded;
					EditorTool.BeginFoldout(ref tmp, this.content, helpInfo, depth);
					this.Expanded = tmp;
				}

				GUI.backgroundColor = tmpColor;

				EditorGUI.BeginChangeCheck();
				this.color = EditorGUI.ColorField(this.colorBounds, GUIContent.none, this.color, false, false, false);
				if(EditorGUI.EndChangeCheck() &&
					this.storeName != "")
				{
					EditorContent.Instance.SetFoldoutColor(this.storeName, this.color);
				}
			}
			else
			{
				if(!Maki.EditorSettings.prettyFoldouts)
				{
					bool tmp = this.expanded;
					EditorTool.BeginFoldout(ref tmp, this.content, helpInfo);
					this.Expanded = tmp;
				}
				else
				{
					bool tmp = this.expanded;
					EditorTool.BeginFoldout(ref tmp, this.content, helpInfo, depth);
					this.Expanded = tmp;
				}
			}

			if(Event.current.type == EventType.Repaint)
			{
				this.startPosition = GUILayoutUtility.GetLastRect().y - 30;
			}
		}

		public void Close(BaseEditor editor)
		{
			if(this.expanded)
			{
				EditorGUILayout.Separator();
			}
			EditorTool.EndFoldout();

			if(Event.current.type == EventType.Repaint)
			{
				Rect bounds = GUILayoutUtility.GetLastRect();
				this.endPosition = bounds.y + bounds.height;

				if(Maki.EditorSettings.useFoldoutColors)
				{
					bounds.y += 1;
					if(this.colorBounds.y != bounds.y)
					{
						editor.Repaint();
					}
					this.colorBounds = bounds;
					this.colorBounds.x += this.colorBounds.width - 12;
					this.colorBounds.width = 10;
					this.colorBounds.height = 10;
				}
			}

			if(Maki.EditorSettings.foldoutSeparator)
			{
				EditorGUILayout.Separator();
			}
		}

		public void CheckVisible(float scroll, float nextPosition, float height)
		{
			this.visible = (scroll - 100 < this.startPosition ||
					(nextPosition > 0 && scroll + 100 < nextPosition)) &&
				this.startPosition < scroll + height - 200 &&
				scroll + 25 < this.endPosition;
		}

		public bool Button()
		{
			bool press = false;
			GUIStyle guiStyle = new GUIStyle(EditorStyles.label);
			guiStyle.fontSize = Mathf.Max(13 - this.depth, 10);
			if(this.searchMark)
			{
				guiStyle.normal.textColor = Maki.EditorSettings.searchJumpListHighlightColor;
			}
			else if(Maki.EditorSettings.useFoldoutColors &&
				Maki.EditorSettings.foldoutColorJumplist &&
				this.color != Color.white)
			{
				guiStyle.normal.textColor = this.color;
			}

			if(this.visible)
			{
				guiStyle.fontStyle = this.depth == 0 ? FontStyle.BoldAndItalic : FontStyle.Italic;
			}
			else
			{
				guiStyle.fontStyle = this.depth == 0 ? FontStyle.Bold : FontStyle.Normal;
			}

			guiStyle.margin = new RectOffset(0, 0, this.depth == 0 ? 10 : Mathf.Max(6 - this.depth * 2, 0), 0);
			guiStyle.padding = new RectOffset(3 + this.depth * 10, 0, 3, 3);

			if(GUILayout.Button("• " + this.content.text, guiStyle))
			{
				press = true;
			}
			EditorTool.CheckHelpText(this.content.text, this.content.tooltip, this.helpInfo);
			return press;
		}
	}
}
