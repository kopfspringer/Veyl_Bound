﻿
using UnityEngine;
using System;

namespace GamingIsLove.Makinom.Editor
{
	public enum EditorDataChangeInformationType { Remove, GUIDChange, UISystemChange, SubDataRemoved };

	public class EditorDataChangeInformation
	{
		public EditorDataChangeInformationType changeType = EditorDataChangeInformationType.Remove;

		public System.Type assetType;

		public IMakinomGenericAsset asset;


		// GUID
		public string oldGUID = "";

		public string newGUID = "";

		public int index = 0;

		public int count = 0;

		public EditorDataChangeInformation(EditorDataChangeInformationType changeType)
		{
			this.changeType = changeType;
		}

		public EditorDataChangeInformation(EditorDataChangeInformationType changeType,
			System.Type assetType, IMakinomGenericAsset asset)
		{
			this.changeType = changeType;
			this.assetType = assetType;
			this.asset = asset;
		}

		public EditorDataChangeInformation(EditorDataChangeInformationType changeType,
			System.Type assetType, string oldGUID, string newGUID)
		{
			this.changeType = changeType;
			this.assetType = assetType;
			this.oldGUID = oldGUID;
			this.newGUID = newGUID;
		}

		public EditorDataChangeInformation(EditorDataChangeInformationType changeType, 
			System.Type assetType, IMakinomGenericAsset asset, int index, int count)
		{
			this.changeType = changeType;
			this.assetType = assetType;
			this.asset = asset;
			this.index = index;
			this.count = count;
		}
	}
}
