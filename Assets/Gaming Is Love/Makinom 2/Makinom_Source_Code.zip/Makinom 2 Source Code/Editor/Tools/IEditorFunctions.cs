﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IEditorFunctions
	{
		void IconTextCodeButton(IconContent content);
	}
}
