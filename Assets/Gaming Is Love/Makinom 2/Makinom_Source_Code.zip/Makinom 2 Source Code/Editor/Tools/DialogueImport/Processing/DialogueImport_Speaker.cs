﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class DialogueImport_Speaker : BaseData, IFoldoutInfo
	{
		[EditorHelp("Found Title", "The title that was found for the speaker.")]
		[EditorInfo(isStandardTextArea = true)]
		[EditorWidth(true)]
		public string foundTitle = "";

		[EditorHelp("UI Box", "Define the UI box that will be used for this speaker.")]
		[EditorSeparator]
		public AssetSelection<UIBoxAsset> uiBox = new AssetSelection<UIBoxAsset>();


		// speaker
		[EditorHelp("Use Speaker", "A selected actor will be used as speaker.\n" +
			"You can display the name of the speaker. The speaker's game object can be used to play an audio clip.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Speaker Settings")]
		public bool useSpeaker = false;

		[EditorHelp("Actor", "Select the actor that will be used as speaker.", "")]
		[EditorInfo(isTabPopup = true, tabPopupID = 0)]
		[EditorCondition("useSpeaker", true)]
		public int actorID = 0;


		// at actor position
		[EditorHelp("Display At Actor", "The UI box will be displayed at the position of the actor.\n" +
			"If disabled or the actor has no game object, the UI box is placed as defined by the prefab.", "")]
		[EditorSeparator]
		public bool atActorPosition = false;

		[EditorHelp("Path to Child", "The UI box is positioned at a child object of the actor.\n" +
			"Leave empty if no child object should be used.", "")]
		[EditorWidth(true)]
		[EditorCondition("atActorPosition", true)]
		public string posChildName = "";

		[EditorHelp("Offset", "Offset added to the object's position.", "")]
		[EditorEndCondition]
		public Vector2 posOff = Vector2.zero;


		// name
		[EditorHelp("Show Name", "Show the name of the speaker in the title content of the UI box.", "")]
		[EditorSeparator]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool speakerName = false;


		// title
		[EditorHelp("Show Title", "Display a title in the title content of the used UI box.", "")]
		[EditorSeparator]
		[EditorCondition("speakerName", false)]
		[EditorDefaultValue(false)]
		public bool useTitle = true;

		[EditorHelp("Title Content", "The title content of the box.", "")]
		[EditorLabel("<name> = speaker name, <shortname> = speaker short name (when using a speaker)")]
		[EditorCondition("useTitle", true)]
		[EditorEndCondition(2)]
		[EditorLanguageExport("Title")]
		public TextContent titleText;


		// portrait
		[EditorHelp("Show Portraits", "Show portraits when displaying the dialogue.")]
		[EditorFoldout("Portrait Content", "Optionally show portraits in the dialogue.", "")]
		public bool showPortraits = false;

		[EditorEndFoldout]
		[EditorCondition("showPortraits", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public PortraitContent<ActorPortraitSelection> portraits;

		public DialogueImport_Speaker()
		{
			this.titleText = new TextContent();
		}

		public DialogueImport_Speaker(string title)
		{
			this.foundTitle = title;
			this.titleText = new TextContent(title);
		}

		public virtual string GetFoldoutInfo()
		{
			return this.foundTitle;
		}

		public virtual string GetName()
		{
			return this.foundTitle;
		}

		public virtual void SetSpeaker(DialogueControl control)
		{
			control.SetData(this.GetData());
			if(this.useTitle && !this.speakerName)
			{
				control.title = new Content();
				control.title.mainContent.data.text.SetData(this.titleText.GetData());
			}

			// ui box
			control.box.box.SetData(this.uiBox.GetData());
		}
	}
}
