﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.Schematics.Nodes;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public class DialogueImport_Dialogue : BaseData, IFoldoutInfo
	{
		[EditorHelp("Next Dialogue", "Select the dialogue that will be opened after this dialogue.")]
		[EditorInfo(isTabPopup = true, tabPopupID = 2)]
		public int next = 0;

		[EditorHelp("Use Speaker", "The dialogue uses one of the found speakers.", "")]
		public bool useSpeaker = false;

		[EditorHelp("Speaker", "Select the speaker that will be used.")]
		[EditorInfo(isTabPopup = true, tabPopupID = 1)]
		[EditorCondition("useSpeaker", true)]
		[EditorEndCondition]
		public int speakerID = -1;


		// own UI box
		[EditorHelp("Own UI Box", "Use a different UI box than defined by the speaker.")]
		[EditorSeparator]
		[EditorCondition("useSpeaker", true)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool ownUIBox = false;

		[EditorHelp("UI Box", "Define the UI box that will be used for this speaker.")]
		[EditorCondition("useSpeaker", false)]
		[EditorCondition("ownUIBox", true)]
		[EditorEndCondition]
		public AssetSelection<UIBoxAsset> uiBox = new AssetSelection<UIBoxAsset>();


		// message
		[EditorHelp("Message Content", "The content displayed in the dialogue.", "")]
		[EditorLabel("<name> = speaker name, <shortname> = speaker short name (when using a speaker)")]
		[EditorLanguageExport("Message")]
		public TextContent messageText;


		// portrait
		[EditorHelp("Own Portraits", "Override the portraits defined by the speaker.")]
		[EditorFoldout("Portrait Content", "Optionally show portraits in the dialogue.", "")]
		[EditorCondition("useSpeaker", true)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool ownPortraits = false;

		[EditorHelp("Show Portraits", "Show portraits when displaying the dialogue.")]
		[EditorCondition("useSpeaker", false)]
		[EditorCondition("ownPortraits", true)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool showPortraits = false;

		[EditorEndFoldout]
		[EditorCondition("showPortraits", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public PortraitContent<ActorPortraitSelection> portraits;


		// choices
		[EditorArray(foldout = true, foldoutText = new string[] {
				"Choice", "Define the text of the choice.", ""
			})]
		public DialogueImport_Choice[] choice;

		public DialogueImport_Dialogue()
		{
			this.messageText = new TextContent();
		}

		public DialogueImport_Dialogue(string message)
		{
			this.messageText = new TextContent(message);
		}

		public virtual string GetFoldoutInfo()
		{
			return this.useSpeaker ? "Speaker " + this.speakerID : "No Speaker";
		}

		public virtual string GetName()
		{
			int index = this.messageText.text.IndexOf('\n');
			if(index >= 0 && index <= 20)
			{
				return this.messageText.text.Substring(0, index);
			}
			else if(this.messageText.text.Length < 20)
			{
				return this.messageText.text;
			}
			else
			{
				return this.messageText.text.Substring(0, 20) + "...";
			}
		}

		public virtual ShowDialogueNode CreateDialogue(DialogueImportContent importContent)
		{
			ShowDialogueNode node = new ShowDialogueNode();
			node.dialogue.type = this.choice != null ? DialogueType.Choice : DialogueType.Message;

			if(this.useSpeaker)
			{
				if(this.speakerID >= 0 &&
					this.speakerID < importContent.speakers.Length)
				{
					importContent.speakers[this.speakerID].SetSpeaker(node.dialogue);
				}
				// ui box
				if(this.ownUIBox)
				{
					node.dialogue.box.box.SetData(this.uiBox.GetData());
				}
				// portraits
				if(this.ownPortraits)
				{
					node.dialogue.showPortraits = this.showPortraits;
					if(this.showPortraits)
					{
						node.dialogue.portraits = new PortraitContent<ActorPortraitSelection>();
						node.dialogue.portraits.SetData(this.portraits.GetData());
					}
					else
					{
						node.dialogue.portraits = null;
					}
				}
			}
			else
			{
				// ui box
				node.dialogue.box.box.SetData(this.uiBox.GetData());
				// portraits
				node.dialogue.showPortraits = this.showPortraits;
				if(this.showPortraits)
				{
					node.dialogue.portraits = new PortraitContent<ActorPortraitSelection>();
					node.dialogue.portraits.SetData(this.portraits.GetData());
				}
				else
				{
					node.dialogue.portraits = null;
				}
			}

			node.dialogue.message.mainContent.data.text.SetData(this.messageText.GetData());
			node.SetNext(0, this.next - 1);

			// choices
			if(this.choice != null)
			{
				node.dialogue.headerTexts = new Headers();
				node.dialogue.choiceOption = new ChoiceOption[this.choice.Length];
				for(int i = 0; i < this.choice.Length; i++)
				{
					node.dialogue.choiceOption[i] = this.choice[i].CreateChoice();
				}
			}

			return node;
		}
	}
}
