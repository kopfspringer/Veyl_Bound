
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class SoundTemplateAsset : MakinomGenericAsset<SoundTemplate>
	{
		public SoundTemplateAsset()
		{

		}

		public override string DataName
		{
			get { return "Sound Template"; }
		}
	}

	public class SoundTemplate : BaseIndexData
	{
		[EditorHelp("Name", "The name of this template.", "")]
		[EditorFoldout("Base Settings", "Set the name of this sound template.", "")]
		[EditorEndFoldout]
		[EditorWidth(true)]
		public string name = "";


		// sounds
		[EditorArray("Add Sound", "Adds a sound to this sound template.\n" +
			"A sound assigns an audio clip to a sound type.", "",
			"Remove", "Removes this sound from the template.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Sound", "Select the sound type and audio clip that will be used by this sound.", ""
		})]
		public Sound[] sound = new Sound[0];

		public SoundTemplate()
		{

		}

		public SoundTemplate(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}

		public AudioClip GetClip(SoundTypeAsset type)
		{
			for(int i = 0; i < this.sound.Length; i++)
			{
				if(this.sound[i].soundType.Is(type))
				{
					return this.sound[i].GetSound();
				}
			}
			return null;
		}
	}
}