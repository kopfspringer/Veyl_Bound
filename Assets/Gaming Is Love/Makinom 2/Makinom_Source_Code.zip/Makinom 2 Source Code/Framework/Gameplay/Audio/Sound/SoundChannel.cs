﻿
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class SoundChannel : AudioChannel
	{
		// objects
		protected AudioMixerGroup audioMixerGroup;

		protected GameObject gameObject;

		protected AudioSource source;

		protected List<AudioSource> registeredSources = new List<AudioSource>();

		public SoundChannel(GameObject parent, int channel)
		{
			this.gameObject = new GameObject("Sound Channel " + channel);
			this.gameObject.transform.SetParent(parent.transform);

			this.source = this.AddAudioSource(this.gameObject);
		}


		/*
		============================================================================
		Audio source functions
		============================================================================
		*/
		public override void SetOutput(AudioMixerGroup audioMixerGroup)
		{
			this.audioMixerGroup = audioMixerGroup;
			if(this.source != null)
			{
				this.source.outputAudioMixerGroup = audioMixerGroup;
			}
		}

		public virtual void PlayOneShot(AudioClip clip, float volume)
		{
			if(clip != null &&
				this.source != null)
			{
				this.source.PlayOneShot(clip, volume * this.Volume * Maki.Audio.SoundVolume);
			}
		}

		public virtual AudioSource Source
		{
			get { return this.source; }
		}

		public virtual void Register(AudioSource audioSource)
		{
			if(audioSource != null)
			{
				audioSource.volume = this.Volume * Maki.Audio.SoundVolume;
				audioSource.outputAudioMixerGroup = this.audioMixerGroup;
				this.registeredSources.Add(audioSource);
			}
		}

		public virtual void Unregister(AudioSource audioSource)
		{
			if(audioSource != null)
			{
				this.registeredSources.Remove(audioSource);
			}
		}


		/*
		============================================================================
		Volume functions
		============================================================================
		*/
		public override void UpdateVolume()
		{
			if(this.source != null)
			{
				this.source.volume = this.Volume * Maki.Audio.SoundVolume;
			}
			for(int i = 0; i < this.registeredSources.Count; i++)
			{
				if(this.registeredSources[i] != null)
				{
					this.registeredSources[i].volume = this.Volume * Maki.Audio.SoundVolume;
				}
				else
				{
					this.registeredSources.RemoveAt(i--);
				}
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public override void SetPCM(int pcm)
		{
			if(pcm < 0)
			{
				pcm = 0;
			}
			if(this.source != null)
			{
				this.source.timeSamples = pcm;
			}
		}

		public override void SetTime(float time)
		{
			if(time < 0)
			{
				time = 0;
			}
			if(this.source != null)
			{
				this.source.time = time;
			}
		}

		public override void Stop()
		{
			this.source.Stop();

			for(int i = 0; i < this.registeredSources.Count; i++)
			{
				if(this.registeredSources[i] != null)
				{
					this.registeredSources[i].Stop();
				}
				else
				{
					this.registeredSources.RemoveAt(i--);
				}
			}
		}
	}
}
