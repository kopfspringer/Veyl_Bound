﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class SoundSettings : BaseData
	{
		[EditorHelp("Sound Template", "Select the sound template that will be used.", "")]
		public AssetSelection<SoundTemplateAsset> soundTemplate = new AssetSelection<SoundTemplateAsset>();

		[EditorArray("Add Sound", "Adds a sound to the list.", "",
			"Remove", "Removes this sound.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Sound", "The sound is played if the selected sound type is played.", ""
		})]
		public Sound[] sound = new Sound[0];

		public SoundSettings()
		{

		}

		public virtual AudioClip GetAudioClip(SoundTypeAsset soundType)
		{
			for(int i = 0; i < this.sound.Length; i++)
			{
				if(this.sound[i].soundType.Is(soundType))
				{
					return this.sound[i].GetSound();
				}
			}
			if(this.soundTemplate.StoredAsset != null)
			{
				AudioClip clip = this.soundTemplate.StoredAsset.Settings.GetClip(soundType);
				if(clip != null)
				{
					return clip;
				}
			}
			return null;
		}
	}
}
