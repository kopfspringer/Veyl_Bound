﻿
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class AudioChannel : ISaveData
	{
		// volume
		protected float volume = 1;

		protected bool mute = false;

		protected Interpolation.FloatInstance fadeVolume;

		public virtual void SetOutput(AudioMixerGroup audioMixerGroup)
		{
			
		}

		protected virtual AudioSource AddAudioSource(GameObject gameObject)
		{
			AudioSource audioSource = gameObject.AddComponent<AudioSource>();
			audioSource.spatialBlend = 0;
			audioSource.priority = 0;
			audioSource.ignoreListenerVolume = true;
			return audioSource;
		}


		/*
		============================================================================
		Volume functions
		============================================================================
		*/
		public virtual float Volume
		{
			get { return this.mute ? 0 : this.volume; }
			set
			{
				this.volume = value;
				if(this.volume < 0)
				{
					this.volume = 0;
				}
				else if(this.volume > 1)
				{
					this.volume = 1;
				}
				this.UpdateVolume();
			}
		}

		public virtual float RealVolume
		{
			get { return this.volume; }
		}

		public virtual bool Mute
		{
			get { return this.mute; }
			set
			{
				if(this.mute != value)
				{
					this.mute = value;
					this.UpdateVolume();
				}
			}
		}

		public virtual void FadeVolume(float toVolume, Interpolation interpolation, float time)
		{
			ValueHelper.Limit(ref toVolume, 0.0f, 1.0f);
			this.fadeVolume = interpolation.CreateFloat(this.Volume, toVolume, time);
		}

		public virtual void UpdateVolume()
		{

		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public virtual void Tick()
		{
			// volume fading
			if(this.fadeVolume != null)
			{
				this.Volume = this.fadeVolume.Tick(Time.unscaledDeltaTime);
				if(this.fadeVolume.Finished)
				{
					this.fadeVolume = null;
				}
			}
		}

		public virtual void SetPCM(int pcm)
		{

		}

		public virtual void SetTime(float time)
		{

		}

		public virtual void Stop()
		{

		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public virtual DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("volume", this.volume);
			data.Set("mute", this.mute);

			return data;
		}

		public virtual void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("volume", ref this.volume);
				data.Get("mute", ref this.mute);
			}
		}
	}
}
