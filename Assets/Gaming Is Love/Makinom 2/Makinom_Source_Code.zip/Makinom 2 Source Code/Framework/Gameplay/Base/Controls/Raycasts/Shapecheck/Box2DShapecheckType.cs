﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Box 2D", "Checks if colliders fall within a box (uses 'Collider2D').")]
	public class Box2DShapecheckType<T> : BaseShapecheckType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Origin")]
		[EditorLabel("The point in 2D space where the shape originates.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Size")]
		[EditorLabel("The size of the shape.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> size = new Vector3Value<T>();

		[EditorHelp("Angle", "The angle of the shape (in degrees).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Angle")]
		public FloatValue<T> angle = new FloatValue<T>();


		// depth
		[EditorHelp("Minimum Depth", "Only include objects with a Z coordinate (depth) greater than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Minimum Depth")]
		public FloatValue<T> minDepth = new FloatValue<T>(typeof(FloatValue_NegativeInfinityType<T>));

		[EditorHelp("Maximum Depth", "Only include objects with a Z coordinate (depth) less than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Depth")]
		public FloatValue<T> maxDepth = new FloatValue<T>(typeof(FloatValue_InfinityType<T>));

		public Box2DShapecheckType()
		{

		}

		public override string ToString()
		{
			return "Box 2D";
		}

		public override bool Is2D
		{
			get { return true; }
		}

		public override bool Check(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapBox(
				this.origin.GetValue(call), this.size.GetValue(call),
				this.angle.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call)) != null;
		}

		public override Collider Overlap(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider[] OverlapAll(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider2D Overlap2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapBox(
				this.origin.GetValue(call), this.size.GetValue(call),
				this.angle.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}

		public override Collider2D[] OverlapAll2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapBoxAll(
				this.origin.GetValue(call), this.size.GetValue(call),
				this.angle.GetValue(call), layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}
	}
}
