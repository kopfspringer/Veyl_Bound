﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class AssetBundleSettings : BaseData
	{
		[EditorHelp("Asset Bundle Name", "Define the name of the asset bundle.", "")]
		[EditorWidth(true)]
		public string assetBundleName = "";


		// asset bundle path
		[EditorHelp("Own Asset Bundle Path", "This asset bundle overrides the default asset bundle path defined in the game settings.", "")]
		public bool ownPath = false;

		[EditorHelp("Asset Bundle Path", "Define the path the asset bundle will be available at.\n" +
			"The asset bundle will be loaded using 'AssetBundle.LoadFromFile' using this path (and the asset bundle name).", "")]
		[EditorCondition("ownPath", true)]
		[EditorAutoInit]
		public ApplicationPath path;

		[EditorHelp("Load Type", "Select the way this asset bundle will be loaded:\n" +
			"- Load From File: Uses 'AssetBundle.LoadFromFile'.\n" +
			"- Load From Memory: Uses 'AssetBundle.LoadFromMemory' after loading the bundle's data via 'File.ReadAllBytes'.", "")]
		[EditorEndCondition]
		public AssetBundleLoadType loadType = AssetBundleLoadType.LoadFromFile;

		public AssetBundleSettings()
		{

		}

		public AssetBundleSettings(bool ownPath)
		{
			this.ownPath = ownPath;
			this.path = new ApplicationPath(ApplicationPathType.StreamingAssetsPath);
		}

		public AssetBundleSettings(string assetBundleName)
		{
			this.assetBundleName = assetBundleName;
		}


		/*
		============================================================================
		Asset bundle functions
		============================================================================
		*/
		public string GetBundlePath()
		{
			if(this.ownPath)
			{
				return System.IO.Path.Combine(
					this.path.Get(),
					this.assetBundleName);
			}
			else
			{
				return System.IO.Path.Combine(
					Maki.GameSettings.assetSettings.defaultAssetBundlePath.Get(),
					this.assetBundleName);
			}
		}

		public AssetBundle LoadBundle()
		{
			return AssetSourceCache.Instance.LoadAssetBundle(this.GetBundlePath(), this.LoadType);
		}

		public AssetBundleLoadType LoadType
		{
			get
			{
				return this.ownPath ?
					this.loadType :
					Maki.GameSettings.assetSettings.defaultAssetBundleLoadType;
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string Name
		{
			get { return this.assetBundleName; }
			set { this.assetBundleName = value; }
		}

		public bool OwnPath
		{
			get { return this.ownPath; }
			set
			{
				if(this.ownPath != value)
				{
					this.ownPath = value;

					if(this.ownPath)
					{
						this.path = new ApplicationPath(ApplicationPathType.StreamingAssetsPath);
					}
					else
					{
						this.path = null;
					}
				}
			}
		}

		public ApplicationPath Path
		{
			get { return this.path; }
			set { this.path = value; }
		}
	}
}
