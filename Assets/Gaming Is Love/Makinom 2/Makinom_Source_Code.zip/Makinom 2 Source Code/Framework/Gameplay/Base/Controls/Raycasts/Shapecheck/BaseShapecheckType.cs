﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseShapecheckType : BaseTypeData
	{
		public virtual bool Is2D
		{
			get { return false; }
		}

		public abstract bool Check(IDataCall call, int layerMask);

		public abstract Collider Overlap(IDataCall call, int layerMask);

		public abstract Collider[] OverlapAll(IDataCall call, int layerMask);

		public abstract Collider2D Overlap2D(IDataCall call, int layerMask);

		public abstract Collider2D[] OverlapAll2D(IDataCall call, int layerMask);
	}

	public abstract class BaseShapecheckType<T> : BaseShapecheckType where T : IObjectSelection, new()
	{

	}
}
