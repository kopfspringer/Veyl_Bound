﻿
using UnityEngine;
using System.Collections.Generic;
using System;

namespace GamingIsLove.Makinom
{
	public abstract class AssetSource : BaseData, ICustomVisualization
	{
		public static HashSet<AssetSource> EditorChanged = new HashSet<AssetSource>();

		public abstract BaseAssetSource Source
		{
			get;
		}

		public abstract string SettingsType
		{
			get;
			set;
		}
		public abstract System.Type GetAssetType();

		public abstract bool HasAsset
		{
			get;
		}

		public abstract void ResetStoredAsset();
	}

	[EditorCombinedField("Source.asset", "type", flexibleSpace = true)]
	public class AssetSource<T> : AssetSource where T : UnityEngine.Object
	{
		[EditorHelp("Asset Source", "Select the source of the used asset:", "")]
		[EditorIndent]
		[EditorInfo(settingBaseType = typeof(BaseAssetSource), settingAutoSetup = "settings")]
		[EditorHide]
		[EditorWidth(150, true)]
		public string type = "";

		[EditorIndent]
		public BaseAssetSource<T> settings = new ReferenceAssetSource<T>();

		protected T storedAsset;

		public AssetSource()
		{
			this.type = this.settings.GetGenericTypeName();
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.storedAsset = null;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override void EditorAutoSetup(string fieldName)
		{
			if(!this.settings.IsType(this.type))
			{
				UnityEngine.Object asset = this.settings.EditorAsset;
				DataObject data = this.settings.GetData();

				System.Type tmpType = ReflectionTypeHandler.Instance.GetType(this.type, typeof(BaseAssetSource));
				if(tmpType != null)
				{
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						tmpType.MakeGenericType(typeof(T)));
					if(tmpSettings is BaseAssetSource<T>)
					{
						this.settings = (BaseAssetSource<T>)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new ReferenceAssetSource<T>();
						this.settings.SetData(data);
						this.type = this.settings.GetGenericTypeName();
					}
				}
				else
				{
					this.settings = new ReferenceAssetSource<T>();
					this.settings.SetData(data);
					this.type = this.settings.GetGenericTypeName();
				}

				if(asset != null)
				{
					this.settings.EditorAsset = asset;
				}
				if(!AssetSource.EditorChanged.Contains(this))
				{
					AssetSource.EditorChanged.Add(this);
				}
			}
		}

		public override string SettingsType
		{
			get { return this.type; }
			set
			{
				this.type = value;
				this.EditorAutoSetup("settings");
			}
		}

		public override System.Type GetAssetType()
		{
			return typeof(T);
		}

		public override string ToString()
		{
			return this.settings.ToString();
		}

		public override BaseAssetSource Source
		{
			get { return this.settings; }
		}


		/*
		============================================================================
		Asset functions
		============================================================================
		*/
		public static implicit operator T(AssetSource<T> source)
		{
			return source != null ? source.settings.Get() : null;
		}

		public override bool HasAsset
		{
			get { return this.settings.HasAsset; }
		}

		public virtual T StoredAsset
		{
			get
			{
				if(this.storedAsset == null)
				{
					this.storedAsset = this;
				}
				return this.storedAsset;
			}
		}

		public override void ResetStoredAsset()
		{
			this.storedAsset = null;
		}

		public virtual bool Is(T other)
		{
			return this.StoredAsset != null && this.StoredAsset == other;
		}

		/// <summary>
		/// Sets the used asset, changing the asset source to 'Reference'.
		/// </summary>
		/// <param name="asset">The asset that will be used.</param>
		public virtual void SetAsset(T asset)
		{
			ReferenceAssetSource<T> source = new ReferenceAssetSource<T>();
			source.asset = asset;
			this.settings = source;
		}
	}
}
