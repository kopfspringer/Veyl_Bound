﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum MenuControlInactiveInputHandling { None, SkipSelection, Hide };

	public class MenuControls : BaseData
	{
		[EditorHelp("Accept Key", "The key used to accept selections (e.g. choice dialogues).")]
		public AssetSelection<InputKeyAsset> acceptKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Cancel Key", "The key used to cancel selections or return to previous selections.")]
		public AssetSelection<InputKeyAsset> cancelKey = new AssetSelection<InputKeyAsset>();

		[EditorFoldout("Vertical Axis", "The key used to move the menu cursor vertically.")]
		[EditorEndFoldout]
		public AxisControl verticalInputAxis = new AxisControl();

		[EditorFoldout("Horizontal Axis", "The key used to move the menu cursor horizontally.")]
		[EditorEndFoldout]
		public AxisControl horizontalInputAxis = new AxisControl();


		// hold accept
		[EditorHelp("Hold Accept Key", "The key used for accepting after holding an input key for a defined time.\n" +
			"Use an input key with 'Hold' input handling.\n" +
			"Different than the 'Accept Key', this will only accept if the input key receives input for a defined time.")]
		[EditorSeparator]
		[EditorLabel("Please note that hold accept has to be enabled for individual UI boxes or inputs (content layouts), otherwise regular accept will be used.")]
		public AssetSelection<InputKeyAsset> holdAcceptKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Hold Accept Time (s)", "The time in seconds the input key (or click) has to be held to recognize it as accepting.\n" +
			"The running hold time can be displayed using HUD elements.")]
		[EditorLimit(0)]
		public float holdAcceptTime = 1;

		[EditorHelp("Use Hold Click Accept", "Clicking on inputs will also use hold accepting.\n" +
			"I.e. the click has to be held for the 'Hold Accept Time' in order to accept an input.")]
		public bool useHoldClickAccept = false;


		// page
		[EditorHelp("Next Page Key", "The key used to change to the next page.")]
		[EditorSeparator]
		public AssetSelection<InputKeyAsset> nextPageKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Previous Page Key", "The key used to change to the previous page.")]
		public AssetSelection<InputKeyAsset> previousPageKey = new AssetSelection<InputKeyAsset>();


		// scroll input
		[EditorHelp("Use Scroll Axis", "Use an input key to scroll the content of a UI box.\n" +
			"If disabled, scrolling is done with the vertical axis (if no inputs are added, e.g. choice buttons) and the mouse wheel.")]
		[EditorSeparator]
		public bool useScrollAxis = false;

		[EditorHelp("Unfocused Scrolling", "The scroll axis will also scroll a UI box when it's unfocused.")]
		[EditorCondition("useScrollAxis", true)]
		public bool scrollAxisUnfocused = false;

		[EditorHelp("Vertical Scroll Axis", "The key used to scroll vertically.")]
		[EditorAutoInit]
		public AssetSelection<InputKeyAsset> scrollVerticalAxis;

		[EditorHelp("Horizontal Scroll Axis", "The key used to scroll horizontally.")]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<InputKeyAsset> scrollHorizontalAxis;


		// scroll top/bottom input
		[EditorHelp("Scroll Top Key", "The key used to scroll to the top.")]
		[EditorSeparator]
		public AssetSelection<InputKeyAsset> scrollTopKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Scroll Bottom Key", "The key used to scroll to the bottom.")]
		public AssetSelection<InputKeyAsset> scrollBottomKey = new AssetSelection<InputKeyAsset>();


		// click accept/select
		// left
		[EditorHelp("Accept Left Click", "Clicking with the left mouse button on an input will accept it.")]
		[EditorSeparator]
		public bool acceptLeftClick = true;

		[EditorHelp("Select Left Click", "Clicking with the left mouse button on an input will select it.")]
		[EditorIndent]
		[EditorCondition("acceptLeftClick", false)]
		[EditorEndCondition]
		public bool selectLeftClick = true;

		[EditorHelp("Drag Left Click", "Clicking (hold) and dragging with the left mouse button on an input will start dragging it.")]
		[EditorIndent]
		[EditorCondition("acceptLeftClick", true)]
		[EditorCondition("selectLeftClick", true)]
		[EditorEndCondition]
		public bool dragLeftClick = true;

		// middle
		[EditorHelp("Accept Middle Click", "Clicking with the middle mouse button on an input will accept it.")]
		public bool acceptMiddleClick = false;

		[EditorHelp("Select Middle Click", "Clicking with the middle mouse button on an input will select it.")]
		[EditorIndent]
		[EditorCondition("acceptMiddleClick", false)]
		[EditorEndCondition]
		public bool selectMiddleClick = false;

		[EditorHelp("Drag Middle Click", "Clicking (hold) and dragging with the middle mouse button on an input will start dragging it.")]
		[EditorIndent]
		[EditorCondition("acceptMiddleClick", true)]
		[EditorCondition("selectMiddleClick", true)]
		[EditorEndCondition]
		public bool dragMiddleClick = false;

		// right
		[EditorHelp("Accept Right Click", "Clicking with the right mouse button on an input will accept it.")]
		public bool acceptRightClick = false;

		[EditorHelp("Select Right Click", "Clicking with the right mouse button on an input will select it.")]
		[EditorIndent]
		[EditorCondition("acceptRightClick", false)]
		[EditorEndCondition]
		public bool selectRightClick = false;

		[EditorHelp("Drag Right Click", "Clicking (hold) and dragging with the right mouse button on an input will start dragging it.")]
		[EditorIndent]
		[EditorCondition("acceptRightClick", true)]
		[EditorCondition("selectRightClick", true)]
		[EditorEndCondition]
		public bool dragRightClick = false;

		// max accepthold time
		[EditorHelp("Limit Accept Click Time", "Accepting via click uses a maximum time the click can be held.")]
		[EditorSeparator]
		public bool limitAcceptClickTime = false;

		[EditorHelp("Max Hold Time (s)", "The time in seconds the click can be held until it's not used as an accept click.")]
		[EditorLimit(0)]
		[EditorIndent]
		[EditorCondition("limitAcceptClickTime", true)]
		[EditorEndCondition]
		public float acceptClickMaxHoldTime = 1.0f;


		// input settings
		[EditorHelp("Auto Select First Input", "Automatically select the first input.\n" +
			"If disabled, no input is selected.\n" +
			"Only used if no input is already selected.")]
		[EditorFoldout("Input Settings", "Define the settings for input controls.", "")]
		public bool inputAutoSelectFirst = true;

		[EditorHelp("Loop", "The input selection will loop, e.g. " +
			"if you press up at the first input, the last input will be selected.")]
		public bool inputLoop = false;

		[EditorHelp("Select First", "The button/choice has to be selected before it can be accepted by a mouse click.\n" +
			"Use this setting if you e.g. want to show the information of a shop item by clicking on it without initiating the buy right away.")]
		public bool inputSelectFirst = false;

		[EditorHelp("Unfocused Selection", "Inputs can also be selected when the UI box is currently not focused.")]
		public bool inputUnfocusedSelection = false;

		[EditorHelp("Unfocused Highlight", "Inputs show their 'Highlighted' state (when selected) when the UI box is currently not focused.\n" +
			"Only used by 'Color Tint' inputs, requires an 'UI Input Color Changer' component on input game objects.")]
		public bool inputUnfocusedHighlight = true;

		[EditorHelp("Inactive Input Handling", "Select how inactive/disabled inputs are handled:\n" +
			"- None: Inactive inputs are displayed and can be selected.\n" +
			"- Skip Selection: Inactive inputs are displayed, input selection skips over them.\n" +
			"- Hide: Inactive inputs are not displayed.")]
		public MenuControlInactiveInputHandling inputInactiveHandling = MenuControlInactiveInputHandling.None;


		// input scroll
		[EditorHelp("Use Input Scroll", "Use input keys to scroll up/down to show the next block of inputs " +
			"(starting with the first not fully visible input).")]
		[EditorSeparator]
		public bool useInputScroll = false;

		[EditorEndFoldout]
		[EditorCondition("useInputScroll", true)]
		[EditorAutoInit]
		[EditorEndCondition]
		public AxisControl inputScroll;


		// tab settings
		[EditorHelp("Loop", "The tab selection will loop, e.g. " +
			"if you press decrease at the first tab, the last tab will be selected.")]
		[EditorFoldout("Tab Settings", "Define the settings for tab button controls.", "")]
		public bool tabLoop = false;

		[EditorHelp("Unfocused Selection", "Tabs can also be selected when the UI box is currently not focused.")]
		public bool tabUnfocusedSelection = false;

		[EditorHelp("Inactive Tab Handling", "Select how inactive/disabled tabs are handled:\n" +
			"- None: Inactive tabs are displayed and can be selected.\n" +
			"- Skip Selection: Inactive tabs are displayed, input selection skips over them.\n" +
			"- Hide: Inactive tabs are not displayed.")]
		public MenuControlInactiveInputHandling tabInactiveHandling = MenuControlInactiveInputHandling.None;

		// tab inputs
		[EditorHelp("Next Tab Key", "The key used to select the next tab.")]
		[EditorSeparator]
		public AssetSelection<InputKeyAsset> nextTabKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Previous Tab Key", "The key used to select the previous tab.")]
		[EditorEndFoldout]
		public AssetSelection<InputKeyAsset> previousTabKey = new AssetSelection<InputKeyAsset>();


		// input filter settings
		[EditorFoldout("Input Filter Settings", "Define the settings for input filter controls")]
		[EditorEndFoldout]
		public UIInputFilterControlSettings inputFilterControls = new UIInputFilterControlSettings();

		public MenuControls()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.verticalInputAxis.UpgradeOldAxis(data, "verticalAxis");
			this.horizontalInputAxis.UpgradeOldAxis(data, "horizontalAxis");

			if(!data.Contains<bool>("dragLeftClick"))
			{
				this.dragLeftClick = this.acceptLeftClick || this.selectLeftClick;
				this.dragMiddleClick = this.acceptMiddleClick || this.selectMiddleClick;
				this.dragRightClick = this.acceptRightClick || this.selectRightClick;
			}
		}

		public bool CheckClickAccept()
		{
			return (this.acceptLeftClick &&
					Input.GetMouseButtonUp(0)) ||
				(this.acceptRightClick &&
					Input.GetMouseButtonUp(1)) ||
				(this.acceptMiddleClick &&
					Input.GetMouseButtonUp(2));
		}

		public bool CheckClickSelect()
		{
			return ((this.acceptLeftClick || this.selectLeftClick) &&
					Input.GetMouseButtonUp(0)) ||
				((this.acceptRightClick || this.selectRightClick) &&
					Input.GetMouseButtonUp(1)) ||
				((this.acceptMiddleClick || this.selectMiddleClick) &&
					Input.GetMouseButtonUp(2));
		}

		public bool CheckDrag()
		{
			return (this.dragLeftClick &&
					Input.GetMouseButtonUp(0)) ||
				(this.dragRightClick &&
					Input.GetMouseButtonUp(1)) ||
				(this.dragMiddleClick &&
					Input.GetMouseButtonUp(2));
		}

		public bool CheckClickAcceptMaxHoldTime(float time)
		{
			return !this.limitAcceptClickTime ||
				time <= this.acceptClickMaxHoldTime;
		}
	}
}
