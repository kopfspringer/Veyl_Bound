
using UnityEngine;
using System.Text;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MecanimAnimation : BaseData
	{
		[EditorHelp("Layer Index", "The index of the AnimatorController layer the animation state is on.", "")]
		public int layer = 0;

		[EditorHelp("Play Mode", "Select how the state will be played:\n" +
			"- None: The state will not be played directly, only through setting parameters.\n" +
			"- Play: Uses Animator.Play to play the state directly.\n" +
			"- Cross Fade: Uses Animator.CrossFade to fade between the current and this state.", "")]
		public MecanimPlayMode playMode = MecanimPlayMode.None;

		[EditorHelp("State Name", "The name of the animation state (without layer name).", "")]
		[EditorWidth(true)]
		[EditorCondition("playMode", MecanimPlayMode.Play)]
		[EditorCondition("playMode", MecanimPlayMode.CrossFade)]
		[EditorCondition(new string[] { "durationType", "durationUseState" },
			new object[] { MecanimDurationType.AnimationClip, true })]
		[EditorEndCondition]
		public string name = "";

		[EditorHelp("Transition Duration", "The duration of the transition from the source state (current state) to this state.\n" +
			"Defined in normalized time (between 0 and 1) of the source state.", "")]
		[EditorCondition("playMode", MecanimPlayMode.CrossFade)]
		[EditorEndCondition]
		[EditorLimit(0.0f, false)]
		public float transitionDuration = 0.1f;

		[EditorSeparator]
		[EditorHelp("Set Normalized Time", "Set the normalized time of the animation state when playing it.", "")]
		[EditorCondition("playMode", MecanimPlayMode.None)]
		[EditorElseCondition]
		public bool setNormalizedTime = false;

		[EditorHelp("Normalized Time", "The normalized time the animation state will be set to when playing (0-1).\n" +
			"E.g. 1 will be the end of the animation, 0.5 in the middle of the animation.", "")]
		[EditorCondition("setNormalizedTime", true)]
		[EditorEndCondition(2)]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		public float normalizedTime = 0;


		// set layer weight
		[EditorHelp("Set Layer Weight", "Set the current weight of the animation's layer before playing the animation.", "")]
		[EditorSeparator]
		public bool setLayerWeight = false;

		[EditorHelp("Layer Weight", "The current weight the layer will be set to.", "")]
		[EditorCondition("setLayerWeight", true)]
		[EditorEndCondition]
		public float layerWeight = 1;



		// duration for wait in schematics
		[EditorHelp("Duration Type", "Select how the animation's duration will be determind:\n" +
			"- Fixed: By a defined duration time.\n" +
			"- Animation Clip: By a defined animation clip's name. " +
			"This will search for the clip in the animator's controller and use the clip's length (if found), multiplied by the animator's speed.", "")]
		[EditorSeparator]
		[EditorLabel("Mecanim doesn't report any animation durations.\n" +
			"Make sure to define a duration or the name of the animation clip for this animation to be able to use 'Wait' options when using it.")]
		public MecanimDurationType durationType = MecanimDurationType.Fixed;

		[EditorHelp("Duration (s)", "The duration of the state's animation clip.\n" +
			"This value is used in schematics to set the wait time for animation nodes.", "")]
		[EditorIndent]
		[EditorLimit(0.0f, false)]
		[EditorCondition("durationType", MecanimDurationType.Fixed)]
		public float duration = 0;

		[EditorHelp("Use Animator Speed", "Multiply the duration by the speed of the animator.", "")]
		[EditorIndent]
		[EditorEndCondition]
		public bool durationUseSpeed = false;

		[EditorHelp("Use State Name", "Use the defined 'State Name' as animation clip name.\n" +
			"If disabled, you can define the name of the animation clip that will be used.", "")]
		[EditorIndent]
		[EditorCondition("durationType", MecanimDurationType.AnimationClip)]
		public bool durationUseState = true;

		[EditorHelp("Animation Clip Name", "Set the name of the animation clip.", "")]
		[EditorWidth(true)]
		[EditorIndent]
		[EditorCondition("durationUseState", false)]
		[EditorEndCondition(2)]
		public string durationClipName = "";


		// play parameters
		[EditorArray("Add Play Parameter", "Adds a parameter that will be set when playing this animation.", "",
			"Remove", "Removes this parameter.", "",
			foldout=true, foldoutText=new string[] {
				"Play Parameter", "The parameter will be set to the defined value.", ""
		})]
		public MecanimParameter[] playParameter = new MecanimParameter[0];


		// stop parameters
		[EditorArray("Add Stop Parameter", "Adds a parameter that will be set when stopping this animation.", "",
			"Remove", "Removes this parameter.", "",
			foldout=true, foldoutText=new string[] {
				"Stop Parameter", "The parameter will be set to the defined value.", ""
		})]
		public MecanimParameter[] stopParameter = new MecanimParameter[0];

		public MecanimAnimation()
		{

		}

		public override string ToString()
		{
			if(MecanimPlayMode.None == this.playMode)
			{
				StringBuilder tmp = new StringBuilder();

				for(int i = 0; i < this.playParameter.Length; i++)
				{
					if(i > 0)
					{
						tmp.Append(", ");
					}
					tmp.Append(this.playParameter[i].ToString());
				}

				return tmp.ToString();
			}
			else
			{
				return this.playMode.ToString() + " " + this.name;
			}
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public AnimInfo Play(Animator animator)
		{
			if(this.setLayerWeight)
			{
				animator.SetLayerWeight(this.layer, this.layerWeight);
			}

			for(int i = 0; i < this.playParameter.Length; i++)
			{
				this.playParameter[i].Set(animator);
			}

			if(MecanimPlayMode.Play == this.playMode)
			{
				if(this.setNormalizedTime)
				{
					animator.Play(this.name, this.layer, this.normalizedTime);
				}
				else
				{
					animator.Play(this.name, this.layer);
				}
			}
			else if(MecanimPlayMode.CrossFade == this.playMode)
			{
				if(this.setNormalizedTime)
				{
					animator.CrossFade(this.name, this.transitionDuration, this.layer, this.normalizedTime);
				}
				else
				{
					animator.CrossFade(this.name, this.transitionDuration, this.layer);
				}
			}

			float tmpDuration = 0;
			if(MecanimDurationType.Fixed == this.durationType)
			{
				tmpDuration = this.duration;
				if(this.durationUseSpeed)
				{
					tmpDuration *= animator.speed;
				}
			}
			else if(MecanimDurationType.AnimationClip == this.durationType)
			{
				tmpDuration = AnimationHelper.GetClipLength(animator,
					this.durationUseState ? this.name : this.durationClipName);
			}

			return new AnimInfo(AnimationSystem.Mecanim,
				animator.GetLayerName(this.layer) + "." + this.name, tmpDuration);
		}

		public void Stop(Animator animator)
		{
			for(int i = 0; i < this.stopParameter.Length; i++)
			{
				this.stopParameter[i].Set(animator);
			}
		}
	}
}
