﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseInputIDKeySetting : BaseTypeData, ISaveData
	{
		public virtual bool IsInput(int inputID, BaseInputIDKeySetting input)
		{
			return false;
		}

		public virtual string GetInputInfo()
		{
			return "";
		}

		public virtual bool HasInputHandling
		{
			get { return false; }
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		/// <summary>
		/// Returns true if consisting of multiple other input keys.
		/// </summary>
		public virtual bool IsCollection
		{
			get { return false; }
		}

		/// <summary>
		/// Update per frame when the input key is blocked (e.g. by timeouts).
		/// </summary>
		/// <param name="inputKey">The input ID key this setting is part of.</param>
		/// <param name="inputKeyID">The ID of the parent input key.</param>
		public virtual void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{

		}

		/// <summary>
		/// Update per frame when the input is not blocked.
		/// </summary>
		/// <param name="inputKey">The input ID key this setting is part of.</param>
		/// <param name="inputKeyID">The ID of the parent input key.</param>
		public virtual void Tick(InputIDKey inputKey, int inputKeyID)
		{

		}

		/// <summary>
		/// Update per frame after updating all input keys (i.e. 'TickBlocked' or 'Tick' has already been called on all input keys).
		/// This is used by the 'Input Key' input origin.
		/// </summary>
		/// <param name="inputKey">The input ID key this setting is part of.</param>
		/// <param name="inputKeyID">The ID of the parent input key.</param>
		public virtual void TickCollection(InputIDKey inputKey, int inputKeyID)
		{

		}

		/// <summary>
		/// Returns the axis value of the input.
		/// By default returns the update axis that was recognized during the 'Tick' call.
		/// Only needs to be overridden when getting the axis requires special treatment.
		/// </summary>
		/// <param name="inputKey">The input ID key this setting is part of.</param>
		/// <param name="inputKeyID">The ID of the parent input key.</param>
		/// <returns>The axis value.</returns>
		public virtual float GetAxis(InputIDKey inputKey, int inputKeyID)
		{
			return inputKey.UpdateAxis;
		}

		/// <summary>
		/// Called when Makinom is reinitialized (e.g. when not using domain reload in Unity).
		/// </summary>
		public virtual void Clear()
		{

		}

		public virtual InputIDKey GetHeldKey()
		{
			return null;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public virtual DataObject SaveGame()
		{
			return this.GetData();
		}

		public virtual void LoadGame(DataObject data)
		{
			this.SetData(data);
		}

		public static BaseInputIDKeySetting Load(DataObject data)
		{
			if(data != null)
			{
				string typeInfo = "";
				data.Get(DataSerializer.TYPE, ref typeInfo);
				if(typeInfo != "")
				{
					BaseInputIDKeySetting input = ReflectionTypeHandler.Instance.CreateInstance(ReflectionTypeHandler.Instance.GetType(typeInfo)) as BaseInputIDKeySetting;
					if(input != null)
					{
						input.LoadGame(data);
						return input;
					}
				}
			}
			return null;
		}
	}
}
