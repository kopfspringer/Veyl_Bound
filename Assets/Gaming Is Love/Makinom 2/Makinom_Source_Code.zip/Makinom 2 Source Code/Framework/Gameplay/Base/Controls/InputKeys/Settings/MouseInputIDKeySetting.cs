﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Mouse", "A mouse button is used (uses mouse cursor position change as axis).\n" +
		"Please note that the axis is based on mouse cursor movement, i.e. it'll not work during locked cursor.")]
	public class MouseInputIDKeySetting : BaseInputIDKeySetting
	{
		[EditorHelp("Mouse Button", "Define which mouse button will be used, e.g.:\n" +
			"0 = left button\n" +
			"1 = right button\n" +
			"2 = middle button", "")]
		[EditorLimit(0, false)]
		public int mouseButton = 0;


		// axis
		[EditorHelp("Mouse Axis", "Select which axis of the mouse position change will be used for the input's axis.", "")]
		[EditorSeparator]
		public Axis2Type mouseAxis = Axis2Type.X;

		[EditorHelp("Axis Without Input", "The mouse axis input will be set without mouse button input, i.e. the axis is available at all times.")]
		public bool axisWithoutInput = false;

		[EditorHelp("Min Axis Range", "The minimum mouse position change (distance) that " +
			"will trigger the axis.", "")]
		[EditorLimit(0.001f, false)]
		public float mouseAxisMinRange = 1;

		[EditorHelp("Max Axis Range", "The maximum mouse position change (dinstance) that " +
			"will be used as full axis value (i.e. 1).", "")]
		[EditorLimit(1.0f, false)]
		public float mouseAxisMaxRange = 1;

		public MouseInputIDKeySetting()
		{

		}

		public override bool IsInput(int inputID, BaseInputIDKeySetting input)
		{
			MouseInputIDKeySetting tmp = input as MouseInputIDKeySetting;
			if(tmp != null)
			{
				return this.mouseButton == tmp.mouseButton;
			}
			return false;
		}

		public override string GetInputInfo()
		{
			return "Mouse" + this.mouseButton;
		}

		public override bool HasInputHandling
		{
			get { return true; }
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{
			if(inputKey.inputHoldTime > 0 ||
				inputKey.inputMaxHoldTime > 0)
			{
				if(Input.GetMouseButtonUp(this.mouseButton))
				{
					inputKey.ReleaseDownTime();
				}
				else if(Input.GetMouseButton(this.mouseButton))
				{
					inputKey.SetTriggerReleaseTimeout();
				}
			}
		}

		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			// trigger count
			if(Input.GetMouseButtonDown(this.mouseButton))
			{
				inputKey.IncreaseTriggerCount();
			}

			if(inputKey.CheckTriggerCount())
			{
				// set input down time
				if(inputKey.inputHoldTime > 0 ||
					inputKey.inputMaxHoldTime > 0)
				{
					if(Input.GetMouseButtonDown(this.mouseButton))
					{
						inputKey.SetDownTime();
						return;
					}
					else if(Input.GetMouseButtonUp(this.mouseButton))
					{
						inputKey.ReleaseDownTime();
						if(InputHandling.Hold == inputKey.handling)
						{
							return;
						}
					}
				}

				if((InputHandling.Down == inputKey.handling && Input.GetMouseButtonDown(this.mouseButton)) ||
					(InputHandling.Hold == inputKey.handling && Input.GetMouseButton(this.mouseButton)) ||
					(InputHandling.Up == inputKey.handling && Input.GetMouseButtonUp(this.mouseButton)) ||
					(InputHandling.Any == inputKey.handling &&
						(Input.GetMouseButtonDown(this.mouseButton) ||
						Input.GetMouseButton(this.mouseButton) ||
						Input.GetMouseButtonUp(this.mouseButton))))
				{
					inputKey.Timeout = Time.realtimeSinceStartup + inputKey.inputTimeout;
					inputKey.InputReceived = true;

					this.SetAxis(inputKey);
				}
				else
				{
					if(this.axisWithoutInput)
					{
						this.SetAxis(inputKey);
					}
				}
				if(Input.GetMouseButtonUp(this.mouseButton))
				{
					inputKey.ResetTriggerCount();
				}
			}
		}

		protected virtual void SetAxis(InputIDKey inputKey)
		{
			float tmpAxis = VectorHelper.GetAxis2Value(Maki.Control.MouseDelta, this.mouseAxis);
			if(Mathf.Abs(tmpAxis) >= this.mouseAxisMinRange)
			{
				tmpAxis /= this.mouseAxisMaxRange;
				inputKey.UpdateAxis = tmpAxis;
			}
			else
			{
				inputKey.UpdateAxis = 0;
			}
		}
	}
}
