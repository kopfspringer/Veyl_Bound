﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Touch", "A touch is used (uses touch position change as axis).")]
	public class TouchInputIDKeySetting : BaseInputIDKeySetting
	{
		// touch
		[EditorHelp("Touch Count", "Define the number of touches that will trigger the input, e.g.:\n" +
			"1 = one finger\n" +
			"2 = two fingers", "")]
		[EditorLimit(1, false)]
		public int touchCount = 1;

		[EditorHelp("Consume Fingers", "Consume the fingers used for the touch input.\n" +
			"The touch won't be available for other touch interactions (e.g. 'Control' type HUDs).", "")]
		public bool consumeFingers = true;


		// axis
		[EditorHelp("Touch Axis", "Select which axis of the touch position change will be used for the input's axis.", "")]
		[EditorSeparator]
		public Axis2Type touchAxis = Axis2Type.X;

		[EditorHelp("Min Axis Range", "The minimum touch position change (distance) that " +
			"will trigger the axis.", "")]
		[EditorLimit(1.0f, false)]
		public float touchAxisMinRange = 1;

		[EditorHelp("Max Axis Range", "The maximum touch position change (dinstance) that " +
			"will be used as full axis value (i.e. 1).", "")]
		[EditorLimit(1.0f, false)]
		public float touchAxisMaxRange = 1;


		// in-game
		private List<int> fingerIDs = new List<int>();

		public TouchInputIDKeySetting()
		{

		}

		public override bool IsInput(int inputID, BaseInputIDKeySetting input)
		{
			TouchInputIDKeySetting tmp = input as TouchInputIDKeySetting;
			if(tmp != null)
			{
				return this.touchCount == tmp.touchCount;
			}
			return false;
		}

		public override string GetInputInfo()
		{
			return "Touch" + this.touchCount;
		}

		public override bool HasInputHandling
		{
			get { return true; }
		}

		public override void Clear()
		{
			this.fingerIDs.Clear();
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{
			if(inputKey.inputHoldTime > 0 ||
				inputKey.inputMaxHoldTime > 0)
			{
				if(Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
				{
					inputKey.ReleaseDownTime();
				}
				else if(Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Hold))
				{
					inputKey.SetTriggerReleaseTimeout();
				}
			}
		}

		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			bool started = false;

			// trigger count
			if(Maki.Control.Touch.CanStart(this.touchCount))
			{
				inputKey.IncreaseTriggerCount();
				Maki.Control.Touch.GetStarted(this.consumeFingers, ref this.fingerIDs);
				started = true;
			}

			if(inputKey.CheckTriggerCount())
			{
				// set input down time
				if(inputKey.inputHoldTime > 0 ||
					inputKey.inputMaxHoldTime > 0)
				{
					if(started)
					{
						inputKey.SetDownTime();
						return;
					}
					else if(Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
					{
						inputKey.ReleaseDownTime();
						if(InputHandling.Hold == inputKey.handling)
						{
							return;
						}
					}
				}

				if((InputHandling.Down == inputKey.handling && started) ||
					Maki.Control.Touch.IsPhase(this.fingerIDs, inputKey.handling))
				{
					inputKey.Timeout = Time.realtimeSinceStartup + inputKey.inputTimeout;
					inputKey.InputReceived = true;

					float tmpAxis = VectorHelper.GetAxis2Value(Maki.Control.Touch.GetDelta(this.fingerIDs), this.touchAxis);
					if(Mathf.Abs(tmpAxis) >= this.touchAxisMinRange)
					{
						tmpAxis /= this.touchAxisMaxRange;
						inputKey.UpdateAxis = tmpAxis;
					}
					else
					{
						inputKey.UpdateAxis = 0;
					}
				}
				if(Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
				{
					inputKey.ResetTriggerCount();
				}
			}
		}
	}
}
