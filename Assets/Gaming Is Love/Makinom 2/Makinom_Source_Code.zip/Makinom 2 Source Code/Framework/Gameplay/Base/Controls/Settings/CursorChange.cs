﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class CursorChange : BaseData
	{
		[EditorHelp("Cursor Texture", "Select the texture that will be used as mouse cursor.", "")]
		public AssetSource<Texture2D> texture = new AssetSource<Texture2D>();

		[EditorHelp("Cursor Hotspot", "The offset from the top left corner of the texture to use as the target point.\n" +
				"Must be within the bounds of the cursor.", "")]
		[EditorCondition("texture.HasAsset", true)]
		public Vector2 hotSpot = Vector2.zero;

		[EditorHelp("Cursor Mode", "Select the mode of the cursor:\n" +
			"- Auto: Use hardware cursors on supported platforms.\n" +
			"- Force Software: Force the use of software cursors.", "")]
		[EditorEndCondition]
		public CursorMode cursorMode = CursorMode.Auto;

		public CursorChange()
		{

		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public bool SetCursor()
		{
			Texture2D cursor = this.texture;
			if(cursor != null)
			{
				Cursor.SetCursor(cursor, this.hotSpot, this.cursorMode);
				return true;
			}
			return false;
		}

		public void ResetCursor()
		{
			Texture2D cursor = this.texture;
			if(cursor != null)
			{
				Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
			}
		}
	}
}
