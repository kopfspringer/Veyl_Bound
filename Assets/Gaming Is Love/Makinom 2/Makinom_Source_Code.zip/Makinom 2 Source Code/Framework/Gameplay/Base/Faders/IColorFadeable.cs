﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.UI
{
	public interface IColorFadeable
	{
		Color Color
		{
			get;
			set;
		}

		Color TintColor
		{
			get;
			set;
		}
	}
}
