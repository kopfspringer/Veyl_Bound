﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Area 2D", "Checks if colliders fall within an area (uses 'Collider2D').")]
	public class Area2DShapecheckType<T> : BaseShapecheckType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Point A")]
		[EditorLabel("One corner of the rectangle.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> pointA = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Point B")]
		[EditorLabel("Diagonally opposite corner of the rectangle.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> pointB = new Vector3Value<T>();


		// depth
		[EditorHelp("Minimum Depth", "Only include objects with a Z coordinate (depth) greater than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Minimum Depth")]
		public FloatValue<T> minDepth = new FloatValue<T>(typeof(FloatValue_NegativeInfinityType<T>));

		[EditorHelp("Maximum Depth", "Only include objects with a Z coordinate (depth) less than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Depth")]
		public FloatValue<T> maxDepth = new FloatValue<T>(typeof(FloatValue_InfinityType<T>));

		public Area2DShapecheckType()
		{

		}

		public override string ToString()
		{
			return "Area 2D";
		}

		public override bool Is2D
		{
			get { return true; }
		}

		public override bool Check(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapArea(
				this.pointA.GetValue(call), this.pointB.GetValue(call),
				layerMask, this.minDepth.GetValue(call), this.maxDepth.GetValue(call)) != null;
		}

		public override Collider Overlap(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider[] OverlapAll(IDataCall call, int layerMask)
		{
			return null;
		}

		public override Collider2D Overlap2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapArea(
				this.pointA.GetValue(call), this.pointB.GetValue(call),
				layerMask, this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}

		public override Collider2D[] OverlapAll2D(IDataCall call, int layerMask)
		{
			return Physics2D.OverlapAreaAll(
				this.pointA.GetValue(call), this.pointB.GetValue(call),
				layerMask, this.minDepth.GetValue(call), this.maxDepth.GetValue(call));
		}
	}
}
