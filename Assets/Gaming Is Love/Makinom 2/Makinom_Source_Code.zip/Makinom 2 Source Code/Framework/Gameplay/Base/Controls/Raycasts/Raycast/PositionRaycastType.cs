﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Position", "The start position and target position are defined by values.")]
	public class PositionRaycastType<T> : BaseRaycastType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Start Position")]
		public Vector3Value<T> startPosition = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Target Position")]
		public Vector3Value<T> targetPosition = new Vector3Value<T>();

		public PositionRaycastType()
		{

		}

		public override string ToString()
		{
			return "Position";
		}

		public override RaycastOutput Raycast(IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera)
		{
			Vector3 startPos = this.startPosition.GetValue(call) + originOffset;
			Vector3 endPos = this.targetPosition.GetValue(call);
			Vector3 tmpDirection = (endPos - startPos).normalized;

			RaycastOutput hit = null;
			if(RaycastHelper.Raycast(raycastType, startPos, tmpDirection,
				out hit, Vector3.Distance(startPos, endPos), layerMask, storeCoords))
			{
				return hit;
			}
			return null;
		}

		public override List<RaycastOutput> RaycastAll(IDataCall call, RaycastType raycastType,
			int layerMask, Vector3 originOffset, bool storeCoords, Camera camera)
		{
			Vector3 startPos = this.startPosition.GetValue(call) + originOffset;
			Vector3 endPos = this.targetPosition.GetValue(call);
			Vector3 tmpDirection = (endPos - startPos).normalized;

			return RaycastHelper.RaycastAll(raycastType, startPos, tmpDirection,
				Vector3.Distance(startPos, endPos), layerMask, storeCoords);
		}
	}
}
