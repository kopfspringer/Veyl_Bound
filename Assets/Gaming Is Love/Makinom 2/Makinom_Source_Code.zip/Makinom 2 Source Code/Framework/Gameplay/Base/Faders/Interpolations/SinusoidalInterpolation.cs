﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Sinusoidal/Sinusoidal In", "Sinusoidal easing in, accelerating from zero velocity.",
		sortIndex=5)]
	public class SinusoidalInInterpolation : BaseInterpolation
	{
		public SinusoidalInInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			if(elapsedTime > duration)
			{
				elapsedTime = duration;
			}
			return -distance * Mathf.Cos(elapsedTime / duration * (Mathf.PI / 2)) + distance + start;
		}
	}

	[EditorSettingInfo("Sinusoidal/Sinusoidal Out", "Sinusoidal easing out, decelerating to zero velocity.",
		sortIndex=5)]
	public class SinusoidalOutInterpolation : BaseInterpolation
	{
		public SinusoidalOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			if(elapsedTime > duration)
			{
				elapsedTime = duration;
			}
			return distance * Mathf.Sin(elapsedTime / duration * (Mathf.PI / 2)) + start;
		}
	}

	[EditorSettingInfo("Sinusoidal/Sinusoidal In + Out", "Sinusoidal easing in/out, acceleration until halfway, then deceleration.",
		sortIndex=5)]
	public class SinusoidalInOutInterpolation : BaseInterpolation
	{
		public SinusoidalInOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			if(elapsedTime > duration)
			{
				elapsedTime = duration;
			}
			return -distance / 2 * (Mathf.Cos(Mathf.PI * elapsedTime / duration) - 1) + start;
		}
	}
}
