﻿
using UnityEngine;
using System.Collections.Generic;
using System.IO;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Persistent Data Path", "Save games are stored as files in 'Application.persistentDataPath'.")]
	public class PersistentDataPathSaveGameFileHandler : BaseSaveGameFileHandler
	{
		[EditorHelp("Save Folder", "Optionally define a folder that will be used (in the persistent data path) to store save games in.", "")]
		[EditorWidth(true)]
		public string saveFolder = "";

		public PersistentDataPathSaveGameFileHandler()
		{

		}

		private string GetPath()
		{
			if(string.IsNullOrEmpty(this.saveFolder))
			{
				return Application.persistentDataPath + "/";
			}
			else
			{
				return Application.persistentDataPath + "/" + this.saveFolder + "/";
			}
		}

		public override void SaveFile(int index, string data)
		{
			string path = this.GetPath();
			if(!Directory.Exists(path))
			{
				Directory.CreateDirectory(path);
			}
			StreamWriter writer = new StreamWriter(path + Maki.SaveGame.GetFileName(index) + ".save");
			writer.Write(Maki.SaveGameSettings.encryptData ? Maki.SecurityHandler.SaveGame(data) : data);
			writer.Flush();
			writer.Close();
		}

		public override string LoadFile(int index)
		{
			StreamReader reader = new StreamReader(
				this.GetPath() + Maki.SaveGame.GetFileName(index) + ".save");
			string data = reader.ReadToEnd();
			reader.Close();
			data = Maki.SecurityHandler.LoadGame(data);
			if(Maki.SaveGame.CompressionHandler != null)
			{
				data = Maki.SaveGame.CompressionHandler.DecompressString(data);
			}
			return data;
		}

		public override void DeleteFile(int index)
		{
			File.Delete(this.GetPath() + Maki.SaveGame.GetFileName(index) + ".save");
		}

		public override bool FileExists(int index)
		{
			return File.Exists(this.GetPath() + Maki.SaveGame.GetFileName(index) + ".save");
		}
	}
}
