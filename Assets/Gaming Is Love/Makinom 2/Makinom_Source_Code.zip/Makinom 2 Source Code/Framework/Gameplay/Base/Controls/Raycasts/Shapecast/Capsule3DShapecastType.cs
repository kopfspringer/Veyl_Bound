﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Capsule 3D", "Casts a capsule into the scene (uses 'Collider').")]
	public class Capsule3DShapecastType<T> : BaseShapecastType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Point 1")]
		[EditorLabel("The centre of the sphere at the start of the capsule.")]
		public Vector3Value<T> point1 = new Vector3Value<T>();

		[EditorSeparator]
		[EditorTitleLabel("Point 2")]
		[EditorLabel("The centre of the sphere at the end of the capsule.")]
		public Vector3Value<T> point2 = new Vector3Value<T>();

		[EditorHelp("Radius", "The radius of the capsule.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Radius")]
		public FloatValue<T> radius = new FloatValue<T>();

		public Capsule3DShapecastType()
		{

		}

		public override string ToString()
		{
			return "Capsule 3D";
		}

		public override bool CastSingle(out RaycastOutput hit, IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit tmpHit;
			if(Physics.CapsuleCast(this.point1.GetValue(call), this.point2.GetValue(call),
				this.radius.GetValue(call), direction, out tmpHit, maxDistance, layerMask))
			{
				hit = new RaycastOutput(tmpHit, storeCoords);
				return true;
			}
			else
			{
				hit = null;
				return false;
			}
		}

		public override RaycastOutput[] CastAll(IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit[] tmpHit = Physics.CapsuleCastAll(
				this.point1.GetValue(call), this.point2.GetValue(call),
				this.radius.GetValue(call), direction, maxDistance, layerMask);

			if(tmpHit != null)
			{
				RaycastOutput[] hit = new RaycastOutput[tmpHit.Length];
				for(int i = 0; i < tmpHit.Length; i++)
				{
					hit[i] = new RaycastOutput(tmpHit[i], storeCoords);
				}
				return hit;
			}
			return null;
		}
	}
}
