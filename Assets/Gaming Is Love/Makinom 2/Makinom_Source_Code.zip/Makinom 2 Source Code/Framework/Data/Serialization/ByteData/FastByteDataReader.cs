﻿
using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace GamingIsLove.Makinom.IO
{
	public class FastByteDataReader
	{
		private static System.Text.UTF8Encoding encoding = new UTF8Encoding();

		private int _position;

		private byte[] _data;

		private IntFloatConversion intFloatConverter = new IntFloatConversion();

		public FastByteDataReader(byte[] data, bool decrypt)
		{
			this._data = decrypt ? Maki.SecurityHandler.Decrypt(data) : data;
		}


		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public bool ReadBool()
		{
			return (_data[_position++] != 0);
		}

		public int ReadInt()
		{
			// little endian
			long ret = 0;
			for(int i = 0; i < 4; i++)
			{
				ret = unchecked((ret << 8) | _data[_position + 4 - 1 - i]);
			}
			_position += 4;
			int value = unchecked((int)ret);
			return value;
		}

		public float ReadFloat()
		{
			this.intFloatConverter.i = this.ReadInt();
			return this.intFloatConverter.f;
		}

		public string ReadString()
		{
			// Length of the string in bytes, not chars
			int stringLength = Read7BitEncodedInt();
			if(stringLength <= 0)
			{
				return System.String.Empty;
			}
			string text = encoding.GetString(_data, _position, stringLength);
			_position += stringLength;
			return text;
		}


		/*
		============================================================================
		List/array functions
		============================================================================
		*/
		public int[] ReadArrayInt()
		{
			int[] array = new int[this.ReadInt()];
			for(int i = 0; i < array.Length; i++)
			{
				array[i] = this.ReadInt();
			}
			return array;
		}

		public float[] ReadArrayFloat()
		{
			float[] array = new float[this.ReadInt()];
			for(int i = 0; i < array.Length; i++)
			{
				array[i] = this.ReadFloat();
			}
			return array;
		}

		public bool[] ReadArrayBool()
		{
			bool[] array = new bool[this.ReadInt()];
			for(int i = 0; i < array.Length; i++)
			{
				array[i] = this.ReadBool();
			}
			return array;
		}

		public string[] ReadArrayString()
		{
			string[] array = new string[this.ReadInt()];
			for(int i = 0; i < array.Length; i++)
			{
				array[i] = this.ReadString();
			}
			return array;
		}


		/*
		============================================================================
		Tool functions and classes
		============================================================================
		*/
		private int Read7BitEncodedInt()
		{
			// Read out an Int32 7 bits at a time.  The high bit
			// of the byte when on means to continue reading more bytes.
			int count = 0;
			int shift = 0;
			byte b;
			do
			{
				b = _data[_position++];
				count |= (b & 0x7F) << shift;
				shift += 7;
			} while((b & 0x80) != 0);
			return count;
		}

		[System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Explicit)]
		private struct IntFloatConversion
		{
			[System.Runtime.InteropServices.FieldOffset(0)]
			public float f;

			[System.Runtime.InteropServices.FieldOffset(0)]
			public int i;

			public static int Convert(float value)
			{
				return new IntFloatConversion { f = value }.i;
			}

			public static float Convert(int value)
			{
				return new IntFloatConversion { i = value }.f;
			}
		}
	}
}
