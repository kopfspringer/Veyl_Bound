﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public enum EditorCallbackType { Before, After, InstanceBefore, InstanceAfter }

	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = true)]
	public class EditorCallbackAttribute : System.Attribute
	{
		public string info = "";

		public EditorCallbackType type = EditorCallbackType.Before;

		public EditorCallbackAttribute(string info, EditorCallbackType type)
		{
			this.info = info;
			this.type = type;
		}
	}
}
