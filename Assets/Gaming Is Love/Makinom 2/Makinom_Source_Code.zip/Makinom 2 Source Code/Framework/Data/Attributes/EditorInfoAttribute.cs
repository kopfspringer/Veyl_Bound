
namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Field, AllowMultiple = false)]
	public class EditorInfoAttribute : System.Attribute
	{
		public bool isToggleLeft = false;

		public bool isToggleButton = false;

		public bool allowSceneObjects = false;

		public bool isVariableField = false;

		public bool isStandardTextArea = false;


		// popup
		public bool isLayerField = false;

		public bool isTabPopup = false;

		public int tabPopupID = 0;

		public bool isAssetSubDataPopup = false;

		public string assetSubDataField = "";

		public bool blockDataPlusButton = false;


		// auto settings
		public System.Type settingBaseType = null;

		public string settingAutoSetup = "";

		public EditorInfoAttribute()
		{

		}

		public EditorInfoAttribute(string subDataAssetField)
		{
			this.isAssetSubDataPopup = true;
			this.assetSubDataField = subDataAssetField;
		}
	}
}
