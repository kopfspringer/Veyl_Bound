
namespace GamingIsLove.Makinom
{
	/// <summary>
	/// Data serialization interface.
	/// Use this if you want to serialize a class that already has a parent class or need special treatment of data serialization.
	/// </summary>
	public interface IBaseData
	{
		/// <summary>
		/// Gets a <see cref="GamingIsLove.Makinom.DataObject"/> representing the class.
		/// </summary>
		/// <returns>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the class data.
		/// </returns>
		DataObject GetData();

		/// <summary>
		/// Sets the variables of the class using a <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		/// <param name='data'>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the data.
		/// </param>
		void SetData(DataObject data);

		/// <summary>
		/// Called for the field defined using the <c>settingAutoSetup</c> option of the <see cref="GamingIsLove.Makinom.EditorInfoAttribute"/>.
		/// </summary>
		/// <param name="fieldName">The name of the field the function is called for.</param>
		void EditorAutoSetup(string fieldName);
	}
}
