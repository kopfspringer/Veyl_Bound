﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	public abstract class BaseParameterType : BaseTypeData
	{
		public virtual bool NeedsCall
		{
			get { return false; }
		}

		public abstract System.Type GetParameterType();

		public abstract object GetParameterValue(IDataCall call);
	}

	public abstract class BaseParameterType<T> : BaseParameterType where T : IObjectSelection, new()
	{
		
	}
}
