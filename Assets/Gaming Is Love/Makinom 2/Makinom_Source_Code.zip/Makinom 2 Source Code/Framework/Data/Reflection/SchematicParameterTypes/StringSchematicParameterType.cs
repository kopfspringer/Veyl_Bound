﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("String", "A string value.")]
	public class StringSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("String Value", "Define the string value that will be used as parameter.", "")]
		public StringValue<SchematicObjectSelection> stringValue = new StringValue<SchematicObjectSelection>();

		public StringSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.stringValue.ToString();
		}

		public override bool NeedsCall
		{
			get
			{
				return this.stringValue.NeedsCall;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(string);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.stringValue.GetValue(schematic);
		}
	}
}
