﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Prefab", "A prefab.")]
	public class PrefabSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Prefab", "Select the prefab that will be used as parameter.", "")]
		[EditorInfo(isTabPopup = true, tabPopupID = 2)]
		public int prefab = 0;

		public PrefabSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.prefab.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(GameObject);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return schematic.GetPrefab(this.prefab);
		}
	}
}
