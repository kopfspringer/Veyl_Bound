﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Layer Mask", "A layer mask.")]
	public class LayerMaskParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Layer Mask", "Select the layers that will be used as parameter.", "")]
		public LayerMask layerMask = -1;

		public LayerMaskParameterType()
		{

		}

		public override string ToString()
		{
			return "Layer Mask";
		}

		public override System.Type GetParameterType()
		{
			return typeof(LayerMask);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.layerMask;
		}
	}
}
