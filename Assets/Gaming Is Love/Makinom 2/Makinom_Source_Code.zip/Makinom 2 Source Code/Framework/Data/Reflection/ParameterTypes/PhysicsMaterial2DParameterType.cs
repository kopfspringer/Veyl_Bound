﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Physics Material 2D", "A 2D physics material.")]
	public class PhysicsMaterial2DParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Physics Material 2D", "Select the 2d physics material that will be used as parameter.", "")]
		public AssetSource<PhysicsMaterial2D> physicMaterial2D = new AssetSource<PhysicsMaterial2D>();

		public PhysicsMaterial2DParameterType()
		{

		}

		public override string ToString()
		{
			return this.physicMaterial2D.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(PhysicsMaterial2D);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.physicMaterial2D.StoredAsset;
		}
	}
}
