﻿
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Audio;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Audio Mixer", "An audio mixer.")]
	public class AudioMixerParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Audio Mixer", "Select the audio mixer that will be used as parameter.", "")]
		public AssetSource<AudioMixer> audioMixer = new AssetSource<AudioMixer>();

		public AudioMixerParameterType()
		{

		}

		public override string ToString()
		{
			return this.audioMixer.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(AudioMixer);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.audioMixer.StoredAsset;
		}
	}
}
