﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Layer Mask", "A layer mask.")]
	public class LayerMaskSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Layer Mask", "Select the layers that will be used as parameter.", "")]
		public LayerMask layerMask = -1;

		public LayerMaskSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return "Layer Mask";
		}

		public override System.Type GetParameterType()
		{
			return typeof(LayerMask);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.layerMask;
		}
	}
}
