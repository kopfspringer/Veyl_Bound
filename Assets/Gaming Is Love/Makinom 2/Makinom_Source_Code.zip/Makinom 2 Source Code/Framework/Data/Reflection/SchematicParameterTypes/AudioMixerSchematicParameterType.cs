﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;
using UnityEngine.Audio;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Audio Mixer", "An audio mixer.")]
	public class AudioMixerSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Audio Mixer", "Select the audio mixer that will be used as parameter.", "")]
		public SchematicAudioMixerSelection audioMixer = new SchematicAudioMixerSelection();

		public AudioMixerSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return this.audioMixer.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(AudioMixer);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.audioMixer.GetAudioMixer(schematic);
		}
	}
}
