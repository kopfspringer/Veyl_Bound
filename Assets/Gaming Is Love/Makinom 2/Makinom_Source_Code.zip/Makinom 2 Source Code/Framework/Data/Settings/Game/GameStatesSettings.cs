
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameStatesSettings : GenericAssetListSettings<GameStateAsset, GameState>
	{
		public GameStatesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Game States"; }
		}


		/*
		============================================================================
		In-game functions
		============================================================================
		*/
		public virtual void SetInitialStates()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.SetInitialState();
				}
			}
		}

		public virtual void ResetInitialStates()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.ResetInitialState();
				}
			}
		}

		public virtual void RegisterAutoChanges()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.RegisterAutoChanges();
				}
			}
		}

		public virtual GameStateAsset FindInControlState()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					for(int j = 0; j < this.assets[i].Settings.autoActivate.Length; j++)
					{
						if(this.assets[i].Settings.autoActivate[j].settings is UnblockPlayerControlGameStateChangeType)
						{
							for(int k = 0; k < this.assets[i].Settings.autoInactivate.Length; k++)
							{
								if(this.assets[i].Settings.autoInactivate[k].settings is BlockPlayerControlGameStateChangeType)
								{
									return this.assets[i];
								}
							}
							return null;
						}
					}
				}
			}
			return null;
		}


		/*
		============================================================================
		State change notify functions
		============================================================================
		*/
		private Notify changedHandler;
		public event Notify Changed
		{
			add { this.changedHandler += value; }
			remove { this.changedHandler -= value; }
		}

		private NotifyGameState stateChangedHandler;
		public event NotifyGameState StateChanged
		{
			add { this.stateChangedHandler += value; }
			remove { this.stateChangedHandler -= value; }
		}

		public virtual void FireChanged(GameState state)
		{
			if(this.changedHandler != null)
			{
				this.changedHandler();
			}
			if(this.stateChangedHandler != null)
			{
				this.stateChangedHandler(state);
			}
		}
	}
}
