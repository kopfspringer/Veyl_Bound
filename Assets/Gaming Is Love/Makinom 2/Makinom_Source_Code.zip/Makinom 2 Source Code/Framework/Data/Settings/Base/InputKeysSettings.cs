
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class InputKeysSettings : GenericAssetListSettings<InputKeyAsset, InputKey>
	{
		public InputKeysSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Input Keys"; }
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public void Init()
		{
			if(SystemInfo.supportsGyroscope &&
				this.HasGyroscope())
			{
				Input.gyro.enabled = true;
			}
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.CheckIsCollection();
				}
			}
		}

		public void Tick()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.Tick();
				}
			}
			// collections 1st pass
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.TickCollection();
				}
			}
			// collections 2nd pass (collections using collections)
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.TickCollection2ndPass();
				}
			}
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.StoreForFixedUpdate();
				}
			}
		}

		public void FixedTick()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.FixedTick();
				}
			}
		}

		public void LateFixedTick()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.LateFixedTick();
				}
			}
		}

		public void ResetAxisHUD()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.SetAxisHUD(-1, 0);
				}
			}
		}

		public void ResetInputAxes(bool resetUnityInput)
		{
			if(resetUnityInput)
			{
				Input.ResetInputAxes();
			}
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.Reset();
				}
			}
			Maki.Control.Touch.Clear();
		}

		public void Clear()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].Settings.Clear();
				}
			}
			Maki.Control.Touch.Clear();
		}

		public bool HasGyroscope()
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					for(int j = 0; j < this.assets[i].Settings.input.Length; j++)
					{
						if(this.assets[i].Settings.input[j].settings is GyroscopeInputIDKeySetting)
						{
							return true;
						}
					}
				}
			}
			return false;
		}
	}
}
