
using UnityEngine;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom
{
	public class SaveGameSettings : BaseSettings
	{
		[EditorHelp("Save Slots", "The number of available slots to save the game.\n" +
			"Setting the save slots to 0 will only allow using AUTO save games and retry.", "")]
		[EditorFoldout("Save Game Settings", "Base save game settings, " +
			"e.g. number of available save slots, game load screen fading, etc.", "")]
		[EditorLimit(0, false)]
		public int saveSlots = 3;

		[EditorHelp("Auto Save Slots", "The number of available auto save game slots.\n" +
			"The auto save slot used in a running game can optionally be selected at the start of the game.\n" +
			"Using AUTOSAVE in the game (e.g. in save points or schematics) " +
			"will save to the auto save slot selected at the game's start.\n" +
			"If no auto save slot selection is used when starting a new game, the first auto save slot (0) will be used.", "")]
		[EditorLimit(1, false)]
		public int autoSaveSlots = 1;

		[EditorHelp("Load Scene Type", "Select how the saved scene is loaded when loading a save game:\n" +
			"- Load Level: Closes all current loaded scenes and loads a scene.\n" +
			"- Load Level Additive: Adds the scene to the current loaded scenes.\n" +
			"- Load Async: Closes all current loaded scenes and loads a " +
			"scene asynchronously in the background.\n" +
			"- Load Async Additive: Adds the scene to the current loaded scenes " +
			"and loads it asynchronously in the background.", "")]
		[EditorSeparator]
		public SceneLoadType loadType = SceneLoadType.LoadLevel;


		// save file settings
		[EditorHelp("Save File Type", "Select how save game files are stored:", "")]
		[EditorFoldout("Save File Settings", "Define where save games will be stored.", "")]
		[EditorInfo(settingAutoSetup = "saveFileSettings", settingBaseType = typeof(BaseSaveGameFileHandler))]
		public string saveFileType = typeof(PersistentDataPathSaveGameFileHandler).ToString();

		public BaseSaveGameFileHandler saveFileSettings = new PersistentDataPathSaveGameFileHandler();

		[EditorHelp("Encrypt Data", "The save game data will be encrypted.\n" +
			"If not selected, the data is saved in plain text.", "")]
		[EditorEndFoldout]
		public bool encryptData = false;


		// game settings
		[EditorHelp("Language", "The language will also be stored in the PlayerPrefs (outside of save games).", "")]
		[EditorFoldout("PlayerPrefs Game Options", "Optionally store game options in PlayerPrefs outside of save games.\n" +
			"The options will be loaded when the game/application is started again.", "")]
		public bool storeOptionLanguage = false;

		[EditorHelp("Global Volume", "The global volume will also be stored in the PlayerPrefs (outside of save games).", "")]
		public bool storeOptionGlobalVolume = false;

		[EditorHelp("Sound Volume", "The sound volume will also be stored in the PlayerPrefs (outside of save games).", "")]
		public bool storeOptionSoundVolume = false;

		[EditorHelp("Music Volume", "The music volume will also be stored in the PlayerPrefs (outside of save games).", "")]
		public bool storeOptionMusicVolume = false;

		[EditorHelp("Save Confirmation", "The save confirmation option will also be stored in the PlayerPrefs (outside of save games).", "")]
		public bool storeSaveConfirmation = false;

		[EditorHelp("Text Speed", "The 'Text Speed' option will also be stored in the PlayerPrefs (outside of save games).", "")]
		[EditorEndFoldout]
		[EditorCallback("extension:playerprefsgameoptions", EditorCallbackType.After)]
		public bool storeOptionTextSpeed = false;


		// screen fades
		[EditorHelp("Own Screen Fade", "Use different screen fade settings when loading a save game.\n" +
			"If disabled, it'll use the default screen fade settings defined in the game settings.")]
		[EditorFoldout("Screen Fade Settings", "Optionally use a different screen fading when loading a save game.", "")]
		public bool ownScreenFade = false;

		[EditorEndFoldout(2)]
		[EditorCondition("ownScreenFade", true)]
		[EditorAutoInit]
		[EditorEndCondition]
		public ScreenFadeSettings screenFade;


		// save data settings
		[EditorHelp("Game Time", "The current game time will be saved.", "")]
		[EditorFoldout("Save Data Settings", "Select the data of a running game that will be saved in a save game.", "")]
		[EditorTitleLabel("Game Data")]
		public bool saveTime = true;

		[EditorHelp("Volumes", "The global, music and sound volumes will be saved in a save game.", "")]
		public bool saveVolumes = true;

		[EditorHelp("Player Position", "The player position (scene, position and rotation) will be saved.", "")]
		public bool savePlayerPosition = true;

		[EditorHelp("Music", "Save the currently playing music and playing time.", "")]
		[EditorCondition("savePlayerPosition", true)]
		public bool saveMusic = true;

		[EditorHelp("Load Scene", "The scene that will be loaded when loading a game without player position.", "")]
		[EditorElseCondition]
		public string saveSceneName = "";

		[EditorHelp("Spawn ID", "The spawn point ID where the player will spawn.", "")]
		[EditorEndCondition]
		public int saveSpawnID = 0;

		[EditorHelp("Block States", "The state of blocked Input Keys and HUDs will be saved.", "")]
		public bool saveBlockStates = true;

		[EditorHelp("Input ID", "The global input ID will be saved.\n" +
			"The input ID (used by 'Input ID' input keys) can be " +
			"changed in-game to create different control styles.", "")]
		public bool saveInputID = true;

		[EditorHelp("Scene Positions", "Save the stored scene positions of all scenes.", "")]
		public bool saveScenePosition = true;

		// scene data
		[EditorHelp("Object Variables", "Select how variables bound to objects will be saved:\n" +
			"- None: The variables won't be saved, i.e. they wont be used at all.\n" +
			"- Game: The variables will be remebered in a running game.\n" +
			"- Save: The variables will be saved in a save game.", "")]
		[EditorSeparator]
		public SaveOption objectVariableOption = SaveOption.Save;

		[EditorHelp("Terrain Changes", "Select how changes to terrains will be saved:\n" +
			"- None: The terrain changes won't be saved, i.e. they wont be used at all.\n" +
			"- Game: The terrain changes will be remebered in a running game.\n" +
			"- Save: The terrain changes will be saved in a save game.\n" +
			"Warning: Saving terrain changes will dramatically increase your save game data.", "")]
		public SaveOption terrainChangesOption = SaveOption.None;

		// game object savers
		[EditorHelp("Game Object Savers", "Select if data from 'Game Object Saver' components will be saved:\n" +
			"- None: Data isn't saved.\n" +
			"- Current: Only data of the current scene is saved.\n" +
			"- All: All stored data will be saved (this can massively increase the save file).", "")]
		[EditorSeparator]
		public SceneSaveOption saveGameObjectSavers = SceneSaveOption.None;

		[EditorHelp("Auto Remove", "Auto remove data from 'Game Object Saver' components after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[EditorIndent]
		public bool gameObjectSaversAutoRemove = false;

		[EditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[EditorIndent]
		[EditorLimit(0, false)]
		[EditorCondition("gameObjectSaversAutoRemove", true)]
		[EditorEndCondition]
		public int gameObjectSaversAutoRemoveAfter = 3;

		// prefab savers
		[EditorHelp("Prefab Savers", "Select if data from prefab savers will be saved (see 'Base/Control > Prefab Savers' for details):\n" +
			"- None: Data isn't saved.\n" +
			"- Current: Only data of the current scene is saved.\n" +
			"- All: All stored data will be saved (this can massively increase the save file).", "")]
		[EditorSeparator]
		public SceneSaveOption savePrefabSavers = SceneSaveOption.None;

		[EditorHelp("Auto Remove", "Auto remove data from prefab after a defined number of scene changes " +
			"without coming back to the scene.\n" +
			"When returning to the scene, the counter will be reset (if the data wasn't removed already).", "")]
		[EditorIndent]
		public bool prefabSaversAutoRemove = false;

		[EditorHelp("After Scene Changes", "The number of scene changes before resetting the data.\n" +
			"E.g. setting it to 1 will allow leaving the scene and returning to it (keeping the data), " +
			"but making another scene change to a different scene will remove the data.", "")]
		[EditorIndent]
		[EditorLimit(0, false)]
		[EditorCondition("prefabSaversAutoRemove", true)]
		[EditorEndCondition]
		public int prefabSaversAutoRemoveAfter = 3;

		// no auto remove scenes
		[EditorHelp("Scene Name", "Define the name of the scene where auto removal of scene data isn't used.", "")]
		[EditorWidth(400, true)]
		[EditorArray("Add No Auto Remove Scene", "Adds a scene where auto removal of scene data isn't used.", "",
			"Remove", "Removes the scene.", "", isHorizontal = true)]
		public string[] noAutoRemoveScene = new string[0];

		// variables
		[EditorHelp("Variables", "Select which variables will be saved:\n" +
			"- None: No variable will be saved.\n" +
			"- Select: Select which variables will be saved.\n" +
			"- All: All variables will be saved, but you can exclude specific variables.", "")]
		[EditorTitleLabel("Variable Data")]
		[EditorSeparator]
		[EditorCallback("check:variables", EditorCallbackType.After)]
		public Selector variableSelector = Selector.All;

		[EditorHelp("Variable Key", "The key (name) of the variable.", "")]
		[EditorEndFoldout]
		[EditorInfo(isVariableField = true)]
		[EditorWidth(400, true)]
		[EditorArray("Add Variable", "Adds a variable to the list.", "",
			"Remove", "Removes the variable.", "", isHorizontal = true)]
		[EditorCondition("variableSelector", Selector.None)]
		[EditorElseCondition]
		[EditorEndCondition]
		[EditorCallback("extension:savegamedata", EditorCallbackType.After)]
		public string[] variableList = new string[0];



		// file settings
		// save file name
		[EditorHelp("Save File Name", "This text is used to display the index text of the save file.", "")]
		[EditorFoldout("File Settings", "Set the content of the file buttons.", "",
			"Save File Name", "This text is used to display the index text of the save file.", "")]
		[EditorEndFoldout]
		[EditorLabel("<filenumber> = file number")]
		[EditorLanguageExport("SaveFileName")]
		public LanguageData<TextContent> saveFileName = new LanguageData<TextContent>(new TextContent("File <filenumber>"));


		// file button
		[EditorHelp("Save Time Format", "The format used to display the save time (i.e. real time).\n" +
			"E.g.: 'yyyy-MM-dd HH:mm:ss' = 2025-01-30 17:52:02")]
		[EditorFoldout("File Info", "Text displayed for saved save game files.", "")]
		public string saveTimeFormat = "yyyy-MM-dd HH:mm:ss";

		[EditorEndFoldout]
		[EditorLabel("<filename> = save/auto file name, <savenumber> = save number\n" +
			"<time> = game time, <savetime> = save time (real time using save time format)")]
		[EditorCallback("extension:fileinfo", EditorCallbackType.Before)]
		[EditorLanguageExport("SaveFileInfo")]
		public ContentInputCustom fileButtonContent = new ContentInputCustom("<filename>");


		// empty button
		[EditorFoldout("Empty File Info", "Text displayed for empty save game slots/files.", "")]
		[EditorEndFoldout]
		[EditorLabel("<filenumber> = file number")]
		[EditorLanguageExport("EmptyFileInfo")]
		public ContentInputCustom emptyFileButtonContent = new ContentInputCustom("File <filenumber>");


		// delete file
		[EditorFoldout("Delete File Settings", "Optionally use an input key to delete " +
			"the currently selected save file in 'Save Game Menu' and 'Load Game Menu' dialogues.", "")]
		[EditorEndFoldout(2)]
		public DeleteSaveFileSetting deleteFile = new DeleteSaveFileSetting();



		// auto save
		// auto file name
		[EditorHelp("Auto File Name", "This text is used to display the index text of the auto save file.", "")]
		[EditorFoldout("Auto Save Settings", "The game can be automatically saved by using the 'Auto Save' schematic node.", "",
			"Auto File Name", "This text is used to display the index text of the auto save file.", "")]
		[EditorEndFoldout]
		[EditorLabel("<filenumber> = auto save slot")]
		[EditorLanguageExport("AutoFileName")]
		public LanguageData<TextContent> autoFileName = new LanguageData<TextContent>(new TextContent("AUTO <filenumber>"));

		//auto save message
		[EditorHelp("Show Message", "A message will be displayed when auto saving the game.", "")]
		[EditorFoldout("Auto Save Message", "A message can be displayed when auto saving the game.", "")]
		public bool showAutoSaveMessage = false;

		[EditorHelp("UI Box", "Select the UI box used to display the message.", "")]
		[EditorCondition("showAutoSaveMessage", true)]
		[EditorAutoInit]
		public UIBoxSelection autoBoxSettings;

		[EditorHelp("Visibility Time (s)", "The time in seconds the message will be displayed.", "")]
		[EditorLimit(0.0f, false)]
		public float autoVisibilityTime = 3;

		[EditorHelp("Message", "The message that will be displayed when the using auto save.", "")]
		[EditorFoldout("Auto Save Message", "The message that will be displayed when using auto save.", "")]
		[EditorEndFoldout(3)]
		[EditorEndCondition]
		[EditorLanguageExport("AutosaveMessage")]
		public Content autoSaveMessage = new Content("Autosave");



		// UI background
		[EditorFoldout("UI Backgrounds", "The save point, save and load menu can show UI backgrounds along the used UI boxes.\n" +
			"You can select the default UI backgrounds for all save menus here.\n" +
			"Each save menu can override the default UI backgrounds.\n" +
			"General UI backgrounds are displayed in all save menus and can't be overridden. " +
			"They're added before the default/individual UI backgrounds (displaying them behind them when added on the same UI layer).", "")]
		[EditorArray("Add Default UI Background", "Adds a default UI background.", "",
			"Remove", "Removes this default UI background.", "",
			foldout = true, foldoutText = new string[] {
				"Default UI Background", "Default UI background can be overridden by the save point, save and load menus.", ""
			})]
		public UIBackgroundSettings[] defaultBackground = new UIBackgroundSettings[0];

		[EditorEndFoldout]
		[EditorArray("Add General UI Background", "Adds a general UI background.\n" +
			"General UI backgrounds are displayed in all save menus and can't be overridden. " +
			"They're added before the default/individual UI backgrounds (displaying them behind them when added on the same UI layer).", "",
			"Remove", "Removes this general UI background.", "",
			foldout = true, foldoutText = new string[] {
				"General UI Background", "This background can't be overridden and will be added before the default/individual UI backgrounds " +
				"(displaying them behind them when added on the same UI layer).", ""
			})]
		public UIBackgroundSettings[] generalBackground = new UIBackgroundSettings[0];


		// pause
		[EditorHelp("Pause Game", "The game will be paused while save menus are opened.", "")]
		[EditorFoldout("Pause Settings", "Optionally pause the game while displaying save menus.", "")]
		public bool pauseGame = false;

		[EditorHelp("Pause Time", "The game time (play time) will pause when the game is paused.", "")]
		[EditorCondition("pauseGame", true)]
		public bool pauseTime = false;

		[EditorHelp("Freeze Pause", "The game freezes in pause, i.e. animations, movements, etc. will stop.", "")]
		public bool freezePause = false;

		[EditorHelp("Change Time Scale", "Change the time scale while displaying save menus.\n" +
			"This can be used to slow down or speed up the game.", "")]
		[EditorElseCondition]
		public bool setTimeScale = false;

		[EditorHelp("Set Makinom Scale", "Set the Makinom time scale - " +
			"it's used only for Makinom related things, e.g. schematics.\n" +
			"If disabled, the Unity time scale will be set, affecting everything in the game.", "")]
		[EditorIndent]
		[EditorCondition("setTimeScale", true)]
		public bool setMakinomScale = false;

		[EditorHelp("Time Scale", "Define the time scale that will be used while displaying the menu screen.\n" +
			"A time scale of 1 is normal speed, 0.5 is half speed, 2 is double speed.\n" +
			"A time scale of 0 will freeze time (same as using freeze pause).", "")]
		[EditorEndFoldout]
		[EditorIndent]
		[EditorEndCondition(2)]
		[EditorLimit(0.0f, false)]
		public float timeScale = 1;



		// save game menu
		[EditorFoldout("Save Game Menu", "Settings for the save file selection menu.", "")]
		[EditorEndFoldout]
		public SaveGameControl saveMenu = new SaveGameControl();



		// load game menu
		[EditorFoldout("Load Game Menu", "Settings for the load file selection menu.", "")]
		[EditorEndFoldout]
		public LoadGameControl loadMenu = new LoadGameControl();



		// save point
		[EditorHelp("Show Choice", "A choice dialogue (save, load, cancel) is displayed when the player " +
			"interacts with a save point.\n" +
			"If not set, the save menu is shown.", "")]
		[EditorFoldout("Save Point Settings", "This settings determine the options " +
			"and appearance of the save point dialogue.", "")]
		public bool showSPChoice = true;

		[EditorEndFoldout]
		[EditorCondition("showSPChoice", true)]
		[EditorEndCondition]
		public SavePointControl savePoint = new SavePointControl();

		public SaveGameSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("saveFileSettings" == fieldName &&
				!this.saveFileSettings.IsType(this.saveFileType))
			{
				DataObject data = this.saveFileSettings.GetData();
				object instance = ReflectionTypeHandler.Instance.CreateInstance(
					this.saveFileType, typeof(BaseSaveGameFileHandler));

				if(instance is BaseSaveGameFileHandler)
				{
					this.saveFileSettings = (BaseSaveGameFileHandler)instance;
					this.saveFileSettings.SetData(data);
				}
				else
				{
					this.saveFileSettings = new PersistentDataPathSaveGameFileHandler();
					this.saveFileSettings.SetData(data);
					this.saveFileType = this.saveFileSettings.GetType().ToString();
				}
			}
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(this.showAutoSaveMessage &&
				data.Contains<DataObject>("autoBox"))
			{
				this.autoBoxSettings = new UIBoxSelection();
				this.autoBoxSettings.Upgrade(data, "autoBox");
			}
			if(data.Contains<DataObject>("fileContent"))
			{
				this.fileButtonContent.UpgradeFromTDIC(data.GetFile("fileContent"));
				this.emptyFileButtonContent.UpgradeFromTDIC(data.GetFile("emptyFileContent"));
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Save Game Menu"; }
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public UIButtonInputContent GetFileInfo()
		{
			return this.fileButtonContent.GetContent<UIButtonInputContent>();
		}

		public UIButtonInputContent GetEmptyInfo()
		{
			return this.emptyFileButtonContent.GetContent<UIButtonInputContent>();
		}

		public string GetSaveName(int index)
		{
			string name = this.saveFileName.Current;
			name = name.Replace("<filenumber>", (index + 1).ToString());
			return name;
		}


		/*
		============================================================================
		Auto save functions
		============================================================================
		*/
		public void ShowAutoSaveMessage()
		{
			if(this.showAutoSaveMessage && this.autoBoxSettings != null)
			{
				Maki.UI.CreateInfoBox("", this.autoSaveMessage.GetContent(),
					this.autoBoxSettings, this.autoVisibilityTime, null, Vector2.zero, true);
			}
		}

		public string GetAutoName(int index)
		{
			string name = this.autoFileName.Current;
			name = name.Replace("<filenumber>", (index + 1).ToString());
			return name;
		}


		/*
		============================================================================
		Save data functions
		============================================================================
		*/
		public bool CanSaveVariable(string key)
		{
			bool save = Selector.All == this.variableSelector;
			for(int i = 0; i < this.variableList.Length; i++)
			{
				if(this.variableList[i] == key)
				{
					save = !save;
					break;
				}
			}
			return save;
		}

		public void SaveMenuPause(bool pause)
		{
			if(pause)
			{
				if(this.pauseGame)
				{
					Maki.Game.PauseGame(true, this.pauseTime, this.freezePause);
				}
				else if(this.setTimeScale)
				{
					if(this.setMakinomScale)
					{
						Maki.Game.TimeScale = this.timeScale;
					}
					else
					{
						Maki.Game.UnityTimeScale = this.timeScale;
					}
				}
			}
			else
			{
				if(this.pauseGame)
				{
					Maki.Game.PauseGame(false, this.pauseTime, this.freezePause);
				}
				else if(this.setTimeScale)
				{
					if(this.setMakinomScale)
					{
						Maki.Game.ResetTimeScale();
					}
					else
					{
						Maki.Game.ResetUnityTimeScale();
					}
				}
			}
		}


		/*
		============================================================================
		Save data functions
		============================================================================
		*/
		public virtual bool BlockAutoRemoveSceneData(string sceneName)
		{
			for(int i = 0; i < this.noAutoRemoveScene.Length; i++)
			{
				if(this.noAutoRemoveScene[i] == sceneName)
				{
					return true;
				}
			}
			return false;
		}
	}
}

