﻿
using UnityEngine;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom
{
	public class UISystemSettings : BaseSettings
	{
		[EditorHelp("UI System Type", "Select which UI system will be used:", "")]
		[EditorFoldout("UI System Settings", "Select which UI system will be used.", "")]
		[EditorInfo(settingAutoSetup="settings", settingBaseType=typeof(BaseUISystem))]
		[EditorCallback("toggle:uisystemdialog", EditorCallbackType.Before)]
		public string type = typeof(NoneUISystem).ToString();

		// default screen size
		[EditorSeparator]
		[EditorHelp("Default Screen Size", "The width and height of the screen size you are designing for.\n" +
			"This setting is used to calculate the UI matrix that is used to determine cursor positions and screen offsets.", "")]
		public Vector2 defaultScreen = new Vector2(1920.0f, 1080.0f);

		// default mask material
		[EditorHelp("Default Mask Material", "Select the default material that will be used for texture alpha masks.\n" +
			"The default mask material can be overridden by each image that can use alpha masks.", "")]
		[EditorSeparator]
		[EditorEndFoldout]
		public AssetSource<Material> defaultMaskMaterial = new AssetSource<Material>();


		// system settings
		public BaseUISystem settings = new NoneUISystem();

		public UISystemSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void EditorAutoSetup(string fieldName)
		{
			if(fieldName == "settings" &&
				!this.settings.IsType(this.type))
			{
				DataObject data = this.settings.GetData();
				object instance = ReflectionTypeHandler.Instance.CreateInstance(
					this.type, typeof(BaseUISystem));

				if(instance is BaseUISystem)
				{
					this.settings = (BaseUISystem)instance;
					this.settings.SetData(data);
				}
				else
				{
					this.settings = new NoneUISystem();
					this.settings.SetData(data);
					this.type = this.settings.GetType().ToString();
				}
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "UI System Settings"; }
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public Vector3 GetScreenCenter()
		{
			return new Vector3(this.defaultScreen.x / 2, this.defaultScreen.y / 2, 0);
		}
	}
}
