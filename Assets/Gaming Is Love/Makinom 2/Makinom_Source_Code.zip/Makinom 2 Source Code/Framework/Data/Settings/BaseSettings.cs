
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class BaseSettings : IBaseData
	{
		/// <summary>
		/// Loads the settings found in the Project asset.
		/// </summary>
		/// <param name='project'>
		/// The Project asset.
		/// </param>
		public virtual void LoadProject(MakinomProjectAsset project)
		{
			this.SetData(project.GetData(this.Filename).ToDataObject());
		}

		/// <summary>
		/// Initializes the settings of directly referenced data assets.
		/// </summary>
		public virtual void InitDataAssetSettings()
		{

		}

		/// <summary>
		/// Gets the save data.
		/// </summary>
		/// <param name='list'>
		/// The list of save data the data will be added to.
		/// </param>
		/// <param name='encrypt'>
		/// If true, the data will be encrypted.
		/// </param>
		public virtual DataFile GetSaveData(bool encrypt, DataFile.SaveFormatType format)
		{
			return this.GetData().GetDataFile(this.Filename, encrypt, format);
		}

		public virtual bool HasChanged(MakinomProjectAsset project, bool encrypt, DataFile.SaveFormatType format, out DataFile file)
		{
			file = this.GetSaveData(encrypt, format);
			return project == null ||
				!project.Contains(this.Filename) ||
				!project.GetData(this.Filename).CompareTo(file);
		}

		/// <summary>
		/// Gets a <see cref="GamingIsLove.Makinom.DataObject"/> representing the class.
		/// </summary>
		/// <returns>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the class data.
		/// </returns>
		public virtual DataObject GetData()
		{
			return DataSerializer.GetDataObject(this);
		}

		/// <summary>
		/// Sets the variables of the class using a <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		/// <param name='data'>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the data.
		/// </param>
		public virtual void SetData(DataObject data)
		{
			DataSerializer.SetDataObject(data, this);
		}

		/// <summary>
		/// Called for the field defined using the <c>settingAutoSetup</c> option of the <see cref="GamingIsLove.Makinom.EditorInfoAttribute"/>.
		/// </summary>
		/// <param name="fieldName">The name of the field the function is called for.</param>
		public virtual void EditorAutoSetup(string fieldName)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		/// <summary>
		/// Gets the filename used for saving the settings.
		/// </summary>
		/// <value>
		/// The filename.
		/// </value>
		public abstract string Filename
		{
			get;
		}

		public virtual System.Type InstanceType
		{
			get { return null; }
		}

		public virtual int Count
		{
			get { return 0; }
		}

		public virtual bool HasGeneralSettings
		{
			get { return false; }
		}
	}
}
