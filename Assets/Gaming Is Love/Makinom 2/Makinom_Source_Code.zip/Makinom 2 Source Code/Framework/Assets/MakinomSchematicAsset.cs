﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MakinomSchematicAsset : ScriptableObject
	{
		[HideInInspector]
		[SerializeField]
		protected string time = "";

		[HideInInspector]
		[SerializeField]
		protected string version = "";

		[HideInInspector]
		[SerializeField]
		protected DataFile data;


		// loaded data
		[HideInInspector]
		[System.NonSerialized]
		protected SchematicSettings settings;


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public SchematicSettings Settings
		{
			get
			{
				if(this.settings == null)
				{
					this.LoadData();
				}
				return this.settings;
			}
		}

		public string Version
		{
			get { return this.version; }
			set { this.version = value; }
		}

		public string SaveTime
		{
			get { return this.time; }
			set { this.time = value; }
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		protected virtual void OnEnable()
		{
			if(this.data != null)
			{
				this.data.ClearDataObject();
				this.settings = null;
			}
		}

		public void SetData(DataObject data)
		{
			this.settings = new SchematicSettings();
			this.settings.SetData(data);
		}

		public void LoadData()
		{
			this.settings = new SchematicSettings();

			if(this.data != null)
			{
				this.settings.SetData(this.data.ToDataObject());
			}
		}

		public void SaveData(bool encrypt, DataFile.SaveFormatType format)
		{
			if(this.settings != null)
			{
				this.data = this.settings.GetData().GetDataFile("settings", encrypt, format);
			}
			else
			{
				this.data = null;
			}
		}

		public bool HasChanged(bool encrypt, DataFile.SaveFormatType format)
		{
			return this.data == null ||
				!this.data.CompareTo(this.settings.GetData().GetDataFile("settings", encrypt, format));
		}
	}
}
