﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Sound Channel")]
	public class SoundChannelComponent : SerializedBehaviour<SoundChannelComponent.Settings>
	{
		protected bool isRegistered = false;

		protected virtual void Reset()
		{
			this.settings.audioSource = this.GetComponent<AudioSource>();
		}

		protected virtual void OnEnable()
		{
			this.Register();
		}

		protected virtual void Start()
		{
			this.Register();
		}

		protected virtual void Register()
		{
			if(!this.isRegistered &&
				Maki.Initialized &&
				this.settings.audioSource != null)
			{
				this.isRegistered = true;
				Maki.Audio.GetSoundChannel(this.settings.channel).Register(this.settings.audioSource);
			}
		}

		protected virtual void OnDisable()
		{
			if(this.isRegistered &&
				Maki.Initialized &&
				Maki.Audio != null)
			{
				this.isRegistered = false;
				Maki.Audio.GetSoundChannel(this.settings.channel).Unregister(this.settings.audioSource);
			}
		}

		public virtual bool PlayOneShot(AudioClip clip, float volume)
		{
			if(clip != null)
			{
				if(this.settings.audioSource != null)
				{
					this.settings.audioSource.PlayOneShot(clip,
						volume * Maki.Audio.GetSoundChannel(this.settings.channel).Volume * Maki.Audio.SoundVolume);
				}
				else
				{
					Maki.Audio.GetSoundChannel(this.settings.channel).PlayOneShot(clip, volume);
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/SoundChannelComponent Icon.png");
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Sound Channel", "Define the sound channel that will used.\n" +
				"The default channel is 0.")]
			[EditorLimit(0, false)]
			[EditorLabel("The audio source will use the sound channel's audio mixer group and it's volume will be driven by the channel's volume.")]
			public int channel = 0;

			[EditorHelp("Audio Source", "Select the 'Audio Source' component that will be used.")]
			[EditorInfo(allowSceneObjects=true)]
			public AudioSource audioSource;

			public Settings()
			{

			}
		}
	}
}
