
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[System.Serializable]
	public class PathPoint
	{
		public Vector3 position = Vector3.zero;

		public Vector3 outTangent = Vector3.zero;

		public Vector3 inTangent = Vector3.zero;

		public float approximation = 0.05f;


		// own rotation settings
		public bool ownRotation = false;

		public PathRotationSettings rotationSettings;

		public Transform lookAtObject;

		public Vector3 rotation = Vector3.zero;

		public float smoothRotation = 0;


		// in-game
		private float length;

		private List<PathPointPosition> pathPosition;

		public PathPoint()
		{

		}

		public PathPoint(Vector3 position)
		{
			this.position = position;
		}


		/*
		============================================================================
		Position functions
		============================================================================
		*/
		public Vector3 GetPosition(float time, PathPoint end)
		{
			if(time <= 0)
			{
				return this.position;
			}
			else if(time >= 1)
			{
				return end.position;
			}
			else
			{
				float time2 = time * time;
				float time3 = time2 * time;

				float u = 1.0f - time;
				float u2 = u * u;
				float u3 = u2 * u;

				Vector3 point = u3 * this.position;
				point += 3 * u2 * time * (this.position + this.outTangent);
				point += 3 * u * time2 * (end.position + end.inTangent);
				point += time3 * end.position;

				return point;
			}
		}

		public bool FindNearestPosition(Vector3 userPosition, ref float pathValue,
			ref Vector3 nearestPosition, ref float shortestDistance)
		{
			bool found = false;

			// start position
			float tmpDistance = Vector3.Distance(userPosition, this.position);
			if(tmpDistance < shortestDistance)
			{
				shortestDistance = tmpDistance;
				pathValue = 0;
				nearestPosition = this.position;
				found = true;
			}

			// path positions
			if(this.pathPosition != null)
			{
				for(int i = 0; i < this.pathPosition.Count; i++)
				{
					tmpDistance = Vector3.Distance(userPosition, this.pathPosition[i].position);
					if(tmpDistance < shortestDistance)
					{
						shortestDistance = tmpDistance;
						pathValue = this.pathPosition[i].time;
						nearestPosition = this.pathPosition[i].position;
						found = true;
					}
				}
			}

			return found;
		}


		/*
		============================================================================
		Length functions
		============================================================================
		*/
		public float Length
		{
			get { return this.length; }
		}

		public void UpdateLength(PathPoint end)
		{
			this.length = 0;
			Vector3 last = this.position;
			Vector3 tmp = Vector3.zero;
			this.pathPosition = new List<PathPointPosition>();

			for(float time = 0; time < 1; time += this.approximation)
			{
				tmp = this.GetPosition(time, end);
				this.length += Vector3.Distance(last, tmp);
				last = tmp;

				// update time positions list for getting nearest path point
				if(!this.ContainsTime(time))
				{
					this.pathPosition.Add(new PathPointPosition(time, tmp));
				}
			}

			tmp = this.GetPosition(1, end);
			this.length += Vector3.Distance(last, tmp);
		}

		private bool ContainsTime(float time)
		{
			for(int i = 0; i < this.pathPosition.Count; i++)
			{
				if(Mathf.Approximately(this.pathPosition[i].time, time))
				{
					return true;
				}
			}
			return false;
		}

		private struct PathPointPosition
		{
			public float time;

			public Vector3 position;

			public PathPointPosition(float time, Vector3 position)
			{
				this.time = time;
				this.position = position;
			}
		}
	}
}
