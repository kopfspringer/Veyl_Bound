
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Store Terrain Changes")]
	public class StoreTerrainChanges : MonoBehaviour
	{
		public string objectID = "";

		protected virtual void Start()
		{
			Terrain terrain = this.GetComponent<Terrain>();
			if(terrain != null)
			{
				TerrainDataChanges changes = Maki.Game.Scene.GetTerrainChanges(this.objectID);
				if(changes != null)
				{
					if(changes.HeightMap != null)
					{
						StoreTerrainChanges.TerrainHeightMapChange(terrain.terrainData);
						terrain.terrainData.SetHeights(0, 0, changes.HeightMap);
					}
					if(changes.AlphaMap != null)
					{
						StoreTerrainChanges.TerrainAlphaMapChange(terrain.terrainData);
						terrain.terrainData.SetAlphamaps(0, 0, changes.AlphaMap);
					}
				}
			}
		}

		public virtual void StoreTerrainHeightMap(TerrainData terrainData)
		{
			TerrainDataChanges changes = Maki.Game.Scene.GetTerrainChanges(this.objectID);
			if(changes != null)
			{
				changes.HeightMap = terrainData.GetHeights(0, 0,
					terrainData.heightmapResolution, terrainData.heightmapResolution);
			}
		}

		public virtual void StoreTerrainAlphaMap(TerrainData terrainData)
		{
			TerrainDataChanges changes = Maki.Game.Scene.GetTerrainChanges(this.objectID);
			if(changes != null)
			{
				changes.AlphaMap = terrainData.GetAlphamaps(0, 0,
					terrainData.alphamapWidth, terrainData.alphamapHeight);
			}
		}


		/*
		============================================================================
		Editor cleanup functions
		============================================================================
		*/
		private static Dictionary<TerrainData, float[,,]> terrainAlphaMap;

		private static Dictionary<TerrainData, float[,]> terrainHeightMap;

		public static void TerrainAlphaMapChange(TerrainData terrainData)
		{
			if(Application.isEditor)
			{
				if(terrainAlphaMap == null)
				{
					terrainAlphaMap = new Dictionary<TerrainData, float[,,]>();
				}
				if(!terrainAlphaMap.ContainsKey(terrainData))
				{
					terrainAlphaMap.Add(terrainData,
						terrainData.GetAlphamaps(0, 0,
							terrainData.alphamapWidth,
							terrainData.alphamapHeight));
				}
			}
		}

		public static void TerrainHeightMapChange(TerrainData terrainData)
		{
			if(Application.isEditor)
			{
				if(terrainHeightMap == null)
				{
					terrainHeightMap = new Dictionary<TerrainData, float[,]>();
				}
				if(!terrainHeightMap.ContainsKey(terrainData))
				{
					terrainHeightMap.Add(terrainData,
						terrainData.GetHeights(0, 0, terrainData.heightmapResolution, terrainData.heightmapResolution));
				}
			}
		}

		public static void ClearTerrainChanges()
		{
			if(terrainAlphaMap != null)
			{
				foreach(KeyValuePair<TerrainData, float[,,]> pair in terrainAlphaMap)
				{
					pair.Key.SetAlphamaps(0, 0, pair.Value);
				}
				terrainAlphaMap = null;
			}
			if(terrainHeightMap != null)
			{
				foreach(KeyValuePair<TerrainData, float[,]> pair in terrainHeightMap)
				{
					pair.Key.SetHeights(0, 0, pair.Value);
				}
				terrainHeightMap = null;
			}
		}
	}
}
