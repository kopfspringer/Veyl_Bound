
using UnityEngine;

namespace GamingIsLove.Makinom.Components
{
	public interface ISceneID
	{
		bool UseSceneID
		{
			get;
			set;
		}

		int SceneID
		{
			get;
			set;
		}
	}

	public interface IGlobalSceneID : ISceneID
	{
		bool IsGlobalSceneID
		{
			get;
			set;
		}
	}

	public interface ISceneGUID
	{
		bool UseSceneGUID
		{
			get;
			set;
		}

		string SceneGUID
		{
			get;
			set;
		}
	}

	public interface IGlobalSceneGUID : ISceneGUID
	{
		bool IsGlobalSceneGUID
		{
			get;
			set;
		}
	}

	public abstract class BaseSceneID : MonoBehaviour, ISceneID
	{
		public bool useSceneID = true;

		public int sceneID = -1;

		public virtual bool UseSceneID
		{
			get { return this.useSceneID; }
			set { this.useSceneID = value; }
		}

		public virtual int SceneID
		{
			get { return this.sceneID; }
			set { this.sceneID = value; }
		}
	}
}
