﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class ShakeMoverComponent : MonoBehaviour
	{
		protected Transform target;

		protected float time;

		protected float time2;

		protected float hitTime;

		protected GetFloat deltaTime;

		protected bool inPause = false;


		// shake
		protected bool shaking = false;

		protected bool shakeRotation = false;

		protected float xIntensity;

		protected float yIntensity;

		protected float zIntensity;

		protected Vector3 originalPosition;

		protected float shakeSpeed;

		public virtual void Stop()
		{
			this.shaking = false;
			this.deltaTime = null;
		}

		public virtual void StartShake(Transform target, float time, bool shakeRotation,
			float xIntensity, float yIntensity, float zIntensity,
			float speed, GetFloat deltaTime, bool inPause)
		{
			this.Stop();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.target = target;
			this.time = 0;
			this.time2 = time;
			this.shakeRotation = shakeRotation;
			this.xIntensity = xIntensity;
			this.yIntensity = yIntensity;
			this.zIntensity = zIntensity;
			this.shakeSpeed = speed;

			this.hitTime = Time.time;
			this.originalPosition = this.shakeRotation ? this.target.localEulerAngles : this.target.localPosition;

			this.shaking = true;
			this.enabled = true;
		}

		protected virtual void Update()
		{
			if(this.target != null &&
				this.shaking &&
				(this.inPause || !Maki.Game.Paused))
			{
				float delta = this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
				this.time += delta;

				if(delta > 0)
				{
					float timer = (Time.time - this.hitTime) * this.shakeSpeed;
					float factor = (1 - ((this.time2 - this.time) / this.time2));

					if(this.shakeRotation)
					{
						this.target.localEulerAngles = new Vector3(
							this.xIntensity != 0 ?
								this.originalPosition.x + Mathf.Sin(timer) * this.xIntensity * factor :
								this.target.localEulerAngles.x,
							this.yIntensity != 0 ?
								this.originalPosition.y + Mathf.Sin(timer) * this.yIntensity * factor :
								this.target.localEulerAngles.y,
							this.zIntensity != 0 ?
								this.originalPosition.z + Mathf.Sin(timer) * this.zIntensity * factor :
								this.target.localEulerAngles.z);
					}
					else
					{
						this.target.localPosition = new Vector3(
							this.xIntensity != 0 ?
								this.originalPosition.x + Mathf.Sin(timer) * this.xIntensity * factor :
								this.target.localPosition.x,
							this.yIntensity != 0 ?
								this.originalPosition.y + Mathf.Sin(timer) * this.yIntensity * factor :
								this.target.localPosition.y,
							this.zIntensity != 0 ?
								this.originalPosition.z + Mathf.Sin(timer) * this.zIntensity * factor :
								this.target.localPosition.z);
					}

					if(timer > Mathf.PI * 2)
					{
						this.hitTime = Time.time;
					}
				}

				if(this.time >= this.time2)
				{
					if(this.shakeRotation)
					{
						this.target.localEulerAngles = new Vector3(
							this.xIntensity != 0 ? this.originalPosition.x : this.target.localEulerAngles.x,
							this.yIntensity != 0 ? this.originalPosition.y : this.target.localEulerAngles.y,
							this.zIntensity != 0 ? this.originalPosition.z : this.target.localEulerAngles.z);
					}
					else
					{
						this.target.localPosition = new Vector3(
							this.xIntensity != 0 ? this.originalPosition.x : this.target.localPosition.x,
							this.yIntensity != 0 ? this.originalPosition.y : this.target.localPosition.y,
							this.zIntensity != 0 ? this.originalPosition.z : this.target.localPosition.z);
					}
					this.shaking = false;
					this.enabled = false;
				}
			}
		}
	}
}
