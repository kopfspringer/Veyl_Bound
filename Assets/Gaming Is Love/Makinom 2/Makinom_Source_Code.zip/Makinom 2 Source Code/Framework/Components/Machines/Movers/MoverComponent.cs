
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class MoverComponent : MonoBehaviour
	{
		// objects
		protected MoveComponentSettings.Instance moveSettings;

		protected Transform target;

		protected Vector3 position;

		protected bool applyGravity;

		protected GetFloat deltaTime;

		protected bool inPause = false;


		// face rotation
		protected bool faceDirection = false;

		protected RotateComponentSettings.Instance rotationSettings;


		// time
		protected float time;

		protected float time2;


		// settings
		protected float speed;

		protected Interpolation.Vector3Instance interpolation;

		protected float distanceY;


		// curves
		protected AnimationCurve xCurve;

		protected float xCurveMultiply = 1;

		protected AnimationCurve yCurve;

		protected float yCurveMultiply = 1;

		protected AnimationCurve zCurve;

		protected float zCurveMultiply = 1;

		protected bool curveLocalSpace = false;

		protected float curveTime = 0;


		// move types
		protected bool speedToObject = false;

		protected bool speedToPosition = false;

		protected bool moveToPosition = false;

		protected bool moveToDir = false;

		protected bool curveMove = false;

		protected bool useUpdate = false;

		protected bool useFixedUpdate = false;


		// callback
		protected Notify[] notify;


		// secure movement
		protected bool secureMove = false;

		protected Vector3 lastPosition;

		protected float lastMoveTime = 0;

		protected float secureTime = 0.5f;

		protected bool stopAtTarget = false;

		private float stopAfterTime = -1;

		protected virtual void Clear()
		{
			this.notify = null;
			this.target = null;

			this.inPause = false;
			this.faceDirection = false;
			this.speedToObject = false;
			this.speedToPosition = false;
			this.moveToPosition = false;
			this.moveToDir = false;
			this.interpolation = null;
			this.useUpdate = false;
			this.useFixedUpdate = false;
			this.stopAtTarget = false;

			this.deltaTime = null;
			this.curveMove = false;
			this.xCurve = null;
			this.yCurve = null;
			this.zCurve = null;
		}

		protected virtual void CheckUpdateType()
		{
			if(this.moveSettings.IsRigidbody())
			{
				this.useFixedUpdate = true;
			}
			else
			{
				this.useUpdate = true;
			}
		}

		public virtual void StopMoving()
		{
			Notify[] tmpNotify = this.notify;
			this.Clear();
			this.Notify(tmpNotify);
		}


		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public virtual void SpeedToObject(MoveComponentSettings.Instance moveSettings, bool g,
			bool fd, RotateComponentSettings.Instance rotationSettings, float s, float d,
			Transform t, float secureTime, float stopAfterTime, bool stopAtTarget, GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.Clear();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.moveSettings = moveSettings;
			this.applyGravity = g;
			this.speed = s;
			this.distanceY = d;
			this.target = t;
			this.notify = notify;
			this.faceDirection = fd;
			this.rotationSettings = rotationSettings;

			if(secureTime >= 0.1f)
			{
				this.secureMove = true;
				this.secureTime = secureTime;
			}
			else
			{
				this.secureMove = false;
			}
			if(stopAfterTime > 0)
			{
				this.stopAfterTime = Time.time + stopAfterTime;
			}
			else
			{
				this.stopAfterTime = -1;
			}
			this.stopAtTarget = stopAtTarget;

			this.CheckUpdateType();
			this.speedToObject = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}

		public virtual void SpeedToPosition(MoveComponentSettings.Instance moveSettings, bool g,
			bool fd, RotateComponentSettings.Instance rotationSettings, float s, float d,
			Vector3 pos, float secureTime, float stopAfterTime, bool stopAtTarget, GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.Clear();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.moveSettings = moveSettings;
			this.applyGravity = g;
			this.speed = s;
			this.distanceY = d;
			this.position = pos;
			this.notify = notify;
			this.faceDirection = fd;
			this.rotationSettings = rotationSettings;

			if(secureTime >= 0.1f)
			{
				this.secureMove = true;
				this.secureTime = secureTime;
			}
			else
			{
				this.secureMove = false;
			}
			if(stopAfterTime > 0)
			{
				this.stopAfterTime = Time.time + stopAfterTime;
			}
			else
			{
				this.stopAfterTime = -1;
			}
			this.stopAtTarget = stopAtTarget;

			this.CheckUpdateType();
			this.speedToPosition = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}

		public virtual void MoveToPosition(MoveComponentSettings.Instance moveSettings, bool g,
			bool fd, RotateComponentSettings.Instance rotationSettings, Vector3 pos, Interpolation interpolation, float t,
			GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.Clear();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.moveSettings = moveSettings;
			this.applyGravity = g;
			this.interpolation = interpolation.CreateVector3(this.transform.position, pos, t);
			this.notify = notify;
			this.rotationSettings = rotationSettings;

			if(fd)
			{
				this.rotationSettings.LookAt(pos, Vector3.up);
			}

			this.CheckUpdateType();
			this.moveToPosition = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}

		public virtual void MoveToDirection(MoveComponentSettings.Instance moveSettings, Vector3 d,
			bool fd, RotateComponentSettings.Instance rotationSettings, float s, float t,
			GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.Clear();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.moveSettings = moveSettings;
			this.position = d;
			this.speed = s;
			this.time = 0;
			this.time2 = t;
			this.notify = notify;
			this.rotationSettings = rotationSettings;

			if(fd)
			{
				this.rotationSettings.LookAt(this.position + this.transform.position, Vector3.up);
			}

			this.CheckUpdateType();
			this.moveToDir = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}

		public virtual void MoveByCurve(MoveComponentSettings.Instance moveSettings,
			bool fd, RotateComponentSettings.Instance rotationSettings,
			AnimationCurve xCurve, float xMultiply,
			AnimationCurve yCurve, float yMultiply,
			AnimationCurve zCurve, float zMultiply,
			bool localSpace, float time, float curveTime, GetFloat deltaTime, bool inPause, params Notify[] notify)
		{
			Notify[] tmpNotify = this.notify;
			this.Clear();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.moveSettings = moveSettings;
			this.position = this.transform.position;

			this.faceDirection = fd;
			this.rotationSettings = rotationSettings;

			this.xCurve = xCurve;
			this.xCurveMultiply = xMultiply;
			this.yCurve = yCurve;
			this.yCurveMultiply = yMultiply;
			this.zCurve = zCurve;
			this.zCurveMultiply = zMultiply;
			this.curveLocalSpace = localSpace;

			this.time = 0;
			this.time2 = time;
			this.curveTime = curveTime;

			this.notify = notify;

			this.CheckUpdateType();
			this.curveMove = true;
			this.enabled = true;

			this.Notify(tmpNotify);
		}


		/*
		============================================================================
		Callbacks functions
		============================================================================
		*/
		protected virtual void Notify()
		{
			if(this.notify != null)
			{
				Notify[] tmpNotify = this.notify;
				this.notify = null;
				this.Notify(tmpNotify);
			}
		}

		protected virtual void Notify(Notify[] tmpNotify)
		{
			if(tmpNotify != null)
			{
				for(int i = 0; i < tmpNotify.Length; i++)
				{
					if(tmpNotify[i] != null)
					{
						tmpNotify[i]();
					}
				}
			}
		}

		protected virtual void OnControllerColliderHit(ControllerColliderHit hit)
		{
			if(this.speedToObject &&
				this.notify != null && notify.Length > 0 &&
				hit.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				this.enabled = false;
				this.moveSettings.ZeroMove();
				this.Notify();
			}
		}

		protected virtual void OnCollisionEnter(Collision collisionInfo)
		{
			if(this.speedToObject &&
				this.notify != null && notify.Length > 0 &&
				collisionInfo.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				this.enabled = false;
				this.moveSettings.ZeroMove();
				this.Notify();
			}
		}

		protected virtual void OnCollisionEnter2D(Collision2D collisionInfo)
		{
			if(this.speedToObject &&
				this.notify != null && notify.Length > 0 &&
				collisionInfo.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				this.enabled = false;
				this.moveSettings.ZeroMove();
				this.Notify();
			}
		}

		protected virtual void OnTriggerEnter(Collider other)
		{
			if(this.speedToObject &&
				this.notify != null && notify.Length > 0 &&
				other.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				this.enabled = false;
				this.moveSettings.ZeroMove();
				this.Notify();
			}
		}

		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			if(this.speedToObject &&
				this.notify != null && notify.Length > 0 &&
				other.gameObject == this.target.gameObject)
			{
				this.speedToObject = false;
				this.enabled = false;
				this.moveSettings.ZeroMove();
				this.Notify();
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void Update()
		{
			if(this.useUpdate && 
				(this.inPause || !Maki.Game.Paused))
			{
				this.DoMove();
			}
		}

		protected virtual void FixedUpdate()
		{
			if(this.useFixedUpdate &&
				(this.inPause || !Maki.Game.Paused))
			{
				this.DoMove();
			}
		}

		protected virtual void DoMove()
		{
			float delta = this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();

			if(this.speedToObject)
			{
				if(this.target != null)
				{
					if(this.faceDirection)
					{
						this.rotationSettings.LookAt(this.target.position, Vector3.up);
					}

					float tmpSpeed = this.speed * delta;
					Vector3 tmp = this.stopAtTarget &&
						VectorHelper.Distance(this.transform.position,
							this.moveSettings.settings.GetLocked(this.target.position, this.transform),
							this.moveSettings.settings.lockAxis) < tmpSpeed ?
								this.target.position :
								Vector3.MoveTowards(
									this.transform.position, this.target.position,
									tmpSpeed);
					this.moveSettings.settings.DoLock(ref tmp, this.transform);
					if(this.applyGravity)
					{
						tmp += Physics.gravity * delta;
					}
					this.moveSettings.SetPosition(tmp);

					if(this.secureMove && this.transform.position != this.lastPosition)
					{
						this.lastPosition = this.transform.position;
						this.lastMoveTime = Time.time;
					}
				}

				if(this.target == null ||
					(this.secureMove && this.lastMoveTime + this.secureTime < Time.time) ||
					(this.stopAfterTime > 0 && this.stopAfterTime < Time.time) ||
					VectorHelper.Distance(this.gameObject,
						this.moveSettings.settings.GetLocked(this.target.position, this.transform),
						this.moveSettings.settings.lockAxis, true) - this.distanceY <= 0.2f)
				{
					this.speedToObject = false;
					this.enabled = false;
					this.moveSettings.ZeroMove();
					this.Notify();
				}
			}
			else if(this.speedToPosition)
			{
				if(this.faceDirection)
				{
					this.rotationSettings.LookAt(this.position, Vector3.up);
				}


				float tmpSpeed = this.speed * delta;
				Vector3 tmp = this.stopAtTarget &&
					VectorHelper.Distance(this.transform.position,
						this.moveSettings.settings.GetLocked(this.position, this.transform),
						this.moveSettings.settings.lockAxis) < tmpSpeed ?
							this.position :
							Vector3.MoveTowards(
								this.transform.position, this.position,
								tmpSpeed);
				this.moveSettings.settings.DoLock(ref tmp, this.transform);
				if(this.applyGravity)
				{
					tmp += Physics.gravity * delta;
				}
				this.moveSettings.SetPosition(tmp);

				if(this.secureMove && this.transform.position != this.lastPosition)
				{
					this.lastPosition = this.transform.position;
					this.lastMoveTime = Time.time;
				}

				if((this.secureMove && this.lastMoveTime + this.secureTime < Time.time) ||
					(this.stopAfterTime > 0 && this.stopAfterTime < Time.time) ||
					VectorHelper.Distance(this.gameObject,
						this.moveSettings.settings.GetLocked(this.position, this.transform),
						this.moveSettings.settings.lockAxis, true) - this.distanceY <= 0.2f)
				{
					this.speedToPosition = false;
					this.enabled = false;
					this.moveSettings.ZeroMove();
					this.Notify();
				}
			}
			else if(this.moveToPosition)
			{
				Vector3 tmp = this.interpolation.Tick(delta);

				this.moveSettings.settings.DoLock(ref tmp, this.transform);
				if(this.applyGravity)
				{
					tmp += Physics.gravity * delta;
				}
				this.moveSettings.SetPosition(tmp);

				if(this.interpolation.Finished)
				{
					this.moveToPosition = false;
					this.enabled = false;
					this.moveSettings.ZeroMove();
					this.Notify();
				}
			}
			else if(this.moveToDir)
			{
				this.time += delta;

				Vector3 tmp = this.position * this.speed * delta;
				this.moveSettings.settings.DoLock(ref tmp, this.transform);
				this.moveSettings.ChangePosition(tmp);

				if(this.time >= this.time2)
				{
					this.moveToDir = false;
					this.enabled = false;
					this.moveSettings.ZeroMove();
					this.Notify();
				}
			}
			else if(this.curveMove)
			{
				this.time += delta;
				float evaluate = this.curveTime * (this.time / this.time2);

				Vector3 tmp = Vector3.zero;
				if(this.xCurve != null)
				{
					tmp.x = this.xCurve.Evaluate(evaluate) * this.xCurveMultiply;
				}
				if(this.yCurve != null)
				{
					tmp.y = this.yCurve.Evaluate(evaluate) * this.yCurveMultiply;
				}
				if(this.zCurve != null)
				{
					tmp.z = this.zCurve.Evaluate(evaluate) * this.zCurveMultiply;
				}

				if(this.curveLocalSpace)
				{
					Vector3 tmpPos = this.transform.position;
					this.transform.position = this.position;
					tmp = this.transform.TransformPointUnscaled(tmp);
					this.transform.position = tmpPos;
				}
				else
				{
					tmp += this.position;
				}

				if(this.faceDirection)
				{
					this.rotationSettings.LookAt(tmp, Vector3.up);
				}
				this.moveSettings.settings.DoLock(ref tmp, this.transform);
				this.moveSettings.SetPosition(tmp);

				if(this.time >= this.time2)
				{
					this.curveMove = false;
					this.enabled = false;
					this.moveSettings.ZeroMove();
					this.Notify();
				}
			}
		}
	}
}
