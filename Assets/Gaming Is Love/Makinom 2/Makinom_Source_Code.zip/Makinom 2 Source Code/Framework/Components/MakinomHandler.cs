
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.Makinom
{
	[AddComponentMenu("")]
	public class MakinomHandler : MonoBehaviour
	{
		protected Maki instance;

		private UpdateTick guiTickHandler;
		public event UpdateTick GUITick
		{
			add { this.guiTickHandler += value; }
			remove { this.guiTickHandler -= value; }
		}

		public static MakinomHandler Create(Maki instance)
		{
			GameObject gameObject = new GameObject("_Makinom");
			gameObject.transform.SetAsFirstSibling();
			GameObject.DontDestroyOnLoad(gameObject);
			
			MakinomHandler handler = gameObject.AddComponent<MakinomHandler>();
			handler.Init(instance);
			gameObject.AddComponent<MakinomLateFixedTick>();
			return handler;
		}

		public virtual void Init(Maki instance)
		{
			this.instance = instance;
			SceneManager.sceneLoaded += this.OnSceneLoaded;
		}

		protected virtual void OnSceneLoaded(Scene scene, LoadSceneMode mode)
		{
			this.instance.OnSceneLoaded(scene.name, SceneManager.GetActiveScene() == scene);
		}

		protected virtual void Update()
		{
			this.instance.FireTick();
		}

		protected virtual void LateUpdate()
		{
			this.instance.FireLateTick();
		}

		protected virtual void FixedUpdate()
		{
			this.instance.FireFixedTick();
		}

		protected virtual void OnGUI()
		{
			Matrix4x4 tmp = GUI.matrix;
			GUI.matrix = Maki.UI.DefaultScreenMatrix.Matrix;
			if(this.guiTickHandler != null)
			{
				this.guiTickHandler();
			}
			GUI.matrix = tmp;
		}

		protected virtual void OnApplicationQuit()
		{
			this.instance.FireApplicationQuit();
		}

		protected virtual void OnDestroy()
		{
			if(Application.isEditor)
			{
				StoreTerrainChanges.ClearTerrainChanges();
			}
		}
	}
}
